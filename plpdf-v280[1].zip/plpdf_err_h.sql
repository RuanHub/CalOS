create or replace package plpdf_err is
--v2.7.0
---------------------------------------------------------------------------------------------------
/* enable (true) or disable (false) parameter checking */
g_check_params boolean := false; --v2.7.0
---------------------------------------------------------------------------------------------------
procedure cr_error(
  p_code varchar2,
  p_1 varchar2 default null, 
  p_2 varchar2 default null,
	p_3 varchar2 default null, 
  p_4 varchar2 default null,
	p_5 varchar2 default null
  );
---------------------------------------------------------------------------------------------------
--v2.7.0
procedure LoopError(
  p_loop in out number,
  p_proc varchar2
  );  
---------------------------------------------------------------------------------------------------
procedure Init_pc(
  p_orientation varchar2,
  p_unit varchar2,
  p_format varchar2
  );
---------------------------------------------------------------------------------------------------
procedure Init1_pc(
  p_orientation varchar2,
  p_unit varchar2,
  p_format plpdf_type.t_pageformat
  );
---------------------------------------------------------------------------------------------------
procedure SetHeaderProcName_pc(
  p_proc_name varchar2,
  p_height number
  );
---------------------------------------------------------------------------------------------------
procedure SetFooterProcName_pc(
  p_proc_name varchar2,
  p_height number
  );
---------------------------------------------------------------------------------------------------
--v2.3.0
procedure StartClipping_pc(
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_end_prev boolean
  ) ;
---------------------------------------------------------------------------------------------------
procedure SetAllMargin_pc(
  p_left number,
  p_top number,
  p_right number
  );
---------------------------------------------------------------------------------------------------
procedure SetLeftMargin_pc(
  p_margin number
  );
---------------------------------------------------------------------------------------------------
procedure SetTopMargin_pc(
  p_margin number
  );
---------------------------------------------------------------------------------------------------
procedure SetRightMargin_pc(
  p_margin number
  );
---------------------------------------------------------------------------------------------------
procedure SetAutoNewPage_pc(
  p_auto boolean,
  p_margin number
  );
---------------------------------------------------------------------------------------------------
procedure SetDocDisplayMode_pc(
  p_zoom varchar2,
  p_layout varchar2,
	p_hidemenubar boolean,
  p_hidetoolbar boolean,
	p_hidewindowui boolean,
  p_displaydoctitle boolean,
	p_centerwindow boolean,
  p_fitwindow boolean
  );
---------------------------------------------------------------------------------------------------
procedure SetCompress_pc(
  p_compress boolean,
  p_method varchar
  );
---------------------------------------------------------------------------------------------------
procedure SetEncoding_pc(
  p_enc varchar2
  );
---------------------------------------------------------------------------------------------------
procedure NewPage_pc(
  p_orientation varchar2
  );
---------------------------------------------------------------------------------------------------
procedure SetColor4Drawing_pc(
  p_r number,
  p_g number,
  p_b number
  );
---------------------------------------------------------------------------------------------------
procedure SetColor4Filling_pc(
  p_r number,
  p_g number,
  p_b number
  );
---------------------------------------------------------------------------------------------------
procedure SetColor4Text_pc(
  p_r number,
  p_g number,
  p_b number
  );
---------------------------------------------------------------------------------------------------
procedure SetLineWidth_pc(
  p_width number
  );
---------------------------------------------------------------------------------------------------
procedure DrawLine_pc(
  p_x1 number,
  p_y1 number,
  p_x2 number,
  p_y2 number
  );
---------------------------------------------------------------------------------------------------
procedure DrawRect_pc(
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_style varchar2
  );
---------------------------------------------------------------------------------------------------
--v2.3.1
procedure DrawRoundedRect_pc(
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_r number,
  p_style varchar2
  );
---------------------------------------------------------------------------------------------------
procedure AddTTF_pc(
  p_family varchar2,
  p_style varchar2
  );
---------------------------------------------------------------------------------------------------
procedure SetPrintFont_pc(
  p_family varchar2,
  p_style varchar2,
  p_size number
  );
---------------------------------------------------------------------------------------------------
--v2.3.0
procedure GetTextWidthFont_pc(
  p_family varchar2,
  p_style varchar2,
  p_size number,
  p_s varchar2
  );
---------------------------------------------------------------------------------------------------
procedure SetPrintFontSize_pc(
  p_size number
  );
---------------------------------------------------------------------------------------------------
procedure SetLinkDest_pc(
  p_link number,
  p_y number, -- default 0,
  p_page number-- default -1
  );
---------------------------------------------------------------------------------------------------
procedure PutLink_pc(
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_link varchar2
  );
---------------------------------------------------------------------------------------------------
procedure PrintText_pc(
  p_x number,
  p_y number,
  p_txt varchar2
  );
---------------------------------------------------------------------------------------------------
procedure PrintCell_pc(
  p_w number,
  p_h number,
  p_txt varchar2,
  p_border varchar2,
  p_ln number,
  p_align varchar2,
  p_fill number,
  p_link varchar2,
	p_clipping number,
  p_vert_align varchar2 --v2.3.0
  );
---------------------------------------------------------------------------------------------------
procedure PrintMultiLineCell_pc(
  p_w number,
  p_h number,
  p_txt varchar2,
  p_border varchar2,
  p_align varchar2,
  p_fill number,
  p_maxline number,
  p_link varchar2,
  p_clipping number,
  p_indent number,
  p_ln number --v2.0.1
  );
---------------------------------------------------------------------------------------------------
procedure PrintFlowingText_pc(
  p_h number,
  p_txt varchar2,
  p_link varchar2,
  p_clipping number, --v2.1.0
  p_lastline_j varchar2 --v2.2.0
  );
---------------------------------------------------------------------------------------------------
procedure LineBreak_pc(
  p_h number
  );
---------------------------------------------------------------------------------------------------
procedure SetCurrentX_pc(
  p_x number
  );
---------------------------------------------------------------------------------------------------
procedure SetCurrentY_pc(
  p_y number
  );
---------------------------------------------------------------------------------------------------
procedure SetCurrentXY_pc(
  p_x number,
  p_y number
  );
---------------------------------------------------------------------------------------------------
procedure DrawEllipse_pc(
  p_x number,
  p_y number,
  p_rx number,
  p_ry number,
  p_style varchar2
  );
---------------------------------------------------------------------------------------------------
--v2.0.0
procedure PutImage_pc(
  p_name varchar2,
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_link varchar2,
  p_type varchar2
  );
---------------------------------------------------------------------------------------------------
procedure CheckPageBreak_pc(
  p_h number
  );
---------------------------------------------------------------------------------------------------
procedure SetRotate_pc(
  p_angle number,
  p_x number,
  p_y number
  );
---------------------------------------------------------------------------------------------------
procedure CrBookmark_pc(
  p_txt varchar2,
  p_level number,
  p_y number
  );
---------------------------------------------------------------------------------------------------
procedure DrawSector_pc(
  p_xc number,
  p_yc number,
  p_r number,
  p_a number,
  p_b number,
  p_style varchar2,
  p_cw boolean,
  p_o number
  );
---------------------------------------------------------------------------------------------------
procedure SetProtection_pc(
  p_print_perm boolean,
  p_modify_perm boolean,
  p_copy_perm boolean,
  p_annot_forms_perm boolean,
  p_user_pass varchar2,
  p_owner_pass varchar2
  );
---------------------------------------------------------------------------------------------------
procedure PrintImageCell_pc( --v2.0.0
  p_w number,
  p_h number,
  p_name varchar2,
  p_margin number,
  p_border varchar2,
  p_ln number,
  p_fill number,
  p_link varchar2,
  p_type varchar2 --v2.0.0
  );
--------------------------------------------------------------------------------------------------
procedure SetCellMargin_pc(
  p_margin number
  );
--------------------------------------------------------------------------------------------------
procedure SetDashPattern_pc(
  p_line number,
  p_noline number
  );
--------------------------------------------------------------------------------------------------
procedure DrawPolygon_pc(
  p_style varchar2
  );
--------------------------------------------------------------------------------------------------
procedure CrTillingPattern_pc(
  p_name varchar2,
  p_width number,
  p_height number
  );
--------------------------------------------------------------------------------------------------
procedure AddLine2Pattern_pc(
  p_name varchar2,
  p_x1 number,
  p_y1 number,
  p_x2 number,
  p_y2 number
  );
--------------------------------------------------------------------------------------------------
procedure AddRect2Pattern_pc(
  p_name varchar2,
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_style varchar2
  );
--------------------------------------------------------------------------------------------------
procedure AddEllipse2Pattern_pc(
  p_name varchar2,
  p_x number,
  p_y number,
  p_rx number,
  p_ry number,
  p_style varchar2
  );
--------------------------------------------------------------------------------------------------
procedure AddPolygon2Pattern_pc(
  p_name varchar2,
  p_style varchar2
  );
--------------------------------------------------------------------------------------------------
procedure SetTillingPattern_pc(
  p_name varchar2,
  p_color plpdf_type.t_color
  );
--------------------------------------------------------------------------------------------------
procedure AttachFile_pc(
  p_filename varchar2,
  p_desc varchar2
  );
--------------------------------------------------------------------------------------------------
procedure AddTextAnnot_pc(
  p_name varchar2,
  p_contents varchar2,
  p_x number,
  p_y number,
  p_label varchar2,
  p_color plpdf_type.t_color,
  p_popup_x number,
  p_popup_y number,
  p_popup_w number,
  p_popup_h number,
  p_open boolean
  );
--------------------------------------------------------------------------------------------------
procedure AddFileAnnot_pc(
  p_name varchar2,
  p_contents varchar2,
  p_x number,
  p_y number,
  p_filename varchar2,
  p_label varchar2,
  p_color plpdf_type.t_color
  );
--------------------------------------------------------------------------------------------------
procedure AddMarkupAnnot_pc(
  p_annot_type varchar2,
  p_contents varchar2,
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_label varchar2,
  p_color plpdf_type.t_color,
  p_popup_x number,
  p_popup_y number,
  p_popup_w number,
  p_popup_h number,
  p_open boolean
  );
--------------------------------------------------------------------------------------------------
procedure AddTOCItem_pc(
  p_txt varchar2,
  p_level number,
  p_y number,
  p_page number
  );
--------------------------------------------------------------------------------------------------
procedure AddTOC_pc(
  p_item_height number,
  p_stop_footer boolean,
  p_title_font_family varchar2,
  p_title_font_style varchar2,
  p_title_font_size number,
  p_title_height number,
  p_title_text varchar2,
  p_title_body_gap number,
  p_item_font_family varchar2,
  p_item_font_style varchar2,
  p_item_font_size number,
  p_level_indent number,
  p_separator varchar2,
  p_move_to number,
  p_custom_proc varchar2
  );
--------------------------------------------------------------------------------------------------
procedure PrintTOCItem_pc(
  p_item plpdf_type.tr_toc,
  p_toc_level_indent number,
  p_toc_item_height number,
  p_toc_separator varchar2
  );
--------------------------------------------------------------------------------------------------
procedure InsMovePage_pc(
  p_orig_pos number,
  p_new_pos number
  );
--------------------------------------------------------------------------------------------------
procedure AddCJKFont_pc(
  p_name varchar2
  );
--------------------------------------------------------------------------------------------------
procedure AcroForm_AddTextField_pc(
  p_name varchar2,
  p_value varchar2,
  p_default_value varchar2,
  p_maxlength number,
  p_multiline boolean,
  p_password boolean,
  p_read_only boolean,
  p_required boolean,
  p_noexport boolean,
  p_print boolean,
  p_x number,
  p_y number,
  p_width number,
  p_height number,
  p_align varchar2,
  p_fill_color plpdf_type.t_color,
  p_border_width number,
  p_border_color plpdf_type.t_color,
  p_font_size_auto boolean,
  p_hint varchar2
  );
--------------------------------------------------------------------------------------------------
procedure AcroForm_AddChoiceField_pc(
  p_name varchar2,
  p_values plpdf_type.t_opt_array,
  p_value varchar2,
  p_default_value varchar2,
  p_combo boolean,
  p_edit boolean,
  p_sort boolean,
  p_read_only boolean,
  p_required boolean,
  p_noexport boolean,
  p_print boolean,
  p_x number,
  p_y number,
  p_width number,
  p_height number,
  p_fill_color plpdf_type.t_color,
  p_border_width number,
  p_border_color plpdf_type.t_color,
  p_font_size_auto boolean,
  p_hint varchar2
  );
--------------------------------------------------------------------------------------------------
procedure Acroform_CheckAction(
  p_action varchar2,
  p_url varchar2,
  p_submitformat varchar2,
  p_request varchar2,
  p_IncludeNoValueFields boolean,
  p_SubmitCoordinates boolean,
  p_javascript varchar2
  );
--------------------------------------------------------------------------------------------------
procedure AcroForm_AddPushbutton_pc(
  p_name varchar2,
  p_label varchar2,
  p_x number,
  p_y number,
  p_width number,
  p_height number,
  p_action varchar2,
  p_url varchar2,
  p_submitformat varchar2,
  p_request varchar2,
  p_IncludeNoValueFields boolean,
  p_SubmitCoordinates boolean,
  p_javascript varchar2,
  p_print boolean,
  p_fill_color plpdf_type.t_color,
  p_border_width number,
  p_border_color plpdf_type.t_color,
  p_font_size_auto boolean,
  p_hint varchar2
  );
--------------------------------------------------------------------------------------------------
procedure AcroForm_AddRbField_pc(
  p_name varchar2,
  p_values plpdf_type.t_radiobutton_array,
  p_value varchar2,
  p_default_value varchar2,
  p_read_only boolean,
  p_required boolean,
  p_NoToggleToOff boolean,
  p_noexport boolean,
  p_print boolean,
  p_height number,
  p_gap number,
  p_fill_color plpdf_type.t_color,
  p_hint varchar2
  );
--------------------------------------------------------------------------------------------------
procedure AcroForm_AddCheckBoxField_pc(
  p_name varchar2,
  p_label varchar2,
  p_checked boolean,
  p_default_checked boolean,
  p_read_only boolean,
  p_required boolean,
  p_noexport boolean,
  p_print boolean,
  p_x number,
  p_y number,
  p_height number,
  p_gap number,
  p_fill_color plpdf_type.t_color,
  p_hint varchar2
  );
--------------------------------------------------------------------------------------------------
procedure SetNOLastpageProcName_pc(
  p_proc_name varchar2
  );
--------------------------------------------------------------------------------------------------
--v2.2.0
procedure PrintFlowingTextLimit_pc(
  p_h number,
  p_txt varchar2,
  p_link varchar2,
  p_min_x number,
  p_max_x number,
  p_align varchar2,
  p_clipping number,
  p_lastline_j varchar2
  );
--------------------------------------------------------------------------------------------------
--v2.1.0
procedure StartOpacity_pc(
  p_val number
  );
--------------------------------------------------------------------------------------------------
--v2.1.0
procedure StartOptCont_pc(
  p_name varchar2,
  p_state boolean,
  p_ui_order boolean,
  p_print boolean
  );
--------------------------------------------------------------------------------------------------
--v2.3.0
procedure AddScreenAnnotURL_pc(
  p_name varchar2,
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_url varchar2,
  p_mime varchar2,
  p_event varchar2
  );
--------------------------------------------------------------------------------------------------
--v2.3.0
procedure AddScreenAnnotFile_pc(
  p_name varchar2,
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_mime varchar2,
  p_event varchar2
  );
--------------------------------------------------------------------------------------------------
--v2.4.0
procedure setDigSig_pc(
  p_Name varchar2,
  p_Location varchar2,
  p_Reason varchar2,
  p_ContactInfo varchar2,
  p_x number,
  p_y number,
  p_w number,
  p_h number,
  p_access_perms number
  );
--------------------------------------------------------------------------------------------------
--v2.5.0
procedure SetRotatePages_pc(
  p_angle number
  );
--------------------------------------------------------------------------------------------------  
--v2.7.0
procedure setID_pc(
  p_id varchar2
  );
--------------------------------------------------------------------------------------------------    
end;
/

