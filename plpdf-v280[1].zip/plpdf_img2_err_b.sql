create or replace package body plpdf_img2_err wrapped 
0
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
3
b
9200000
1
4
0 
c
2 :e:
1PACKAGE:
1BODY:
1PLPDF_IMG2_ERR:
1FUNCTION:
1ERRORHANDLER:
1P_IMG:
1OUT:
1NOCOPY:
1BLOB:
1P_NAME:
1VARCHAR2:
1RETURN:
0

0
0
27
2
0 :2 a0 97 a0 8d 90 :3 a0 b0
3f 8f a0 b0 3d b4 :2 a0 2c
6a 4f b7 a4 b1 11 68 4f
b1 b7 a4 11 a0 b1 56 4f
1d 17 b5 
27
2
0 3 7 b 15 19 3d 31
35 39 30 44 51 4d 2d 59
4c 5e 62 66 6a 49 6e 70
74 76 82 86 88 8a 8c 90
9c a0 a2 a5 a7 a8 b1 
27
2
0 1 9 e 1 a 3 c
10 17 :3 3 a :2 3 16 5 c
:2 1 3 :a 1 5 :6 1 
27
4
0 :3 1 :2 3 :6 4
:4 5 3 :2 6 :2 3
8 :2 7 :8 3 b
:6 1 
b3
4
:3 0 1 :3 0 2
:3 0 3 :6 0 1
:2 0 4 :3 0 5
:a 0 1a 2 :7 0
5 49 0 3
7 :3 0 8 :3 0
9 :3 0 6 :5 0
1 a 9 :4 0
16 0 7 b
:3 0 a :7 0 e
d :3 0 c :3 0
9 :3 0 10 12
0 1a 5 13
:2 0 a 19 :3 0
19 0 19 18
16 17 :6 0 1a
1 0 5 13
19 21 :3 0 1f
0 1f :3 0 1f
21 1d 1e :6 0
22 :2 0 3 :3 0
c 0 3 1f
25 :3 0 24 22
26 :8 0 
e
4
:3 0 1 6 1
c 2 b f
1 15 1 1a

1
4
0 
25
0
1
14
2
4
0 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0
0 0 0 0 
3 0 1
6 2 0
c 2 0
5 1 2
0

/
