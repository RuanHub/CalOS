create or replace package plpdf_gl is
--v2.1.1
  procedure init;
  --
  function nameToUnicode(
     p_name varchar2
     ) return number;
  --
  function unicodeToName(
     p_num number
     ) return varchar2;
  --
end plpdf_gl;
/

