create or replace package plpdf_pdfx is
-- v2.7.0

-- PDFX, PDF/A

-- Create XMP as blob
function CreateXmp(
    p_producer varchar2,
    p_title varchar2 default null,
    p_author varchar2 default null, 
    p_subject varchar2 default null, 
    p_keywords varchar2 default null, 
    p_creator varchar2 default null,
    p_creationdate date default null,
    p_moddate date default null,
    p_PdfXConformance varchar2 default null
    ) return blob;  

--srgb
function srgb_profile
  return blob;
end plpdf_pdfx;
/

