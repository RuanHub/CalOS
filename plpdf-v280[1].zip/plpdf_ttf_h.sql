create or replace package plpdf_ttf is
--v2.7.0
---------------------------------------------------------------------------------------------------
type t_enc_map is table of varchar2(255) index by pls_integer;
---------------------------------------------------------------------------------------------------
--v1.01
function MakeFont(
  p_fontfile_name varchar2,
  p_fontfile blob,
  p_id number,
  p_enc varchar2 default 'cp1252',
  p_patch t_enc_map
  ) return plpdf_type.t_addfont;
---------------------------------------------------------------------------------------------------
--v1.2.5
procedure StoreTTF(
  p_font_file_id number,
  p_enc varchar2 default 'cp1252'
  );
---------------------------------------------------------------------------------------------------
--v1.2.5
function GetTTF(
  p_id number
  ) return plpdf_type.t_addfont;
---------------------------------------------------------------------------------------------------
-- v1.2.5
procedure StoreTTF_1(
  p_font_file_id number,
  p_enc varchar2 default 'cp1252'
  );
---------------------------------------------------------------------------------------------------
--v1.2.5
procedure StoreTTF_utf16(
  p_font_file_id number
  );
---------------------------------------------------------------------------------------------------
--v2.1.1
function ReadMap 
  return t_enc_map;
---------------------------------------------------------------------------------------------------
--v2.1.1
function MakeFontEncoding(
  p_map t_enc_map
  ) return varchar2;
---------------------------------------------------------------------------------------------------
end;
/

