create or replace package plpdf_text2 is
  --v2.7.0
--------------------------------------------------  
  c_text_type varchar2(10 char) := 'SINGLE';
  c_se varchar2(1 char) := '('; -- start_encloser
  c_ee varchar2(1 char) := ')'; -- end_encloser
  v_encoding  varchar2(20 char); --v2.7.0
---------------------------------------------------------------------------------------------------
function xescape(
  p_s varchar2
  ) return varchar2;
---------------------------------------------------------------------------------------------------
function tohex(
  p_s varchar2
  ) return varchar2;
---------------------------------------------------------------------------------------------------
function tohex_false(
  p_s varchar2
  ) return varchar2;
---------------------------------------------------------------------------------------------------
function cast_to_varchar2(
  p_s raw
  ) return varchar2;
---------------------------------------------------------------------------------------------------
function cast_to_raw(
  p_s varchar2
  ) return raw;
---------------------------------------------------------------------------------------------------
function ascii1(
  p_s varchar2
  ) return number;
---------------------------------------------------------------------------------------------------
-- mod: v2.3.1
function replace_blob(
  p_blob in out nocopy blob,
  p_from varchar2,
  p_to varchar2,
  p_from2 varchar2 default null,
  p_to2 varchar2 default null,
  p_from3 varchar2 default null,
  p_to3 varchar2 default null
  ) return blob;
---------------------------------------------------------------------------------------------------
procedure repl_init(
  p_enc varchar2 default 'cp1252'
  );  
---------------------------------------------------------------------------------------------------
--v2.7.0
function GetTextWidth_J(
  p_s varchar2,
  p_cw in out nocopy plpdf_type.t_cw,
  p_fontsize number
  ) return number;
--
function GetTextWidth_KC(
  p_s varchar2,
  p_cw in out nocopy plpdf_type.t_cw,
  p_fontsize number
  ) return number;
--
function GetTextWidth_1(
  p_s varchar2,
  p_cw in out nocopy plpdf_type.t_cw,
  p_fontsize number
  ) return number;
--
--v2.7.0
function RemoveMissingChars_1(
  p_s varchar2,
  p_cw in out nocopy plpdf_type.t_cw
  ) return varchar2;
--
--v2.7.0
function RemoveMissingChars_CJK(
  p_s varchar2,
  p_cw in out nocopy plpdf_type.t_cw
  ) return varchar2;  
--
function textstringASCII(
  p_s varchar2,
  p_n number default null
  ) return varchar2;
--
function textstringHEX(
  p_s varchar2,
  p_n number default null
  ) return varchar2;
--
end plpdf_text2;
/

