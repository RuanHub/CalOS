create or replace package plpdf_ttf_subset is
--v2.3.0

function CreateSubSet(
  p_fileName varchar2,
  p_ttf blob,
  p_glyphsUsed plpdf_type.t_ttfsubset_list
  ) return blob;

end plpdf_ttf_subset;
/

