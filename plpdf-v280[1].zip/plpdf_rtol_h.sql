create or replace package plpdf_rtol is
--v2.1.1
---------------------------------------
function convert_text(
  p_text varchar2, 
  p_ttf_cw Plpdf_Type.t_cw, 
  p_direction varchar2
  ) return varchar2;
--
end plpdf_rtol;
/

