create or replace package plpdf_enc is
--v1.1.8
---------------------------------------------------------------------------------------------------
type t_encoding1 is table of varchar2(255 char) index by pls_integer;
v_e t_encoding1;
---------------------------------------------------------------------------------------------------
procedure init(
  p_enc varchar2, 
  p_cw in out plpdf_type.t_charwidths
  );
---------------------------------------------------------------------------------------------------
end;
/

