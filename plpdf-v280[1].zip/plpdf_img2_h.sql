create or replace package plpdf_img2 is
--v2.8.0
  --
  function genPdfImage(
  p_img in out nocopy blob,
  p_name varchar2
  ) return plpdf_type.t_pdfimage;
  --
  function DictTest(
  p_img in out nocopy blob,
  p_name varchar2
  ) return varchar2;
  
end plpdf_img2;
/

