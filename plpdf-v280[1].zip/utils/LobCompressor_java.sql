create or replace and compile java source named "LobCompressor" as
import java.lang.*;
import oracle.sql.*;
import java.io.*;
import java.util.zip.InflaterInputStream;
import java.util.zip.DeflaterOutputStream;

public class LobCompressor {
    public static void compress(CLOB clob, BLOB blob) throws Exception {
        InputStream in=clob.getAsciiStream();
        DeflaterOutputStream z=new 
        DeflaterOutputStream(blob.getBinaryOutputStream());
        byte[] buffer=new byte[clob.getBufferSize()];
        int cnt;
        while ((cnt=in.read(buffer))!=-1) {
            z.write(buffer,0,cnt);
        }
        in.close();
        z.close();
    }

    public static void decompress(BLOB blob, CLOB clob) throws Exception {
        OutputStream out=clob.getAsciiOutputStream();
        InflaterInputStream z=new InflaterInputStream(blob.getBinaryStream());
        byte[] buffer=new byte[blob.getBufferSize()];
        int cnt;
        while ((cnt=z.read(buffer))!=-1) {
            out.write(buffer,0,cnt);
        }
        z.close();
        out.close();
    }

    public static void compress(BLOB slob, BLOB blob) throws Exception {
        InputStream in=slob.getBinaryStream();
        DeflaterOutputStream z=new 
        DeflaterOutputStream(blob.getBinaryOutputStream());
        byte[] buffer=new byte[slob.getBufferSize()];
        int cnt;
        while ((cnt=in.read(buffer))!=-1) {
            z.write(buffer,0,cnt);
        }
        in.close();
        z.close();
    }

    public static void decompress(BLOB blob, BLOB slob) throws Exception {
        OutputStream out=slob.getBinaryOutputStream();
        InflaterInputStream z=new InflaterInputStream(blob.getBinaryStream());
        byte[] buffer=new byte[blob.getBufferSize()];
        int cnt;
        while ((cnt=z.read(buffer))!=-1) {
            out.write(buffer,0,cnt);
        }
        z.close();
        out.close();
    }
};
/



