declare
  l_data blob;

  l_image      ordsys.ordimage;
begin

  -- modify select!!!
  select t.image_file
    into l_data
  from image_blob t
  where t.id = 1
  for update;
  
	 l_image := ordsys.ordimage(ordsys.ordsource
       (l_data,null,null,null,null,null),null,null,null,null,null,null,null);
       
  l_image.setProperties;
  
  if not(l_image.getContentFormat() = '24BITRGB' AND l_image.getmimetype() = 'image/jpeg') then
    l_Image.process('fileFormat=JPEG contentFormat=24BITRGB');
	  l_image.setProperties;
  end if;  
end;
/
  