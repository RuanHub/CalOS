create or replace package plpdf_digsig is
--v2.4.0

  v_original_data blob;
  v_signed_data blob;
  v_signproc varchar2(255 char) := 'PKCS7Sign';


  v_digsig_keystore blob;
  v_digsig_certalias varchar2(255 char);
  v_digsig_keystore_password varchar2(255 char);
  v_digsig_privkey_password varchar2(255 char);
  
--v2.4.0
procedure setSignProc(
  p_signproc varchar2
  );
--v2.4.0
procedure setOrignaldata(
  p_original_data blob
  );  
--v2.4.0
function getSigneddata
  return blob;  
--v2.4.0
procedure setKeyStore(
  p_digsig_keystore blob
  );
--v2.4.0
procedure setCertAlias(
  p_digsig_certalias varchar2
  );  
--v2.4.0
procedure setKeyStorePassword(
  p_digsig_keystore_password varchar2
  );  
--v2.4.0
procedure setPrivKeyPassword(
  p_digsig_privkey_password varchar2
  );    
--v2.4.0
procedure PKCS7Sign;

end plpdf_digsig;
/

