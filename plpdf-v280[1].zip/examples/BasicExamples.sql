CREATE OR REPLACE package BasicExamples is
/* Package Release date 2012-03-19  YYYY-MM-DD */

-- Init examples
procedure InitDefault;
procedure InitOrient;
procedure InitUnit;
procedure InitPageFormat;
-- Init1 example
procedure Init1;
-- NewPage example
procedure NewPage;
-- LineBreak examle
procedure LineBreak;
-- SetPrintFont example
procedure SetPrintFont;
procedure SetPrintFontSize;
-- Position examples
procedure SetCurrentXY;
procedure SetCurrentX;
procedure SetCurrentY;
-- Printcell examples
procedure PrintCell;
procedure PrintCellPro;
-- SetEncoding examples
procedure SetEncoding;
procedure SetEncoding2;
-- SetProperties example
procedure SetProperties;
-- SetDisplayMode examples
procedure DisplayModeZoom1;
procedure DisplayModeZoom2;
procedure DisplayModeZoom3;
procedure DisplayModeHide1;
procedure DisplayModeHide2;
-- HeaderFooter examples
procedure HeaderFooter;
procedure header1;
procedure footer1;
procedure HeaderFooter1;
-- Margin examples
procedure SetMargin;
procedure SetCellMargins;
procedure SetMarginsValue;
-- Color 
procedure SetTextColor;
procedure SetFillColor;
procedure SetDrawColor;
-- Textwith
procedure GetTextWidth;
-- Draw
procedure DrawLine;
procedure DrawRect;
procedure DrawEllipseCircle;
procedure DrawSector;
procedure DashPattern;
procedure DrawPolygon;
procedure Pattern;
procedure DrawRoundedRect;
-- Internal link
procedure InternalLink;
-- Multiline Cell
procedure MultiLineCell;
-- Flowing text
procedure FlowingText;
procedure FlowingTextLimit;
-- Image
procedure Image;
procedure ImageCell;
-- PrintRow
procedure PrintRow;
procedure PrintRowLink;
-- Rotate
procedure Rotate;
procedure SetRotatePage;
-- Bookmark
procedure CreateBookmark;
-- TTF
procedure TTFembending;
-- Clipping
procedure Clipping;
-- Protection
procedure Protect;
-- JavaScript
procedure JavaScript;
-- Attach 
procedure AttachFile;
-- PageNumber
procedure PageNumber;
procedure header2;
procedure footer2;
-- Annotation
procedure TextAnnotation;
procedure FileAnnotation;
procedure MarkupAnnotation;
procedure ScreenAnnotation;
-- Chinese font
procedure ChineseFont;
-- TOC
procedure WithoutTOC;
procedure HeaderTOC1;
procedure FooterTOC1;
procedure MinimalTOC;
procedure NormalTOC;
procedure MovetoTOC;
procedure CoverPageTOC;
procedure FooterTOC2;
procedure DifferentFooter;
procedure FooterTOC3;
procedure TestTOC1Custom;
procedure CustomTOC;
procedure ProfTOC;
procedure InsMoveTOC;
-- PrintText
procedure PrintText;
-- Acroform
procedure Acroform;
-- Others
procedure TextSetRTOL;
procedure SetAutoNewPage;
procedure SetCompress;
procedure SetNOLastpageProcName;
procedure NotLastPage;
procedure InsertMovePage;
procedure Opacity;
procedure OptCont;
-- Template
procedure TemplatePage;
procedure Template_init;
procedure Template_eg;
procedure DefaultTemplate;

end;
/

CREATE OR REPLACE package body BasicExamples is

v_tpl   plpdf_type.tr_tpl_data;  



/* INIT_EXAMPLE */
procedure InitDefault is
      
l_blob blob;
 
begin  
  
   /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
     
  /* Create a new page. Without parameters the default page orientation: portrait. */ 
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 200,          -- Rectangle width 
  p_h => 10,           -- Rectangle height
  p_txt => 'InitDefault - The Init procedure with default parameters' -- Text in rectangle
  );
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_file, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;


/* INIT_EXAMPLE_ORIENT */
procedure InitOrient is
  l_blob blob;
  
begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init(
  p_orientation => 'L'          -- Set the page orientiation: Landscape
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */     
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 100,                 -- Rectangle width
  p_h => 10,                  -- Rectangle height
  p_txt => 'InitOrinet - Orientation: Landscape' -- Text in rectangle
  );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
   /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_file, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;

/* INIT_EXAMPLE_UNIT */
procedure InitUnit is
  l_blob blob;
  
begin
  
   /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init(
  p_unit => 'cm'             -- Set the unit of measure: cm
  );
  /* Create a new page. Without parameters the default page orientation: portrait. */     
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 100,          -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'InitUnit - Unit of measure: cm'   -- Text in rectangle
  );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
  plpdf.SendDoc(
  p_blob => l_blob
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_file, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;

/* INIT_EXAMPLE_PAGE_FORMAT */
procedure InitPageFormat is
  
  l_blob blob;
  
begin
   /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init(
  p_format => 'A3'        -- Page format: A3 
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */ 
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 100,                 -- Rectangle width
  p_h => 10,                  -- Rectangle height
  p_txt => 'InitPageFormat - Page format: A3' -- Text in rectangle
  );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_file, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;


/* INIT1_EXAMPLE */
procedure Init1 is
      
l_blob blob;
 
begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm */
  plpdf.Init1(
  p_orientation => 'L',        -- Orientation: Landscape
  p_unit => 'mm',              -- Unit of measure: mm(default)
  p_format => plpdf_const.a5  -- Set the page froamat A5. Using a constant from plpdf_const package
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */      
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 200,          -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Init1 procedure: Page format - A5'       -- Text in rectangle
  );
   
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_file, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;

/* NEW_PAGE_EXAMPLE */
procedure NewPage is
      
l_blob blob;

begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* If no orientation is given then the orientation specified in Init
  will be used.  */     
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );

  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 200,                 -- Rectangle width
  p_h => 10,                  -- Rectangle height
  p_txt => 'NewPage - Start page orientation: Portrait' ---- Text in rectangle
  );
  
  /* Creates a new page with landscape orientation */
  plpdf.NewPage(
  p_orientation => 'L'  -- Landscape: 'L', Portrait(default): 'P'   
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 200,                 -- Rectangle width
  p_h => 10,                  -- Rectangle height
  p_txt => 'Second page: Landscape'        -- Text in rectangle
  );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_file, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;

/* LINEBREAK_EXAMPLE */
procedure LineBreak is
      
l_blob blob;

begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Create a new page. Without parameters the default page orientation: portrait. */        
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 200,          -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'First line of the document' -- Text in rectangle
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10         -- Height of the line break. 
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 100,          -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Create new row, withe LineBreak procedure.' -- Text in rectangle
  );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob     -- The generated document
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_file, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;

/* SET_PRINT_FONT_EXAMPLE */

procedure SetPrintFont is
      
l_blob blob;

begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Create a new page. Without parameters the default page orientation: portrait. */     
  plpdf.NewPage;
  
  /* Set font properties.
     p_family: Font Family
     p_style: B - Bold, I - Italic, U - Underline, null - Regular. Styles may be combined ( BI - Bold and Italic)
     p_size: size
   */
   plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 200,          -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'SetPrintFont - Reagular Arial text. Size: 12'   -- Text in rectangle
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
  
  /* For another cell, setting a new font properties */
  plpdf.SetPrintFont(
  p_family => 'Courier',       -- Font family: Courier
  p_style => 'B',              -- Font style: Bold
  p_size => 14                 -- Font size: 14
  );
   
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 200,          -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Bold Courier text. Size 14'       -- Text in rectangle 
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
  
  /* For the third cell, setting a new font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',   -- Font family: Arial
  p_style => 'I',        -- Font style: Italic
  p_size => 16           -- Font size: 16
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 200,          -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Italic Arial text. Size 16'       -- Text in rectangle
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
  
  /* Combined style parameters */
  plpdf.SetPrintFont(
  p_family => 'Arial',         -- Font family: Arial
  p_style => 'BIU',            -- Font style: Bold, Italic and Underline
  p_size => 12                 -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 200,          -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Bold,Italic and Underline Arial text. Size 12'  -- Text in rectangle
  );
  
   /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_file, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;

procedure SetPrintFontSize is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle width
    p_h => 40,           -- Rectangle height
    p_txt => 'First cell',  -- Text in rectangle
    p_ln => 1               -- Cursor position after the cell is printed
    );
    
    /* Sets the font size. All other font properties remain unchanged. */
    plpdf.SetPrintFontSize(
    p_size => 16     -- Font size
    );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle width
    p_h => 40,           -- Rectangle height
    p_txt => 'Greater size',          -- Text in rectangle
    p_ln => 1         -- Cursor position after the cell is printed
    );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle width
    p_h => 40,           -- Rectangle height
    p_txt => 'Greater size2'          -- Text in rectangle
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure SetCurrentXY is
  l_blob blob;
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
     plpdf.Init;
     
     /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
     plpdf.NewPage;
     
     /* Sets the font and its properties */
     plpdf.SetPrintFont(
     p_family => 'Arial',     -- Font family: Arial
     p_style => null,         -- Font style: Regular(default)
     p_size => 12             -- Font size: 12
     );
     
     /* Places the cursor at the X and Y coordinate. */
     plpdf.SetCurrentXY(
     p_x => 50,          -- X coordinate
     p_y => 30           -- Y coordinate
     );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 100,           -- Rectangle width
     p_h => 10,           -- Rectangle height
     p_txt => 'This cell start position: X=50, Y=30', -- Text in rectangle
     p_border => '1'    -- Border: outline
     );
     
     /* Places the cursor at the X and Y coordinate. */
     plpdf.SetCurrentXY(
     p_x => 40,          -- X coordinate
     p_y => 100           -- Y coordinate
     );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 110,           -- Rectangle width
     p_h => 10,           -- Rectangle height
     p_txt => 'Jump to: X=40, Y=100, with SetCurrentXY
     ', -- Text in rectangle
     p_border => '1'             -- Border: outline
     );
     
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */  
    insert into STORE_BLOB (BLOB_FILE,CREATED_DATE) values (l_blob, sysdate);
    commit;
    end;

procedure SetCurrentX is
  l_blob blob;
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
     plpdf.Init;
     
     /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
     plpdf.NewPage;
     
     /* Sets the font and its properties */
     plpdf.SetPrintFont(
     p_family => 'Arial',     -- Font family: Arial
     p_style => null,         -- Font style: Regular(default)
     p_size => 12             -- Font size: 12
     );
     
     /* Places the cursor at the X coordinate. */
     plpdf.SetCurrentX(
     p_x => 10          -- X coordinate
     );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 50,           -- Rectangle width
     p_h => 10,           -- Rectangle height
     p_txt => 'SetCurrentX', -- Text in rectangle
     p_border => '1'    -- Border: outline
     );
     
     /* Places the cursor at the X coordinate. */
     plpdf.SetCurrentX(
     p_x => 120          -- X coordinate
     );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 50,           -- Rectangle width
     p_h => 10,           -- Rectangle height
     p_txt => 'New X position', -- Text in rectangle
     p_border => '1'    -- Border: outline
     );
    
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */  
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES(l_blob,sysdate);
    commit;
    end;

procedure SetCurrentY is
  l_blob blob;
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
     plpdf.Init;
     
     /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
     plpdf.NewPage;
     
     /* Sets the font and its properties */
     plpdf.SetPrintFont(
     p_family => 'Arial',     -- Font family: Arial
     p_style => null,         -- Font style: Regular(default)
     p_size => 12             -- Font size: 12
     );
     
     /* Places the cursor at the Y coordinate. */
     plpdf.SetCurrentY(
     p_y => 30,          -- Y coordinate
     p_cr => false      -- When true, X position returns to beginning of line
     );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 50,           -- Rectangle width
     p_h => 10,           -- Rectangle height
     p_txt => 'SetCurrentY', -- Text in rectangle
     p_border => '1'    -- Border: outline
     );
     
     /* Places the cursor at the Y coordinate. */
     plpdf.SetCurrentY(
     p_y => 120          -- Y coordinate
     );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 50,           -- Rectangle width
     p_h => 10,           -- Rectangle height
     p_txt => 'New Y position', -- Text in rectangle
     p_border => '1'    -- Border: outline
     );
    
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */  
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES(l_blob,sysdate);
    commit;
    end;


/* PRINT_CELL_EXAMPLE */
procedure PrintCell is
      
l_blob blob;

begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Create a new page. Without parameters the default page orientation: portrait. */      
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'PrintCell Example - Basic style'  -- Printed text
  );
  
  /* Printcell with frame */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'PrintCell with frame',  -- Text in rectangle
  p_border => '1'     -- with outline frame
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 20           -- Height of the line break. 
  );
  
  /* Printcell with left side border */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'PrintCell with Left border',    -- Text in rectangle
  p_border => 'L' -- Left side border ( R - right, T - top, B - bottom)
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
  
  /* Printcell with right side border */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'PrintCell with Right border',   -- Text in rectangle
  p_border => 'R'     -- Right side border
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 15           -- Height of the line break. 
  );
  
/* Printcell with top side border */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'PrintCell with Top border',     -- Text in rectangle
  p_border => 'T'     -- Top side border
  );
  
  
/* Printcell with bottom side border */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Princell with Bottom Side',     -- Text in rectangle
  p_border => 'B'    -- Bottom side border
  );
  
 /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 20           -- Height of the line break. 
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */  
  plpdf.PrintCell(
  p_w => 100,          -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'PrintCell - Cursor positioning after print the cell', -- Text in rectangle
  p_ln => '1'         -- Cursor position after the cell: New Line (Beside the cell - 0, Under the cell - 2 
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */  
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Left',     -- Text in rectangle
  p_border => '1',     -- Border: Outline
  p_align => 'L'      -- Left align
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */  
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Right',     -- Text in rectangle
  p_border => '1',     -- Border: Outline
  p_align => 'R'      -- Right align
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */  
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Center',     -- Text in rectangle
  p_border => '1',     -- Border: Outline
  p_align => 'C'      -- Center align
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
    
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */  
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Force Justification',     -- Text in rectangle
  p_border => '1',     -- Border: Outline
  p_align => 'J'      -- Force Justification
  );
    
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 20           -- Height of the line break. 
  );
  
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */  
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'No fill',  -- Text in rectangle
  p_fill => 0         -- No fill
  );
  
  /* Set the fill color */
  plpdf.SetColor4Filling(
  p_r => 200,     -- Red component code. Number between 0 and 255
  p_g => 200,     -- Green component code. Number between 0 and 255
  p_b => 100      -- Blue component code. Number between 0 and 255
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle with
  p_h => 10,           -- Rectangle height
  p_txt => 'Filled',   -- Text in rectangle
  p_fill => 1     -- Fill with current fill color ( No-fill/default: 0)
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 20           -- Height of the line break. 
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle with
  p_h => 10,           -- Rectangle height
  p_txt => 'This is a real link',   -- Text in rectangle
  p_link => 'http://www.plpdf.com',       -- Can be a URL or an internal link ID
  p_border => '1'                         -- Border: outline
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 15           -- Height of the line break. 
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle with
  p_h => 10,           -- Rectangle height
  p_border => '1',     -- Border outline
  p_txt => 'Clipping off,Clipping off,Clipping off,Clipping off,Clipping off',    -- Text in rectangle
  p_clipping => 0    -- Clipping: no  (default value: 1 - on).
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
  
   /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle with
  p_h => 10,           -- Rectangle height
  p_border => '1',     -- Border outline
  p_txt => 'Clipping on,Clipping on,Clipping on,Clipping on,Clipping on,Clipping on', -- Text in rectangle
  p_clipping => 1    -- Clipping on (default value 1 - on)
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 15           -- Height of the line break. 
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle with
  p_h => 40,           -- Rectangle height
  p_txt => 'Top',      -- Text in rectangle
  p_vert_align =>  'T',           -- Vertical align - Top: T, Bottom: B
  p_border => '1'                 -- Border: outline
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 70,           -- Rectangle with
  p_h => 40,           -- Rectangle height
  p_txt => 'Bottom',   -- Text in rectangle
  p_vert_align => 'B', -- Vertical align - Bottom: B
  p_border => '1'      -- Bortder: outline
  ); 
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_file, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;

/* PRINT_CELL_PRO_EXAMPLE */
  
procedure PrintCellPro is
  l_blob blob;
  
begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Create a new page. Without parameters the default page orientation: portrait. */
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Courier',      -- Font family: Courier
  p_style => null,            -- Font style: Regular
  p_size => 14                -- Font size: 14
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 0,       -- Rectangle with. If 0 then the rectangle will extend till the right margin
  p_h => 15,      -- Rectangle height. 0: uses last cell height, -1: uses minimum cell height
  p_txt => 'PrintCell Pro Example',    -- Text in rectangle
  p_border => 'B',        -- Bottom side border
  p_align => 'C',         -- Horizontal align: Center
  p_vert_align => 'T',    -- Verzical align: Top
  p_ln => 2               -- Cursor position under the cell. (0: Beside the cell, 1: New line)
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 15           -- Height of the line break. 
  );
  
  /* For another cell, set new font properties */
  plpdf.SetPrintFont(
  p_family => 'Courier',      -- Font family: Courier
  p_style => 'I',             -- Font style: Italic
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 0,       -- Rectangle with. If 0 then the rectangle will extend till the right margin
  p_h => 10,      -- Rectangle height. 0: uses last cell height, -1: uses minimum cell height
  p_txt => 'Click this text to visit plpdf.com',    -- Text in rectangle
  p_border => '1',                   -- Outline border
  p_link => 'http://www.plpdf.com'   -- URL or internal link ID
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 15           -- Height of the line break. 
  );
  
  /* Set the fill color */
  plpdf.SetColor4Filling(
  p_r => 137,     -- Red component code. Number between 0 and 255
  p_g => 143,     -- Green component code. Number between 0 and 255
  p_b => 198      -- Blue component code. Number between 0 and 255
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 63,           -- Rectangle with           
  p_h => 80,           -- Rectangle height
  p_txt => 'Sample Text 1',         -- Text in rectangle
  p_border => 'L',      -- Left side border
  p_align => 'L',       -- Horizontal align: Left
  p_fill => '1',        -- Filled cell
  p_vert_align => 'T'   -- Vertical align: Top
  );
  
  /* Set the fill color */
  plpdf.SetColor4Filling(
  p_r => 129,     -- Red component code. Number between 0 and 255
  p_g => 236,     -- Green component code. Number between 0 and 255
  p_b => 124      -- Blue component code. Number between 0 and 255
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 63,           -- Rectangle with           
  p_h => 80,           -- Rectangle height
  p_txt => 'Sample Text 2',         -- Text in rectangle
  p_border => 'LR',     -- Left and Right side border
  p_align => 'C',       -- Horizontal align: Center
  p_fill => '1'         -- Filled
  );
  
  /* Set the fill color */
  plpdf.SetColor4Filling(
  p_r => 255,     -- Red component code. Number between 0 and 255
  p_g => 140,     -- Green component code. Number between 0 and 255
  p_b => 48       -- Blue component code. Number between 0 and 255
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 63,           -- Rectangle with           
  p_h => 80,           -- Rectangle height
  p_txt => 'Sample Text 3',         -- Text in rectangle
  p_align => 'R',       -- Horizontal align: Right
  p_border => 'R',      -- Right border 
  p_fill => '1',        -- Filled
  p_vert_align => 'B',  -- Vertical align: Bottom
  p_ln => 1             -- Cursor position in new line, after print the cell
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 0,            -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'This is another sample text in the document.', -- Text in rectangle
  p_border => 'TB',         -- Top and Bottom border
  p_align => 'C',           -- Horizontal align: Center
  p_ln => 1                 -- Cursor position in new line, after print the cell
  );
  
  /* Cursor is placed at the start of the next line. */
  plpdf.LineBreak(
  p_h => 10           -- Height of the line break. 
  );
  
  /* Set the fill color */
  plpdf.SetColor4Filling(
  p_r => 150,     -- Red component code. Number between 0 and 255
  p_g => 150,     -- Green component code. Number between 0 and 255
  p_b => 150      -- Blue component code. Number between 0 and 255
  );
  
  /* Generate lines with Printcell */
  
  FOR i IN 1..10 LOOP
  
  IF (i MOD 2 = 0) THEN
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 0,            -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_fill => '1',       -- Fill with current fill color ( No-fill/default: 0)
  p_txt => i || '. line', -- Text in rectangle
  p_ln => 1);          -- Cursor position after the cell: New Line (Beside the cell - 0, Under the cell - 2
  
  ELSE
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 0,            -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => i || '. line', -- Text in rectangle
  p_ln => 1            -- Cursor position after the cell: New Line (Beside the cell - 0, Under the cell - 2
  );
  END IF;
  END LOOP;
  
   /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (blob_File, created_date) VALUES (l_blob,sysdate);
  
  commit;
end;


/* SET_ENCODING_EXAMPLE */

procedure SetEncoding is
/*  Sets Adobe Core character encoding (default code is cp1252) */
l_blob blob;  

begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* default code is cp1252 */
  plpdf.SetEncoding(
     p_enc => 'cp1252'  -- Character encoding type
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */      
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => null,            -- Font style: Regular
     p_size => 12                -- Font size: 12
  );
     
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 150,          -- Rectangle width
     p_h => 10,           -- Rectangle height
     p_ln => 1,           -- Cursor position after the cell: New Line (Beside the cell - 0, Under the cell - 2           
     p_txt => 'The character encoding: cp1252'
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 100,       -- Rectangle width           
     p_h => 10,        -- Rectangle height                 
     p_txt => UNISTR('\0171\00ED\00E9\00E1\0151\00FA\00F6\00FC\00F3!')   -- Text in rectangle
  );  

  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (Blob_File,CREATED_DATE) VALUES (l_blob,sysdate);
  commit;
end;

/* SET_ENCODING_EXAMPLE_2 */
procedure SetEncoding2 is

l_blob blob;  

begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /*  Sets Adobe Core character encoding (default code is cp1252) */
  plpdf.SetEncoding(
      p_enc => 'iso-8859-2'  -- Character encoding type 
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => null,            -- Font style: Regular
     p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */   
  plpdf.PrintCell(
     p_w => 150,                 -- Rectangle width
     p_h => 10,                  -- Rectangle height
     p_ln => 1,                  -- Cursor position after the cell: New Line (Beside the cell - 0, Under the cell - 2
     p_txt => 'The character encoding: iso-8859-2'  -- Text in rectangle
  ); 
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 100,           -- Rectangle width      
     p_h => 10,            -- Rectangle height            
     p_txt => UNISTR('\0171\00ED\00E9\00E1\0151\00FA\00F6\00FC\00F3!')   -- Text in rectangle
  );  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (Blob_File,CREATED_DATE) VALUES (l_blob,sysdate);
  commit;
end;

/* SET_PROPERTIES_EXAMPLE */  
procedure SetProperties is
  l_blob blob;
begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Sets the document title */
  plpdf.SetDocTitle(
  p_title => 'MyTitle' -- Document title
  );
  
  /* Sets the document subject */
  plpdf.SetDocSubject(
  p_subject => 'MySubject' -- Document subject
  );
  
  /* Sets the document author */
  plpdf.SetDocAuthor(
  p_author => 'Author name'   -- Document author
  );
  
  /* Sets the document keywords */
  plpdf.SetDocKeywords(
  p_keywords => 'key1, key2, key3' -- Keywords
  );
  
  /* Sets the document creator */
  plpdf.SetDocCreator(
  p_creator => 'Creator name'       -- Document creator
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
  p_w => 150,           -- Rectangle width
  p_h => 10,           -- Rectangle height
  p_txt => 'Document properties example -> see the properties' -- Text in rectangle
  );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB (BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
  commit;
end;
 
/* DISPLAY_MODE_ZOOM_EXAMPLE1 */
procedure DisplayModeZoom1 is
  
  l_blob blob;
begin
  
   /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Sets how to display the document in a PDF viewer  */
  plpdf.SetDocDisplayMode(
  p_zoom => 'fullpage',      -- Layout view: fits as full page
  p_layout => 'continuous'   -- Page layout: displays pages continuously
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */ 
  plpdf.NewPage;
  
 /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'DisplayModeZoom1' -- Text in rectangle 
     );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */   
  plpdf.NewPage;
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page2'        -- Text in rectangle 
     );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */
  plpdf.NewPage;
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page3'        -- Text in rectangle 
     );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
  
  /* Store */  
  insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
commit;
end;

procedure DisplayModeZoom2 is
  
  l_blob blob;
begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Sets how to display the document in a PDF viewer  */
  plpdf.SetDocDisplayMode(
  p_zoom => 'fullwidth',      -- Layout view: fits as full with
  p_layout => 'default'       -- Page layout: displays according to the setting of the PDF viewer
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */ 
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'DisplayModeZoom2' -- Text in rectangle 
     );
  /* Create a new page. Without parameters the default page orientation: portrait. */   
  plpdf.NewPage;
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page2'        -- Text in rectangle 
     );
  /* Create a new page. Without parameters the default page orientation: portrait. */
  plpdf.NewPage;
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page3'        -- Text in rectangle 
     );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
  insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
commit;
end;

procedure DisplayModeZoom3 is
  
  l_blob blob;
begin
   /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Sets how to display the document in a PDF viewer  */
  plpdf.SetDocDisplayMode(
  p_zoom => 'real',      -- Layout view: fits in actual size
  p_layout => 'single'   -- Page layout: displays single pages
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */ 
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'DisplayModeZoom3' -- Text in rectangle 
     );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */   
  plpdf.NewPage;

  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */  
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page2'        -- Text in rectangle 
     );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */
  plpdf.NewPage;
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page3'        -- Text in rectangle 
     );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
  
  /* Store */ 
  insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
commit;
end;

procedure DisplayModeHide1 is
  
  l_blob blob;
begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Sets how to display the document in a PDF viewer  */
  plpdf.SetDocDisplayMode(
  p_zoom => 'fullpage',      -- Layout view: fits as full page
  p_layout => 'continuous',   -- Page layout: displays pages continuously
  p_hidemenubar => true,     -- hide the viewer application's menu bar when the document active
  p_hidetoolbar => true,     -- hide the viewer application's tool bars when the document active
  p_hidewindowui => true     -- hide user interface elements (e.g. scrool bars, navigation controls)
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */ 
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'DisplayModeHide1' -- Text in rectangle 
     );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */   
  plpdf.NewPage;
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page2'        -- Text in rectangle 
     );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */
  plpdf.NewPage;
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page3'        -- Text in rectangle 
     );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
  
  /* Store */ 
  insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
commit;
end;

procedure DisplayModeHide2 is
  
  l_blob blob;
begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
  /* Sets the document title */
  plpdf.SetDocTitle(
  p_title => 'Example Title' -- document title
  );
  
  /* Sets how to display the document in a PDF viewer  */
  plpdf.SetDocDisplayMode(
  p_zoom => 'fullpage',      -- Layout view: fits as full page
  p_layout => 'continuous',   -- Page layout: displays pages continuously
  p_displaydoctitle => true, -- The window's title bar should display the document title taken from the Title entry of the document information dictionary
  p_centerwindow => true,    -- Sets the document's window position int the center of the screen
  p_fitwindow => true        -- Resize the document's window to fit the size of the first displayed page
  );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */ 
  plpdf.NewPage;
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
  p_family => 'Arial',        -- Font family: Arial
  p_style => null,            -- Font style: Regular
  p_size => 12                -- Font size: 12
  );
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'DisplayModeHide2' -- Text in rectangle 
     );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */   
  plpdf.NewPage;
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page2'        -- Text in rectangle 
     );
  
  /* Create a new page. Without parameters the default page orientation: portrait. */
  plpdf.NewPage;
  
  /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
  plpdf.PrintCell(
     p_w => 80,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page3'        -- Text in rectangle 
     );
  
  /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob  -- The generated document
  );
  
  /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
  
  /* Store */ 
  insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
commit;
end;

/* HEADER_FOOTER EXAMPLE */
procedure HeaderFooter is
  
l_blob blob;

begin
  /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
   /* Defines the page number alias. 
       Default: {nb} */
   plpdf.nopAlias;
   
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
   plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.header1',    -- Page header procedure name: xheader
     p_height => 10               -- Height of header section
     );
   
     /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
   plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.footer1',    --Page footer procedure name: xfooter
     p_height => 10               --Height of footer section
     ); 
     
     /* Create a new page. Without parameters the default page orientation: portrait. */
     plpdf.NewPage;
     
     /* Sets the font properties */
     plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => null,            -- Font style: Regular
     p_size => 12                -- Font size: 12
     );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 50,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page 1'       -- Text in rectangle 
     );
     
     /* Create a new page. Without parameters the default page orientation: portrait. */
     plpdf.NewPage; 
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */ 
     plpdf.PrintCell(
     p_w => 50,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page 2'       -- Text in rectangle 
     );
     
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
      
    /* Print it:
        
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
      
    /* Store */ 
  insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
  commit;
end;

procedure HeaderFooter1 is
  
l_blob blob;

begin
   /* Initializes generator program variables. 
       Default parameter values: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
  plpdf.Init;
  
   /* Defines the page number alias. 
       Default: {nb} */
   plpdf.nopAlias(
   p_alias => '{nb}',
   p_cp_alias => '{cp}',
   p_format => '{cp}/{nb}'
   );    
   
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
   plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.header1',    -- Page header procedure name: xheader
     p_height => 10               -- Height of header section
     );
   
     /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
   plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.footer1',    --Page footer procedure name: xfooter
     p_height => 10               --Height of footer section
     ); 
     
     /* Create a new page. Without parameters the default page orientation: portrait. */
     plpdf.NewPage;
     
     /* Sets the font properties */
     plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => null,        -- Font style: regular (default)
     p_size => 12            -- Font size: 12 pt
     ); 
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 50,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page 1'       -- Text in rectangle 
     );
     
     /* Create a new page. Without parameters the default page orientation: portrait. */
     plpdf.NewPage; 
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 50,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Page 2'       -- Text in rectangle 
     );
     
      /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
      
    /* Print it:
        
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
      
    /* Store */ 
  insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
  commit;
end;

procedure header1 is
begin
  
  /* Sets the font properties */
  plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => null,        -- Font style: regular (default)
     p_size => 12            -- Font size: 12 pt
     ); 
    
    /* Page title */
 
    /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 0,                          -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page Title',             -- Text in rectangle 
     p_border => '0',                   -- Without frame
     p_ln => '0',                       -- Cursor position after the cell is printed: Beside  
     p_align => 'C'                     -- Text alignment: Center
     );   
   
    /* Line break. */
    plpdf.LineBreak(
     p_h => 20                          --Height of the line break.
     );
end;

procedure footer1 is
begin
 
  /* Sets the font properties */
  plpdf.SetPrintFont(
     p_family => 'Arial',             -- Font family: Arial
     p_style => 'I',                  -- Font style: Italic
     p_size => 8                      -- Font size: 8 pt
     ); 
     
   /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 0,                        -- Rectangle width
     p_h => 10,                       -- Rectangle heigth
     p_txt => to_char(plpdf.CurrentPageNumber) || '/{nb}', -- Text in rectangle 
     p_border => '0',                 -- Without frame
     p_ln => '0',                     -- Cursor position after the cell is printed: Beside  
     p_align => 'C'                   -- Text alignment: Center
     );  
  
end;

procedure SetMargin is
  l_blob blob;
  begin
   /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
   plpdf.init;
   
    /* Sets the margin size. */
    plpdf.SetAllMargin(
     p_left => 30, -- Left margin: 30mm
     p_top => 40,  -- Top margin: 40mm
     p_right => 50 -- Right margin: 50mm
     ); 

    /* Create a new page. Without parameters the default page orientation: portrait. */ 
    plpdf.NewPage;
     
    /* Sets the font properties */
    plpdf.SetPrintFont(
     p_family => 'Arial', -- Font family: Arial
     p_style => null,     -- Font style: regular (default)
     p_size => 12         -- Font size: 12 pt
     );
     
    /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,              -- Rectangle width
     p_h => 10,              -- Rectangle heigth
     p_txt => 'Set margins example cell 1', -- Text in rectangle
     p_ln => 1,    -- Cursor position after the cell: New Line (Beside the cell - 0, Under the cell - 2
     p_border => '1'  -- Border: outline
     ); 
    
    /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_txt => 'Set margins example cell 2',      -- Text in rectangle
    p_border => '1'       -- Border: outline
    );
    
    /* Sets the margin size. */
    plpdf.SetAllMargin(
    p_left => 10, -- Left margin: 10mm
    p_top => 10,  -- Top margin: 10mm
    p_right => 10 -- Right margin: 10mm
    );
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_border => '1',     -- Border: outline
    p_txt => 'New page with new margins'        -- Text in rectangle
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
      
    /* Print it:
        
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
      
    /* Store */ 
     insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
     commit;
           
  end;

procedure SetCellMargins is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the cell bottom margin size. */
    plpdf.SetCellBottomMargin(
    p_margin => 10   -- Margin size
    );
    /* Sets the cell left margin size. */
    plpdf.SetCellLeftMargin(
    p_margin => 40   -- Margin size
    );
    /* Sets the cell right margin size. */
    plpdf.SetCellRightMargin(
    p_margin => 20   -- Margin size
    );
    /* Sets the cell Top margin size. */
    plpdf.SetCellTopMargin(
    p_margin => 5    -- Margin size
    );
    
     /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => 'I',                    -- Font style: Italic
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle width
    p_h => 30,           -- Rectangle height
    p_border => '1',     -- Border: outline
    p_txt => 'All cell margin is different.'    -- Text in rectangle
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the cell margin size. */
    plpdf.SetCellMargin(
    p_margin => 15   -- Margin size
    );
    
     /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => 'I',                    -- Font style: Italic
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle width
    p_h => 40,           -- Rectangle height
    p_border => '1',     -- Border: outline
    p_txt => 'Cell margins: 40'     -- Text in rectangle
    );

    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure SetMarginsValue is
  l_blob blob;
  
  begin
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Sets the top margin size. */
    plpdf.SetTopMargin(
    p_margin => 40  -- Margin size
    );
    
    /* Sets the left margin size. */
    plpdf.SetLeftMargin(
    p_margin => 40 -- Margin size
    );
    
    /* Sets the right margin size */
    plpdf.SetRightMargin(
    p_margin => 40 -- Margin size
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_txt => 'Margins : 40',          -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure SetTextColor is
  l_blob blob;
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
         
    /* Sets the font properties */
    plpdf.SetPrintFont(
     p_family => 'Arial', -- Font family: Arial
     p_style => null,     -- Font style: regular (default)
     p_size => 12         -- Font size: 12 pt
     );
         
    /* Set text Color */
    plpdf.SetColor4Text(
        p_r => 165,           -- Red component code, can be between 0 and 255
        p_g => 10,            -- Green component code, can be between 0 and 255
        p_b => 70             -- Blue component code, can be between 0 and 255
     );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 50,             -- Rectangle width
     p_h => 10,             -- Rectangle heigth
     p_txt => 'Color text' -- Text in rectangle 
     ); 
     
     /* Cursor is placed at the start of the next line. */
     plpdf.LineBreak(
     p_h => 20           -- Height of the line break. 
     );
	
    /* Sets the text color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet. 
     - p_g: -1 (default)
     - p_b: -1 (default) */
    plpdf.SetColor4Text(
     p_r => 0               -- Red component code: 0 (black)
     );                     
	
    /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,             -- Rectangle width
     p_h => 10,             -- Rectangle heigth
     p_txt => 'Color text2' -- Text in rectangle 
     );
     
     /* Cursor is placed at the start of the next line. */
     plpdf.LineBreak(
     p_h => 20           -- Height of the line break. 
     );
     
     /* Sets the text color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet. */
     plpdf.SetColor4Text(
        p_r => 39,           -- Red component code, can be between 0 and 255
        p_g => 200,          -- Green component code, can be between 0 and 255
        p_b => 150           -- Blue component code, can be between 0 and 255
     );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
     plpdf.PrintCell(
     p_w => 50,             -- Rectangle width
     p_h => 10,             -- Rectangle heigth
     p_txt => 'Color text3' -- Text in rectangle 
     );  
     
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
        
      /* Print it:
          
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
        
      /* Store */
         insert into STORE_BLOB (BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
         commit;
  end;
  
procedure SetFillColor is
  l_blob blob;
  begin 
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
      
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
      
   /* Sets the font properties */
    plpdf.SetPrintFont(
     p_family => 'Arial', -- Font family: Arial
     p_style => null,     -- Font style: regular (default)
     p_size => 12         -- Font size: 12 pt
     );
     
   /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
   plpdf.PrintCell(
   p_w => 50,             -- Rectangle width
   p_h => 10,             -- Rectangle heigth
   p_txt => 'SetFillColor', -- Text in rectangle
   p_ln => 1              -- Cursor position after the cell is printed 
   );  
    
    /* Sets the fill color for objects inserted after this statement. */
    plpdf.SetColor4Filling(
    p_r => 20,      -- Red component code, can be between 0 and 255
    p_g => 100,     -- Green component code, can be between 0 and 255
    p_b => 200      -- Blue component code, can be between 0 and 255
    ); 
    
    /* Draws a rectangle on the page. */
    plpdf.DrawRect(
    p_x => 20,           -- X coordinate for the top left corner of the rectangle
    p_y => 20,           -- Y coordinate for the top left corner of the rectangle
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_style => 'F'       -- Style: Filled, no border
    );
    
    /* Sets the fill color for objects inserted after this statement. */
    plpdf.SetColor4Filling(
    p_r => 110,      -- Red component code, can be between 0 and 255
    p_g => 90,     -- Green component code, can be between 0 and 255
    p_b => 150      -- Blue component code, can be between 0 and 255
    );
    
    /* Draws a rectangle on the page. */
    plpdf.DrawRect(
    p_x => 20,           -- X coordinate for the top left corner of the rectangle
    p_y => 40,           -- Y coordinate for the top left corner of the rectangle
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_style => 'F'       -- Style: Filled, no border
    );
    
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
        
      /* Print it:
          
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
        
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES(l_blob,sysdate);
    commit;
    end;

procedure SetDrawColor is
  l_blob blob;
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the line color for objects (line, rectangle, circle etc.) inserted after this statement. */
    plpdf.SetColor4Drawing(
    p_r => 255,      -- Red component code, can be between 0 and 255
    p_g => 50,     -- Green component code, can be between 0 and 255
    p_b => 50      -- Blue component code, can be between 0 and 255
    );
    
      /* Draws a rectangle on the page. */
    plpdf.DrawRect(
    p_x => 20,           -- X coordinate for the top left corner of the rectangle
    p_y => 20,           -- Y coordinate for the top left corner of the rectangle
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_style => 'D'       -- Style: border line, no fill
    );
    
    /* Sets the fill color for objects inserted after this statement. */
    plpdf.SetColor4Drawing(
    p_r => 50,      -- Red component code, can be between 0 and 255
    p_g => 255,     -- Green component code, can be between 0 and 255
    p_b => 50      -- Blue component code, can be between 0 and 255
    );
    
    /* Draws a rectangle on the page. */
    plpdf.DrawRect(
    p_x => 20,           -- X coordinate for the top left corner of the rectangle
    p_y => 40,           -- Y coordinate for the top left corner of the rectangle
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_style => 'D'       -- Style: Filled, no border
    );
    
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
        
      /* Print it:
          
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
        
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES(l_blob,sysdate);
    commit;
    end;

procedure GetTextWidth is
  l_blob blob;
  l_length number;
  l_text varchar2(255);
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
     plpdf.Init;
     
     /* Create a new page. Without parameters the default page orientation: portrait. */    
     plpdf.NewPage;
     
         
     /* Sets the font properties */
     plpdf.SetPrintFont(
       p_family => 'Arial', -- Font family: Arial
       p_style => null,     -- Font style: regular (default)
       p_size => 12         -- Font size: 12 pt
     );
         
     l_text := 'This is the text.';
     /* function plpdf.GetTextWidth: 
        Returns the width of the parameter text. 
        The width of the text in the unit of measure specified in plpdf.Init */
     l_length:= plpdf.GetTextWidth(
                p_s => l_text      -- Parameter text
                );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */    
     plpdf.PrintCell(
     p_w => 0,            -- Rectangle width
     p_h => 10,           -- Rectangle height
     p_txt => l_text || ' - text length: ' || to_char(l_length),   -- Text in rectangle
     p_ln => 1       -- -- Cursor position under the cell. (0: Beside the cell, 1: New line)
     ); 
         
     l_text := 'This is the longer text.';
     l_length := plpdf.GetTextWidth(
              p_s => l_text -- Parameter text
              );
     
     /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */             
     plpdf.PrintCell(
     p_w => 0,            -- Rectangle width
     p_h => 10,           -- Rectangle height
     p_txt => l_text || ' - text length ' || to_char(l_length) -- Text in rectangle
     );
         
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
     insert into STORE_BLOB (BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
     commit;
  end;
  
procedure DrawLine is
  l_blob blob;
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
    p_x1 => 10,        -- X coordinate for the start of the line
    p_y1 => 10,        -- Y coordinate for the start of the line
    p_x2 => 10,        -- X coordinate for the end of the line
    p_y2 => 50         -- Y coordinate for the end of the line
    );
    
    /* Sets the line color for objects (line, rectangle, circle etc.) 
       inserted after this statement. */
    plpdf.SetColor4Drawing(
     p_r => 200,        -- Red component code, can be between 0 and 255
     p_g => 100,        -- Green component code, can be between 0 and 255
     p_b => 50          -- Blue component code, can be between 0 and 255
     ); 
	
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
     p_x1 => 20,        -- X coordinate for the start of the line
     p_y1 => 10,        -- Y coordinate for the start of the line
     p_x2 => 20,        -- X coordinate for the end of the line
     p_y2 => 50         -- Y coordinate for the end of the line
     ); 
       
    /* Sets the line color for objects (line, rectangle, circle etc.) 
       inserted after this statement. 
     - r_g: -1 (default)
     - r_b: -1 (default) */
    plpdf.SetColor4Drawing(
     p_r => 0           -- Red component code: 0 (black)
     ); 
        
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
     p_x1 => 30,        -- X coordinate for the start of the line
     p_y1 => 10,        -- Y coordinate for the start of the line
     p_x2 => 30,        -- X coordinate for the end of the line
     p_y2 => 50         -- Y coordinate for the end of the line
     ); 

    /* Sets the thickness of lines drawn after this statement. If
      no thickness is set then it is 0.2 mm by default. */
    plpdf.SetLineWidth(
     p_width => 0.4     -- Line width: 0.4 mm
     ); 
	
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
     p_x1 => 40,        -- X coordinate for the start of the line
     p_y1 => 10,        -- Y coordinate for the start of the line
     p_x2 => 40,        -- X coordinate for the end of the line
     p_y2 => 50         -- Y coordinate for the end of the line
     ); 
	
    /* Sets the line color for objects (line, rectangle, circle etc.) 
       inserted after this statement. */
    plpdf.SetColor4Drawing(
     p_r => 190,        -- Red component code, can be between 0 and 255
     p_g => 240,        -- Green component code, can be between 0 and 255
     p_b => 220         -- Blue component code, can be between 0 and 255
     );
    
    /* Sets the thickness of lines drawn after this statement. If
      no thickness is set then it is 0.2 mm by default. */  
    plpdf.SetLineWidth(
    p_width => 1.2      -- Line with 1.2 mm
    );  
      
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
     p_x1 => 50,        -- X coordinate for the start of the line
     p_y1 => 10,        -- Y coordinate for the start of the line
     p_x2 => 50,        -- X coordinate for the end of the line
     p_y2 => 50         -- Y coordinate for the end of the line
     );
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
    p_x1 => 10,     -- X coordinate for the start of the line
    p_y1 => 60,     -- Y coordinate for the start of the line
    p_x2 => 60,     -- X coordinate for the end of the line
    p_y2 => 80      -- Y coordinate for the end of the line
    );
    
    /* Sets the line color for objects (line, rectangle, circle etc.) 
       inserted after this statement. */
    plpdf.SetColor4Drawing(
    p_r => 50,        -- Red component code, can be between 0 and 255
    p_g => 140,       -- Green component code, can be between 0 and 255
    p_b => 200        -- Blue component code, can be between 0 and 255
    );
    
    /* Sets the thickness of lines drawn after this statement. If
      no thickness is set then it is 0.2 mm by default. */
    plpdf.SetLineWidth(
    p_width => 0.8    -- Line with 0.8 mm
    );
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
    p_x1 => 10,     -- X coordinate for the start of the line
    p_y1 => 80,     -- Y coordinate for the start of the line
    p_x2 => 60,     -- X coordinate for the end of the line
    p_y2 => 60      -- Y coordinate for the end of the line
    );
   
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
    end;

procedure DrawRect is
  l_blob blob;
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    for i in 1..20 loop
      
    /* Sets the line color for objects (line, rectangle, circle etc.) 
       inserted after this statement. */
    plpdf.SetColor4Drawing(
     p_r => i*13-10,      -- Red component code, can be between 0 and 255
     p_g => 255-(i*12),   -- Green component code, can be between 0 and 255
     p_b => 0             -- Blue component code, can be between 0 and 255
     ); 
  	
    /* Draws a rectangle on the page */  
    plpdf.DrawRect(
     p_x => 30-i,         -- X coordinate for the top left corner of the rectangle
     p_y => 30-i,         -- Y coordinate for the top left corner of the rectangle
     p_w => 2*i,          -- The width of the rectangle
     p_h => 2*i,          -- The height of the rectangle
     p_style => 'D'       -- Style: No fill, border line
     );
       
    end loop;    
	
    /* Sets the line color for objects (line, rectangle, circle etc.) 
       inserted after this statement.
     - p_g: -1 (default)
     - p_b: -1 (default) */
    plpdf.SetColor4Drawing(
     p_r => 0               -- Red component code: 0 (black)
     );    
	
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 100,            -- Red component code, can be between 0 and 255
     p_g => 100,            -- Green component code, can be between 0 and 255
     p_b => 240             -- Blue component code, can be between 0 and 255
     ); 
    
    /* Draws a rectangle on the page */  	
    plpdf.DrawRect(
     p_x => 100,             -- X coordinate for the top left corner of the rectangle
     p_y => 10,             -- Y coordinate for the top left corner of the rectangle
     p_w => 50,             -- The width of the rectangle
     p_h => 50,             -- The height of the rectangle
     p_style => 'DF'        -- Style: fill, border line
     );
     
     
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
    
    end;

procedure DrawEllipseCircle is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font properties */
     plpdf.SetPrintFont(
       p_family => 'Arial', -- Font family: Arial
       p_style => null,     -- Font style: regular (default)
       p_size => 12         -- Font size: 12 pt
     );
    
    /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_txt => 'DrawCircleEllipse'      -- Text in rectangle
    );
    
    /* Draws an ellipse on the current page - style: draw (default) */
    plpdf.DrawEllipse(
    p_x => 30, -- X coordinate of the center of the ellipse
    p_y => 30, -- Y coordinate of the center of the ellipse
    p_rx => 20, -- Horizontal radius of the ellipse
    p_ry => 10 -- Vertical radius of the ellipse
    ); 
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/    
    plpdf.SetColor4Filling(
     p_r => 101,              -- Red component code, can be between 0 and 255
     p_g => 111,              -- Green component code, can be between 0 and 255
     p_b => 255             -- Blue component code, can be between 0 and 255
     ); 
    
    /* Draws an ellipse on the current page - style: draw (default) */    
    plpdf.DrawEllipse(
    p_x => 60,  -- X coordinate of the center of the ellipse
    p_y => 60,  -- Y coordinate of the center of the ellipse
    p_rx => 30, -- Horizontal radius of the ellipse
    p_ry => 10,  -- Vertical radius of the ellipse
    p_style => 'F'  -- -- Style: Fill and border line
    );
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/    
    plpdf.SetColor4Filling(
     p_r => 0,              -- Red component code, can be between 0 and 255
     p_g => 0,              -- Green component code, can be between 0 and 255
     p_b => 255             -- Blue component code, can be between 0 and 255
     ); 
     
    /* Draws a circle on the current page */
    plpdf.Drawcircle(
    p_x => 100, -- X coordinate of the center of the circle
    p_y => 100, -- Y coordinate of the center of the circle
    p_r => 10,  -- The radius of the circle
    p_style => 'F' -- Style: Fill 
    );
    
    /* Draws a circle on the current page */
    plpdf.DrawCircle(
    p_x => 120,     -- X coordinate of the center of the circle
    p_y => 100,     -- Y coordinate of the center of the circle
    p_r => 10,      -- The radius of the circle
    p_style => 'D' -- Style: border line
    );
    
    /* Draws a circle on the current page */
    plpdf.DrawCircle(
    p_x => 110,     -- X coordinate of the center of the circle
    p_y => 120,     -- Y coordinate of the center of the circle
    p_r => 10,      -- The radius of the circle
    p_style => 'DF' -- Style: Fill and border line
    ); 		
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;  

procedure DrawSector is
  l_blob blob;
  l_xc number;
  l_yc number;
  l_r number;
  
  begin
    /* Initialize, without parameters means:  
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    l_xc := 105;    -- Abscissa of the center
    l_yc := 105;     -- Ordinate of the center
    l_r := 50;      -- Radius
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 120,    -- Red component code, can be between 0 and 255
     p_g => 120,    -- Green component code, can be between 0 and 255
     p_b => 255     -- Blue component code, can be between 0 and 255
     );
     
    /* Draws a sector on the current page. */
    plpdf.DrawSector(
     p_xc => l_xc,  -- X coordinate of the center of the sector
     p_yc => l_yc,  -- Y coordinate of the center of the sector
     p_r => l_r,    -- Radius of the sector
     p_a => 20,     -- Starting point of the sector
     p_b => 100     -- End point of the sector
     ); 
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 120,    -- Red component code, can be between 0 and 255
     p_g => 255,    -- Green component code, can be between 0 and 255
     p_b => 120     -- Blue component code, can be between 0 and 255
     );
    
    /* Draws a sector on the current page. */
    plpdf.DrawSector(
     p_xc => l_xc,  -- X coordinate of the center of the sector
     p_yc => l_yc,  -- Y coordinate of the center of the sector
     p_r => l_r,    -- Radius of the sector
     p_a => 100,    -- Starting point of the sector
     p_b => 200     -- End point of the sector
     ); 
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 255,    -- Red component code, can be between 0 and 255
     p_g => 120,    -- Green component code, can be between 0 and 255
     p_b => 120     -- Blue component code, can be between 0 and 255
     );
    
    /* Draws a sector on the current page. */
    plpdf.DrawSector(
     p_xc => l_xc,  -- X coordinate of the center of the sector
     p_yc => l_yc,  -- Y coordinate of the center of the sector
     p_r => l_r,    -- Radius of the sector
     p_a => 200,    -- Starting point of the sector
     p_b => 255      --End point of the sector
     ); 
     
     /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
     plpdf.SetColor4Filling(
     p_r => 100,   -- Red component code, can be between 0 and 255
     p_g => 123,   -- Green component code, can be between 0 and 255
     p_b => 170    -- Blue component code, can be between 0 and 255
     );
     
     /* Draws a sector on the current page. */
     plpdf.DrawSector(
     p_xc => l_xc,    -- X coordinate of the center of the sector
     p_yc => l_yc,    -- Y coordinate of the center of the sector
     p_r => l_r,      -- Radius of the sector      
     p_a => 255,      -- Starting point of the sector
     p_b => 299        --End point of the sector
     );
     
     /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
     plpdf.SetColor4Filling(
     p_r => 200,   -- Red component code, can be between 0 and 255
     p_g => 180,   -- Green component code, can be between 0 and 255
     p_b => 170    -- Blue component code, can be between 0 and 255
     );
     
     /* Draws a sector on the current page. */
     plpdf.DrawSector(
     p_xc => l_xc,    -- X coordinate of the center of the sector
     p_yc => l_yc,    -- Y coordinate of the center of the sector
     p_r => l_r,      -- Radius of the sector      
     p_a => 299,      -- Starting point of the sector
     p_b => 20        --End point of the sector
     );
     
    l_xc := 120;    -- Abscissa of the center
    l_yc := 200;     -- Ordinate of the center
    l_r := 30;      -- Radius
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 120,    -- Red component code, can be between 0 and 255
     p_g => 120,    -- Green component code, can be between 0 and 255
     p_b => 255     -- Blue component code, can be between 0 and 255
     );
     
    /* Draws a sector on the current page. */
    plpdf.DrawSector(
     p_xc => l_xc,  -- X coordinate of the center of the sector
     p_yc => l_yc,  -- Y coordinate of the center of the sector
     p_r => l_r,    -- Radius of the sector
     p_a => 20,     -- Starting point of the sector
     p_b => 100,     -- End point of the sector
     p_style => 'F'  -- Style F - Filled no border, Default FD
     ); 
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 120,    -- Red component code, can be between 0 and 255
     p_g => 255,    -- Green component code, can be between 0 and 255
     p_b => 120     -- Blue component code, can be between 0 and 255
     );
    
    /* Draws a sector on the current page. */
    plpdf.DrawSector(
     p_xc => l_xc,  -- X coordinate of the center of the sector
     p_yc => l_yc,  -- Y coordinate of the center of the sector
     p_r => l_r,    -- Radius of the sector
     p_a => 100,    -- Starting point of the sector
     p_b => 200,     -- End point of the sector
     p_style => 'F'  --Style F - Filled no border, Default FD
     ); 
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 255,    -- Red component code, can be between 0 and 255
     p_g => 120,    -- Green component code, can be between 0 and 255
     p_b => 120     -- Blue component code, can be between 0 and 255
     );
    
    /* Draws a sector on the current page. */
    plpdf.DrawSector(
     p_xc => l_xc,  -- X coordinate of the center of the sector
     p_yc => l_yc,  -- Y coordinate of the center of the sector
     p_r => 40,    -- Radius of the sector
     p_a => 200,    -- Starting point of the sector
     p_b => 255,      --End point of the sector
     p_style => 'F',   -- Style F - Filled no border, Default FD
     p_cw => false,    -- Draw direction: Anti-clockwise
     p_o => 30        -- origin of angles
     ); 
     
     /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
     plpdf.SetColor4Filling(
     p_r => 100,   -- Red component code, can be between 0 and 255
     p_g => 123,   -- Green component code, can be between 0 and 255
     p_b => 170    -- Blue component code, can be between 0 and 255
     );
     
     /* Draws a sector on the current page. */
    plpdf.DrawSector(
     p_xc => l_xc,  -- X coordinate of the center of the sector
     p_yc => l_yc,  -- Y coordinate of the center of the sector
     p_r => l_r,    -- Radius of the sector
     p_a => 255,    -- Starting point of the sector
     p_b => 20,      --End point of the sector
     p_style => 'F'  -- Style F - Filled no border, Default FD
     );  
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
 end; 

procedure DashPattern is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
     p_x1 => 20,        -- X coordinate for the start of the line
     p_y1 => 20,        -- Y coordinate for the start of the line
     p_x2 => 100,       -- X coordinate for the end of the line
     p_y2 => 20         -- Y coordinate for the end of the line
     ); 
    
    /* Sets the dash pattern for lines inserted after thisstatement. */
    plpdf.SetDashPattern(
     p_line => 5,       -- Length of dashes
     p_noline => 2      -- length of gaps
     ); 
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
     p_x1 => 20,        -- X coordinate for the start of the line
     p_y1 => 40,        -- Y coordinate for the start of the line
     p_x2 => 100,       -- X coordinate for the end of the line
     p_y2 => 40         -- Y coordinate for the end of the line
     ); 
   
    /* Sets the thickness of lines drawn after this statement. */
    plpdf.SetLineWidth(
     p_width => 1       -- Line thickness: 1mm
     ); 
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
     p_x1 => 20,        -- X coordinate for the start of the line
     p_y1 => 60,        -- Y coordinate for the start of the line
     p_x2 => 100,       -- X coordinate for the end of the line
     p_y2 => 60         -- Y coordinate for the end of the line
     ); 
    
    /* Sets the dash pattern for lines inserted after thisstatement.
       Call the procedure without parameter to restore normal drawing. */
    plpdf.SetDashPattern();
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
     p_x1 => 20,        -- X coordinate for the start of the line
     p_y1 => 80,        -- Y coordinate for the start of the line
     p_x2 => 100,       -- X coordinate for the end of the line
     p_y2 => 80         -- Y coordinate for the end of the line
     ); 
    
    /* Sets the dash pattern for lines inserted after thisstatement.
       Call the procedure without parameter to restore normal drawing. */
    plpdf.SetDashPattern(
    p_line => 4,          -- Length of dashes
    p_noline => 2         -- length of gaps
    );
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
    p_x1 => 20,     -- X coordinate for the start of the line
    p_y1 => 100,    -- Y coordinate for the start of the line
    p_x2 => 200,    -- X coordinate for the end of the line
    p_y2 => 100     -- Y coordinate for the end of the line
    );
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
    p_x1 => 200,    -- X coordinate for the start of the line
    p_y1 => 100,    -- Y coordinate for the start of the line
    p_x2 => 200,    -- X coordinate for the end of the line
    p_y2 => 150     -- Y coordinate for the end of the line
    );
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
    p_x1 => 200,    -- X coordinate for the start of the line
    p_y1 => 150,    -- Y coordinate for the start of the line
    p_x2 => 20,     -- X coordinate for the end of the line
    p_y2 => 150     -- Y coordinate for the end of the line
    );
    
    /* Draws a line between the two positions on the page. */
    plpdf.DrawLine(
    p_x1 => 20,     -- X coordinate for the start of the line
    p_y1 => 150,    -- Y coordinate for the start of the line
    p_x2 => 20,     -- X coordinate for the end of the line
    p_y2 => 100     -- Y coordinate for the end of the line
    );

     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure DrawPolygon is
  
  l_blob blob;
  l_points plpdf_type.t_points;
  
  begin
    
    for l_i in 1..10 loop
      /* Generates random coordinates */
      l_points(l_i).x := dbms_random.value(15,120);
      l_points(l_i).y := dbms_random.value(15,120);
    end loop;
    
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
     /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
    p_r => 160,    -- Red component code, can be between 0 and 255
    p_g => 180,    -- Green component code, can be between 0 and 255
    p_b => 200     -- BLue component code, can be between 0 and 255
    );
    
    /* Draws a lines (polygon) between the points on the page. */
    plpdf.DrawPolygon(
     p_points => l_points, -- set of ordered points
     p_style => 'F'        -- Fill, no border line
     );
     
     /* Cursor is placed at the start of the next line. */
     plpdf.LineBreak(
 	    p_h => 20         -- Height of the line break. 
      );
     
     for l_i in 1..10 loop
      /* Generates random coordinates */
      l_points(l_i).x := dbms_random.value(120,200);
      l_points(l_i).y := dbms_random.value(15,120);
    end loop;
     
     plpdf.DrawPolygon(
     p_points => l_points -- set of ordered points
     );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob     -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close;   
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure Pattern is
  l_blob blob;
  
  l_points plpdf_type.t_points;
  
  begin
    
    for l_i in 1..6 loop
      /* Generates random coordinates */
      l_points(l_i).x := dbms_random.value(1,7);
      l_points(l_i).y := dbms_random.value(1,7);
    end loop;
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create pattern: line */
    
    /* Starts of define a �Tilling Pattern�. 
       Tiling patterns consist of a small graphical figure 
       (called a pattern cell) that is replicated at fixed 
       horizontal and vertical intervals to fill the area to
       be painted.*/
    plpdf.CrTillingPattern(
     p_name => 'line',          -- Name of pattern
     p_width => 5,              -- Width of pattern 
     p_height => 5              -- Height of pattern
     );
    
    /* Add a line to the pattern. */   
    plpdf.AddLine2Pattern(
     p_name => 'line',          -- Name of pattern
     p_x1 => 0,                 -- X coordinate for the start of the line 
     p_y1 => 0,                 -- Y coordinate for the start of the line
     p_x2 => 5,                 -- X coordinate for the end of the line
     p_y2 => 5                  -- Y coordinate for the end of the line
     );

    /* Create pattern: chequer */
  
    /* Starts of define a �Tilling Pattern�. */
    plpdf.CrTillingPattern(
     p_name => 'chequer',       -- Name of pattern
     p_width => 4,              -- Width of pattern 
     p_height => 4              -- Height of pattern
     );
    
    /* Add a rectangle to the pattern. */ 
    plpdf.AddRect2Pattern(
     p_name => 'chequer',       -- Name of pattern
     p_x => 0,                  -- X coordinate for the top left corner of the rectangle
     p_y => 0,                  -- Y coordinate for the top left corner of the rectangle
     p_w => 2,                  -- The width of the rectangle
     p_h => 2,                  -- The height of the rectangle
     p_style => 'F'             -- Style: Fill
     );
    
    /* Add a rectangle to the pattern. */ 
    plpdf.AddRect2Pattern(
     p_name => 'chequer',       -- Name of pattern
     p_x => 2,                  -- X coordinate for the top left corner of the rectangle
     p_y => 2,                  -- Y coordinate for the top left corner of the rectangle
     p_w => 2,                  -- The width of the rectangle
     p_h => 2,                  -- The height of the rectangle
     p_style => 'F'             -- Style: Fill
     );

    /* Create pattern: halfchequer */
	  
    /* Starts of define a �Tilling Pattern�. */
    plpdf.CrTillingPattern(
     p_name => 'halfchequer',   -- Name of pattern
     p_width => 4,              -- Width of pattern 
     p_height => 4              -- Height of pattern
     );
               
     /* Add a rectangle to the pattern. */ 
    plpdf.AddRect2Pattern(
     p_name => 'halfchequer',   -- Name of pattern
     p_x => 0,                  -- X coordinate for the top left corner of the rectangle
     p_y => 0,                  -- Y coordinate for the top left corner of the rectangle
     p_w => 2,                  -- The width of the rectangle
     p_h => 2,                  -- The height of the rectangle
     p_style => 'F'             -- Style: Fill
     );     

    /* Add a rectangle to the pattern. */ 
    plpdf.AddRect2Pattern(
     p_name => 'halfchequer',   -- Name of pattern
     p_x => 2,                  -- X coordinate for the top left corner of the rectangle
     p_y => 2,                  -- Y coordinate for the top left corner of the rectangle
     p_w => 2,                  -- The width of the rectangle
     p_h => 2,                  -- The height of the rectangle
     p_style => 'D'             -- Style: No fill, border line
     );
     
    /* Create pattern: circle */

    /* Starts of define a �Tilling Pattern�. */
    plpdf.CrTillingPattern(
     p_name => 'circle',        -- Name of pattern
     p_width => 5,              -- Width of pattern 
     p_height => 5              -- Height of pattern
     ); 
    
    /* Add a circle to the pattern. */ 
    plpdf.AddCircle2Pattern(
     p_name => 'circle',        -- Name of pattern
     p_x => 5/2,                -- X coordinate of the center of the circle
     p_y => 5/2,                -- Y coordinate of the center of the circle
     p_r => 2,                  -- The radius of the circle
     p_style => 'D'             -- Style: No fill, border line
     );
    
    /* Add a circle to the pattern. */ 
    plpdf.AddCircle2Pattern(
     p_name => 'circle',        -- Name of pattern
     p_x => 0,                  -- X coordinate of the center of the circle
     p_y => 5/2,                -- Y coordinate of the center of the circle
     p_r => 2,                  -- The radius of the circle
     p_style => 'D'             -- Style: No fill, border line
     );
    
    /* Add a circle to the pattern. */ 
    plpdf.AddCircle2Pattern(
     p_name => 'circle',        -- Name of pattern
     p_x => 5,                  -- X coordinate of the center of the circle
     p_y => 5/2,                -- Y coordinate of the center of the circle
     p_r => 2,                  -- The radius of the circle
     p_style => 'D'             -- Style: No fill, border line
     );
     
     /* Create pattern: Ellipse */

    /* Starts of define a �Tilling Pattern�. */
     plpdf.CrTillingPattern(
     p_name => 'ellipse', -- Name of pattern
     p_width => 5,        -- Width of pattern 
     p_height => 5        -- Height of pattern
     );
     
     /* Add a ellipse to the pattern. */
     plpdf.AddEllipse2Pattern(
     p_name => 'ellipse',    -- Name of pattern
     p_x => 5,               -- X coordinate of the center of the circle
     p_y => 5/2,             -- Y coordinate of the center of the circle
     p_rx => 3,              -- Horizontal radius of the ellipse
     p_ry => 1,              -- Vertical radius of the ellipse
     p_style => 'F'          -- Style: Fill, no border line
     );
     
     /* Add a ellipse to the pattern. */
     plpdf.AddEllipse2Pattern(
      p_name => 'ellipse',    -- Name of pattern
     p_x => 0,               -- X coordinate of the center of the circle
     p_y => 5/2,             -- Y coordinate of the center of the circle
     p_rx => 3,              -- Horizontal radius of the ellipse
     p_ry => 1,              -- Vertical radius of the ellipse
     p_style => 'F'          -- Style: Fill, no border line
     );
     
     /* Create pattern: Polygon */

    /* Starts of define a �Tilling Pattern�. */  
     plpdf.CrTillingPattern(
     p_name => 'polygon', -- Name of pattern
     p_width => 7,        -- Width of pattern
     p_height => 7        -- Height of pattern
     );
     
     /* Add a polygon to the pattern. */
     plpdf.AddPolygon2Pattern(
     p_name => 'polygon',    -- Name of pattern
     p_points => l_points,   -- Points
     p_style => 'FD'         -- Style: Fill and border line
     );
     
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',       -- Font family: Arial
     p_style => null,           -- Font style: regular (default)
     p_size => 12               -- Font size: 12 pt
     ); 
    
    /* Draw pattern: line*/
    
    /* Sets the fill pattern for objects inserted after this statement. */
    plpdf.SetTillingPattern(
     p_name => 'line',              -- Name of pattern 
     p_color => plpdf_const.Salmon  -- Color of �graphical figures�
     );
    
    /* Draws a rectangle on the page */  
    plpdf.DrawRect(
     p_x => 10,                 -- X coordinate for the top left corner of the rectangle
     p_y => 10,                 -- Y coordinate for the top left corner of the rectangle
     p_w => 40,                 -- The width of the rectangle
     p_h => 40,                 -- The height of the rectangle
     p_style => 'FD'            -- Style: Fill, border line
     );
    
    /* Draw pattern: chequer */
    
    /* Sets the fill pattern for objects inserted after this statement. */
    plpdf.SetTillingPattern(
     p_name => 'chequer',           -- Name of pattern 
     p_color => plpdf_const.Black   -- Color of �graphical figures�
     );
    
    /* Draws a rectangle on the page */  
    plpdf.DrawRect(
     p_x => 10,                 -- X coordinate for the top left corner of the rectangle
     p_y => 55,                 -- Y coordinate for the top left corner of the rectangle
     p_w => 40,                 -- The width of the rectangle
     p_h => 40,                 -- The height of the rectangle
     p_style => 'FD'            -- Style: Fill, border line
     );

    /* Draw pattern: halfchequer */
    
    /* Sets the fill pattern for objects inserted after this statement. */
    plpdf.SetTillingPattern(
     p_name => 'halfchequer',           -- Name of pattern 
     p_color => plpdf_const.Royal_blue  -- Color of �graphical figures�
     );
    
    /* Draws a rectangle on the page */  
    plpdf.DrawRect(
     p_x => 10,                 -- X coordinate for the top left corner of the rectangle
     p_y => 100,                -- Y coordinate for the top left corner of the rectangle
     p_w => 40,                 -- The width of the rectangle
     p_h => 40,                 -- The height of the rectangle
     p_style => 'FD'            -- Style: Fill, border line
     );	
     
     /* Draw pattern: circle */
    
    /* Sets the fill pattern for objects inserted after this statement. */
    plpdf.SetTillingPattern(
     p_name => 'circle',                  -- Name of pattern 
     p_color => plpdf_const.Yellow_green  -- Color of �graphical figures�
     );
    
    /* Draws a rectangle on the page */  
    plpdf.DrawRect(
     p_x => 10,                 -- X coordinate for the top left corner of the rectangle
     p_y => 145,                -- Y coordinate for the top left corner of the rectangle
     p_w => 40,                 -- The width of the rectangle
     p_h => 40,                 -- The height of the rectangle
     p_style => 'FD'            -- Style: Fill, border line
     );	
     
     /* Draw pattern: ellipse */
    
    /* Sets the fill pattern for objects inserted after this statement. */
    plpdf.SetTillingPattern(
     p_name => 'ellipse',                  -- Name of pattern 
     p_color => plpdf_const.Green          -- Color of �graphical figures�
     );
    
    /* Draws a rectangle on the page */  
    plpdf.DrawRect(
     p_x => 10,                 -- X coordinate for the top left corner of the rectangle
     p_y => 190,                -- Y coordinate for the top left corner of the rectangle
     p_w => 40,                 -- The width of the rectangle
     p_h => 40,                 -- The height of the rectangle
     p_style => 'FD'            -- Style: Fill, border line
     );
     
     /* Draw pattern: polygon */
    
    /* Sets the fill pattern for objects inserted after this statement. */
    plpdf.SetTillingPattern(
     p_name => 'polygon',                  -- Name of pattern 
     p_color => plpdf_const.Orange         -- Color of �graphical figures�
     );
    
    /* Draws a rectangle on the page */  
    plpdf.DrawRect(
     p_x => 10,                 -- X coordinate for the top left corner of the rectangle
     p_y => 235,                -- Y coordinate for the top left corner of the rectangle
     p_w => 40,                 -- The width of the rectangle
     p_h => 40,                 -- The height of the rectangle
     p_style => 'FD'            -- Style: Fill, border line
     );
     
    /* Places the cursor at the X and Y coordinate. */
    plpdf.SetCurrentXY(
     p_x => 70,                 -- X coordinate
     p_y => 20                  -- y coordinate
    );
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and specified fill. */
    plpdf.PrintCell(
     p_w => 50,                 -- Rectangle width
     p_h => 10,                 -- Rectangle heigth
     p_txt => 'Line pattern'    -- Text in rectangle 
     );       

    /* Places the cursor at the X and Y coordinate. */
    plpdf.SetCurrentXY(
     p_x => 70,                 -- X coordinate
     p_y => 70                  -- y coordinate
    );
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and specified fill. */
    plpdf.PrintCell(
     p_w => 50,                 -- Rectangle width
     p_h => 10,                 -- Rectangle heigth
     p_txt => 'Chequer pattern' -- Text in rectangle 
     );          

    /* Places the cursor at the X and Y coordinate. */
    plpdf.SetCurrentXY(
     p_x => 70,                 -- X coordinate
     p_y => 120                 -- y coordinate
    );
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and specified fill. */
    plpdf.PrintCell(
     p_w => 50,                       -- Rectangle width
     p_h => 10,                       -- Rectangle heigth
     p_txt => 'Half-chequer pattern'  -- Text in rectangle 
     );	  
	  
    /* Places the cursor at the X and Y coordinate. */
    plpdf.SetCurrentXY(
     p_x => 70,                 -- X coordinate
     p_y => 170                 -- y coordinate
    );
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,                 -- Rectangle width
     p_h => 10,                 -- Rectangle heigth
     p_txt => 'Circle pattern'  -- Text in rectangle 
     );
     
     /* Places the cursor at the X and Y coordinate. */
    plpdf.SetCurrentXY(
     p_x => 70,                 -- X coordinate
     p_y => 210                 -- y coordinate
    );
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,                 -- Rectangle width
     p_h => 10,                 -- Rectangle heigth
     p_txt => 'Ellipse pattern'  -- Text in rectangle 
     );
     
     /* Places the cursor at the X and Y coordinate. */
    plpdf.SetCurrentXY(
     p_x => 70,                 -- X coordinate
     p_y => 260                 -- y coordinate
    );
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,                 -- Rectangle width
     p_h => 10,                 -- Rectangle heigth
     p_txt => 'Polygon pattern'  -- Text in rectangle 
     );		
     
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob     -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close;   
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure DrawRoundedRect is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Draws a rectangle on the page.*/
    plpdf.DrawRoundedRect(
    p_x => 10,        -- X coordinate for the top left corner of the rectangle
    p_y => 10,        -- Y coordinate for the top left corner of the rectangle
    p_w => 100,       -- The width of the rectangle
    p_h => 40,        -- The height of the rectangle
    p_r => 4,         -- The radius of the corners
    p_style => 'D'    -- Style : 'D' no fill, border line
    );
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
    p_r => 70,    -- Red component code, can be between 0 and 255
    p_g => 180,    -- Green component code, can be between 0 and 255
    p_b => 70     -- BLue component code, can be between 0 and 255
    );
    
    
    /* Draws a rectangle on the page.*/
    plpdf.DrawRoundedRect(
    p_x => 10,        -- X coordinate for the top left corner of the rectangle
    p_y => 60,        -- Y coordinate for the top left corner of the rectangle
    p_w => 70,       -- The width of the rectangle
    p_h => 30,        -- The height of the rectangle
    p_r => 8,         -- The radius of the corners
    p_style => 'F'    -- Style : 'D' no fill, border line
    ); 
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob     -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close;   
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
 
procedure InternalLink is
  l_blob blob;
  l_link number;
  
  begin
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Creates an internal link, and returns its ID. 
       An internal link can be used to take the cursor to another place 
       within the document by clicking over it. */
    l_link := plpdf.CrInternalLink;
    
     /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',       -- Font family: Arial
     p_style => null,           -- Font style: regular (default)
     p_size => 12               -- Font size: 12 pt
     ); 
    
    /* Draws a rectangle cell with text inside. The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
    p_w => 50,           -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_txt => 'Target'    -- Text in rectangle
    );
    
    /* Sets the destination page and position for the internal link */
    plpdf.SetLinkDest(l_link);
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Puts a link area on the page that point to an internal link */
    plpdf.PutLink(
     p_x => 100,               --X coordinate of the top left corner of the area
     p_y => 20,               -- Y coordinate of the top left corner of the area
     p_w => 60,               -- Link area width
     p_h => 15,               -- Link area height
     p_link => l_link         -- Internal link ID
     );
    
    /* Draws a rectangle on the page */ 
    plpdf.DrawRect(
     p_x => 100,              -- X coordinate for the top left corner of the rectangle
     p_y => 20,               -- Y coordinate for the top left corner of the rectangle
     p_w => 60,               -- The width of the rectangle
     p_h => 15,               -- The height of the rectangle
     p_style => 'D'           -- Style: no fill, border line
     );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob     -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close;   
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure MultiLineCell is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',       -- Font family: Arial
     p_style => null,           -- Font style: regular (default)
     p_size => 12               -- Font size: 12 pt
     );
    
    /* Draws a multi line cell. Default values: 
     - border: 0: without border, 
     - alignment: J: froce justification, 
     - fill: 0: no fill, 
     - maxline: 0: no max */
    plpdf.PrintMultiLineCell(
     p_w => 60, -- Rectangle width
     p_h => 10, -- Rectangle height
     p_txt => 'MultiLineCell - defaults. Generate dynamic PDF documents from data stored in Oracle databases using the PL/PDF program package.' -- Text in rectangle
     );
			 
    /* Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
    p_h => 10         -- Height of the line break. 
    );

    /* Draws a multi line cell. */
    plpdf.PrintMultiLineCell(
     p_w => 50, -- Rectangle width
     p_h => 10, -- Rectangle height
     p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases using the PL/PDF program package.', -- Text in rectangle
     p_border => '1',  -- Rectangle border: outline border
     p_align => 'L'    -- Text alignment: Left
     );
     
    /* Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
    p_h => 5         -- Height of the line break. 
    );
    
     /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
    p_r => 200,    -- Red component code, can be between 0 and 255
    p_g => 150,    -- Green component code, can be between 0 and 255
    p_b => 150     -- BLue component code, can be between 0 and 255
    );
 
    /* Draws a multi line cell. */ 
     plpdf.PrintMultiLineCell(
     p_w => 50, -- Rectangle width
     p_h => 10, -- Rectangle height
     p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases using the PL/PDF program package.', -- Text in rectangle
     p_border => 'LR',  -- Rectangle border: outline border
     p_align => 'C',    -- Text alignment: Center
     p_fill => 1        -- Filled
     );
     
     /* Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
    p_h => 5         -- Height of the line break. 
    );
   
    /* Draws a multi line cell. */  
     plpdf.PrintMultiLineCell(
     p_w => 50, -- Rectangle width
     p_h => 10, -- Rectangle height
     p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases using the PL/PDF program package.', -- Text in rectangle
     p_border => 'T',  -- Rectangle border
     p_align => 'R',    -- Text alignment: Left
     p_maxline => 3,     -- Max line number
     p_ln => 0         -- Cursor position after print the cell
     );
     
     /* Draws a multi line cell. */ 
     plpdf.PrintMultiLineCell(
     p_w => 50, -- Rectangle width
     p_h => 10, -- Rectangle height
     p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases using the PL/PDF program package.', -- Text in rectangle
     p_border => '0',  -- Rectangle border
     p_align => 'C',    -- Text alignment: Left
     p_ln => 1,         -- Cursor position after print the cell
     p_clipping => 0    -- Clipping off
     );

     /* Create a new page. Without parameters the default page orientation: portrait. */ 
    plpdf.NewPage;
    
    /* Draws a multi line cell. */ 
    plpdf.PrintMultiLineCell(
     p_w => 70, -- Rectangle width
     p_h => 10, -- Rectangle height
     p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases using the PL/PDF program package.', -- Text in rectangle
     p_border => '0',  -- Rectangle border
     p_ln => 1         -- Cursor position after print the cell
     );
     
     /* Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
    p_h => 5         -- Height of the line break. 
    );
     
    /* Draws a multi line cell. */ 
     plpdf.PrintMultiLineCell(
     p_w => 70, -- Rectangle width
     p_h => 10, -- Rectangle height
     p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases using the PL/PDF program package.', -- Text in rectangle
     p_border => '0',  -- Rectangle border
     p_ln => 1,         -- Cursor position after print the cell
     p_indent => 10,     -- First line indent
     p_link => 'http://www.plpdf.com'
     );
     
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob     -- The generated document
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure FlowingText is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',       -- Font family: Arial
     p_style => null,           -- Font style: regular (default)
     p_size => 12               -- Font size: 12 pt
     ); 
    
    /* Prints text continuously. */
    plpdf.PrintFlowingText(
     p_h => 9, -- Line height
     p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases ' ||
            'using the PL/PDF program package. PL/PDF is written exclusively in PL/SQL. ' ||
            'It is able to either store the generated PDF document in the database or ' ||
            'provide the results directly to a browser using MOD_PLSQL. No third-party ' ||
            'software is needed; PL/PDF only uses tools provided by the installation ' ||
            'package of an Oracle Database. Use PL/PDF to quickly and easily develop ' ||
            'applications with dynamic content but also quality ' ||
            'presentation and printing capabilities.' -- Text
     );
     
     /* Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
    p_h => 20         -- Height of the line break. 
    );
    
    /* Prints text continuously. */ 
    plpdf.PrintFlowingText(
     p_h => 9,     -- Line height
     p_link => 'http://www.plpdf.com', -- URL or internal link ID
     p_align => 'R',                   -- Text alignment: Right      
     p_txt => 'With link -> Generate dynamic PDF documents from data stored in Oracle databases ' ||
            'using the PL/PDF program package. PL/PDF is written exclusively in PL/SQL. ' ||
            'It is able to either store the generated PDF document in the database or ' ||
            'provide the results directly to a browser using MOD_PLSQL. No third-party ' ||
            'software is needed; PL/PDF only uses tools provided by the installation ' ||
            'package of an Oracle Database. Use PL/PDF to quickly and easily develop ' ||
            'applications with dynamic content but also quality ' ||
            'presentation and printing capabilities.' -- Text
     );
     
    /* Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
    p_h => 20         -- Height of the line break. 
    );
     
    /* Prints text continuously. */ 
    plpdf.PrintFlowingText(
     p_h => 9,     -- Line height
     p_align => 'J',  -- Text alignment: Force Justification
     p_clipping => 0, -- Clipping text: 0 - no clipping
     p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases ' ||
            'using the PL/PDF program package. PL/PDF is written exclusively in PL/SQL. ' ||
            'It is able to either store the generated PDF document in the database or ' ||
            'provide the results directly to a browser using MOD_PLSQL. No third-party ' ||
            'software is needed; PL/PDF only uses tools provided by the installation ' ||
            'package of an Oracle Database. Use PL/PDF to quickly and easily develop ' ||
            'applications with dynamic content but also quality ' ||
            'presentation and printing capabilities.' -- Text
     );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
  plpdf.SendDoc(
  p_blob => l_blob     -- The generated document
  );
  
  /* Print it:
    
  owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close;   
        wpg_docload.download_file(l_blob);   */
  
  /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure FlowingTextLimit is
  l_blob blob;
  l_link number;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => null,        -- Font style: regular (default)
     p_size => 12            -- Font size: 12 pt
     ); 
	
    /* Prints text continuously. */
    plpdf.PrintFlowingTextLimit(
     p_h => 9, -- Line height
     p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases ' ||
            'using the PL/PDF program package. PL/PDF is written exclusively in PL/SQL. ' ||
            'It is able to either store the generated PDF document in the database or ' ||
            'provide the results directly to a browser using MOD_PLSQL. No third-party ' ||
            'software is needed; PL/PDF only uses tools provided by the installation ' ||
            'package of an Oracle Database. Use PL/PDF to quickly and easily develop ' ||
            'applications with dynamic content but also quality ' ||
            'presentation and printing capabilities.', -- Text
     p_min_x => 120,         -- Minimum X position
     p_max_x => 160,         -- Maximum X position
     p_align => 'J'          -- Text alignment: Force Justification
     );
     
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob     -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close;   
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
    
procedure Image is
  l_blob blob;
  l_image blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => null,        -- Font style: regular (default)
     p_size => 12            -- Font size: 12 pt
     ); 
    
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
    p_w => 100,      -- Rectangle width
    p_h => 10,       -- Rectangle height
    p_txt => 'Image' -- Text in rectangle 
    );
    
    /* Select image from a table.
       Needs table IMAGE_BLOB(id number, image_file blob).
       Image_file must contain image. */
    select image_file
      into l_image
     from IMAGE_BLOB
     where id = 1
     for update;
    
    
    /* Inserts an image (JPG, BMP, PNG, etc.) from a BLOB variable
       into the current page. */
    plpdf.PutImage(
     p_name => 'kep.jpg',  -- Image name or ID
     p_data => l_image,           -- Variable containing the image as binary data
     p_x => 10,                   -- X coordinate of the image
     p_y => 20,                   -- Y coordinate of the image
     p_w => 100,                   -- Image width
     p_h =>  30                   -- Image height
     );    
   
   
    /* Inserts an image (JPG, BMP, PNG, etc.) from a BLOB variable
       into the current page. */
    plpdf.PutImage(
     p_name => 'kep.jpg',         -- Image name or ID
     p_data => l_image,           -- Variable containing the image as binary d
     p_x => 10,                   -- X coordinate of the image
     p_y => 70,                   -- Y coordinate of the image
     p_w =>  0,                   -- Image width, if 0 then the image is displayed in its actual width
     p_h =>  0                    -- Image height, if 0 then the image is displayed in its actual height
     );
     
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;  

procedure ImageCell is
  l_blob blob;
  l_image blob;
  
  begin
    
    /* Select image from a table.
       Needs table IMAGE_BLOB(id number, image_file blob).
       Image_file must contain image. */
    select image_file
       into l_image
      from image_blob
      where id = 1
      for update;
      
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
   
 
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => null,        -- Font style: regular (default)
     p_size => 12            -- Font size: 12 pt
     );  
    
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,              -- Rectangle width                             
     p_h => 10,              -- Rectangle height                            
     p_txt => 'ImageCell'    -- Text in rectangle                   
     ); 
     
     /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_color => plpdf_const.Gray  -- Color
     ); 
     
   
    /* Print an image with frame. */
    plpdf.PrintImageCell(
     p_w => 50,                             -- Width of frame
     p_h => 50,                             -- Height of frame
     p_name => 'Image4 ',                   -- Name of image
     p_data =>  l_image,                    -- Variable containing the image as binary data
     p_margin =>     5,                     -- Margin size of frame
     p_border => '1',                       -- Rectangle border
     p_ln => 0,                             -- Cursor position after the cell is printed
     p_fill =>   1,                         -- Fill
     p_link => 'http://www.oracle.com'      -- URL 
     );
     
     
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;



procedure PrintRow is
  
  l_blob blob;

  l_border    char(1);                    -- Actual border
  l_fill      number;                     -- Filling
  l_datas     plpdf_type.t_row_datas;     -- Array of datas
  l_borders   plpdf_type.t_row_borders;   -- Array of borders
  l_widths    plpdf_type.t_row_widths;    -- Array of widths
  l_aligns    plpdf_type.t_row_aligns;    -- Array of aligns
  l_styles    plpdf_type.t_row_styles;    -- Array of styles
  l_maxlines  plpdf_type.t_row_maxlines;  -- Array of max lines
  
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Set columns widths */
    l_widths(1) := 30;
    l_widths(2) := 40;
    l_widths(3) := 100;
	 
    /* Set columns aligns */
    l_aligns(1) := 'R';          -- Right
    l_aligns(2) := 'C';          -- Center
    l_aligns(3) := 'L';          -- Left
	
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => 'B',             -- Font style: Bold
     p_size => 12                -- Font size: 12 pt
     ); 
     
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 200,                 -- Red component code, can be between 0 and 255
     p_g => 220,                 -- Green component code, can be between 0 and 255
     p_b => 255                  -- Blue component code, can be between 0 and 255
     ); 	
        
    
    
    /* Print rows with PLPDF.Row_Print */
    
    /* Print headers */
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(1),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'ROWNUM',          -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '0',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(2),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'OWNER',           -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '0',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(3),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'OBJECT NAME',     -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '1',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
        
         
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => null,            -- Font style: regular (default)
     p_size => 12                -- Font size: 12 pt
     ); 
     
     /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 180,                 -- Red component code, can be between 0 and 255
     p_g => 180,                 -- Green component code, can be between 0 and 255
     p_b => 180                  -- Blue component code, can be between 0 and 255
     ); 
    
    for f_obj in (select rownum, owner, object_name from all_objects where rownum <= 10) loop
        /* Set datas */
	l_datas(1) := to_char(f_obj.rownum); 
	l_datas(2) := f_obj.owner;
	l_datas(3) := f_obj.object_name;    
       
        /* Print datas*/
        
        /* Prints a full row in the PDF document. 
           The rows consist of multi-line cells. 
           The row�s height is set according to the largest cell */
        plpdf.Row_Print(
        p_data => l_datas,       -- Data shown in the cells
        p_width => l_widths,     -- Width of the cells
        p_align => l_aligns,      -- Alignment of the cells
        p_h => 8,                 -- Height of the cells
        p_fill => 0,              -- no fill
        p_min_height => 5         -- Minimal height of row, 0 means that this parameter is not used
        );
    end loop;
	
    /* Line break. Cursor is placed at the start of the next line.*/
    plpdf.LineBreak(
     p_h => 40                  -- Height of the line break.
     ); 
     
     /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 200,                 -- Red component code, can be between 0 and 255
     p_g => 220,                 -- Green component code, can be between 0 and 255
     p_b => 255                  -- Blue component code, can be between 0 and 255
     ); 	    
    
    /* Print rows with PLPDF.Row_Print2 */     
    
    /* Print headers */
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => 'B',             -- Font style: Bold
     p_size => 12                -- Font size: 12 pt
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(1),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'ROWNUM',          -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '0',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(2),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'OWNER',           -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '0',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(3),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'OBJECT NAME',     -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '1',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
     
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 245,                 -- Red component code, can be between 0 and 255
     p_g => 245,                 -- Green component code, can be between 0 and 255
     p_b => 255                  -- Blue component code, can be between 0 and 255
     );   
     
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => null,            -- Font style: regular (default)
     p_size => 12                -- Font size: 12 pt
     );
         
    for f_obj in (select rownum, owner, object_name from all_objects where rownum <= 10) loop
        /* Set datas */
	l_datas(1) := to_char(f_obj.rownum); 
	l_datas(2) := f_obj.owner;
	l_datas(3) := f_obj.object_name;    
        
        
        if mod(f_obj.rownum,2)=1 then
              /* Odd line */
              l_border:='0';
              l_fill:=1;
          else
              /* Even line */
              l_border:='1';
              l_fill:=0;
        end if;
                
        /* Set columns borders */
        l_borders(1) := l_border;       
        l_borders(2) := l_border;
        l_borders(3) := l_border;
       
        /* Print datas*/
        
        /* Prints a full row in the PDF document. 
           The rows consist of multi-line cells. 
           The row�s height is set according to the largest cell */
        plpdf.Row_Print2(
         p_data => l_datas,       -- Data shown in the cells
         p_border => l_borders,   -- Border array of the cells
         p_width => l_widths,     -- Width of the cells
         p_align => l_aligns,     -- Alignment of the cells
         p_style => l_styles,     -- Style of the cells
         p_maxline => l_maxlines, -- Maximum number of lines in a multi-line cell
         p_fill => l_fill,         -- Fill
         p_min_height => 5,        -- Minimal height of row
         p_clipping => 1           -- Cipping
         );
    end loop;
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure PrintRowLink is
  l_blob blob;
  l_datas     plpdf_type.t_row_datas;     -- Array of datas
  l_borders   plpdf_type.t_row_borders;   -- Array of borders
  l_widths    plpdf_type.t_row_widths;    -- Array of widths
  l_aligns    plpdf_type.t_row_aligns;    -- Array of aligns
  l_styles    plpdf_type.t_row_styles;    -- Array of styles
  l_fonts     plpdf_type.t_row_fonts;     -- Array of fonts
  l_maxlines  plpdf_type.t_row_maxlines;  -- Array of max lines
  l_links     plpdf_type.t_row_links;     -- Array of links
  
  begin
      /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
     /* Set columns borders */
    l_borders(1) := '1'; 
    l_borders(2) := '1';
    l_borders(3) := '1';
	 
    /* Set columns widths */
    l_widths(1) := 30;
    l_widths(2) := 40;
    l_widths(3) := 100;
	 
    /* Set columns aligns */
    l_aligns(1) := 'R';          -- Right
    l_aligns(2) := 'C';          -- Center
    l_aligns(3) := 'L';          -- Left
	
    /* Set links */
    l_links(1) := 'http://www.plpdf.com';
    l_links(2) := 'http://www.plsqlplus.com';
    l_links(3) := 'http://support.plpdf.com';
  
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => 'B',             -- Font style: Bold
     p_size => 12                -- Font size: 12 pt
     );
    
    /* Set background color*/
    
    /* Sets the fill color for objects inserted after this statement. 
       Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Filling(
     p_r => 200,                 -- Red component code, can be between 0 and 255
     p_g => 220,                 -- Green component code, can be between 0 and 255
     p_b => 255                  -- Blue component code, can be between 0 and 255
     ); 
    
    /* Print headers */
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(1),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'ROWNUM',          -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '0',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(2),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'OWNER',           -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '0',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );

    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(3),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'OBJECT NAME',     -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '1',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
	 
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => null,            -- Font style: regular (default)
     p_size => 12                -- Font size: 12 pt
     );

    /* Print with PLPDF.RowPrint3 */	 
    
    for f_obj in (select rownum, owner, object_name from all_objects where rownum <= 10) loop
        /* Set datas */
	l_datas(1) := to_char(f_obj.rownum); 
	l_datas(2) := f_obj.owner;
	l_datas(3) := f_obj.object_name;    
       
        /* Print datas*/
        
        /* Prints a full row in the PDF document. 
           The rows consist of multi-line cells. 
           The row�s height is set according to the largest cell */
        plpdf.Row_Print3(
        p_data => l_datas,       -- Data shown in the cells
        p_border => l_borders,   -- Border array of the cells
        p_width => l_widths,     -- Width of the cells
        p_align => l_aligns,     -- Alignment of the cells
        p_style => l_styles,     -- Style of the cells
        p_maxline => l_maxlines, -- Maximum number of lines in a multi-line cell
        p_links => l_links,       -- Links of the cells 
        p_h => 8,                 -- Height of the cells
        p_fill => 0,              -- no fill
        p_min_height => 5         -- Minimal height of row, 0 means that this parameter is not used 
        );
    end loop;

    /* Line break. Cursor is placed at the start of the next line.*/
    plpdf.LineBreak(
     p_h => 40                  -- Height of the line break.
     );
     
    /* Print with PLPDF.RowPrint4 */	 
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => 'B',             -- Font style: Bold
     p_size => 12                -- Font size: 12 pt
     );
    
    /* Print headers */
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(1),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'ROWNUM',          -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '0',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(2),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'OWNER',           -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '0',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );

    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => l_widths(3),         -- Rectangle width
     p_h => 10,                  -- Rectangle heigth
     p_txt => 'OBJECT NAME',     -- Text in rectangle 
     p_border => '1',            -- With frame
     p_ln => '1',                -- Cursor position after the cell is printed
     p_align => 'C',             -- Text alignment: Center
     p_fill => 1                 -- Fill with current fill color
     );
    
    /* Set l_fonts attributes */
    l_fonts(1).family:='Arial';   -- Font family 
    l_fonts(1).style:= 'B';       -- Font style: Bold
    l_fonts(1).fsize:= 12;        -- Font size: 12 pt
    
    /* Set l_fonts attributes */
    l_fonts(2).family:='Arial';   -- Font family 
    l_fonts(2).style:= 'U';       -- Font style: Underline
    l_fonts(2).fsize:= 10;        -- Font size: 10 pt
    
    /* Set l_fonts attributes */
    l_fonts(3).family:='Courier'; -- Font family 
    l_fonts(3).style:= null;      -- Font style: regular
    l_fonts(3).fsize:= 12;        -- Font size: 12 pt
    
    for f_obj in (select rownum, owner, object_name from all_objects where rownum <= 10) loop
        /* Set datas */
	l_datas(1) := to_char(f_obj.rownum); 
	l_datas(2) := f_obj.owner;
	l_datas(3) := f_obj.object_name;    
       
        /* Print datas*/
        
        /* Prints a full row in the PDF document. 
           The rows consist of multi-line cells. 
           The row�s height is set according to the largest cell */
        plpdf.Row_Print4(
        p_data => l_datas,       -- Data shown in the cells
        p_border => l_borders,   -- Border array of the cells
        p_width => l_widths,     -- Width of the cells
        p_align => l_aligns,     -- Alignment of the cells
        p_font => l_fonts,       -- Font of the cells (Family is required)
        p_maxline => l_maxlines, -- Maximum number of lines in a multi-line cell
        p_links => l_links,       -- Links of the cells
        p_h => 8,                 -- Height of the cells
        p_fill => 0,              -- no fill
        p_min_height => 5         -- Minimal height of row, 0 means that this parameter is not used  
        );
    end loop;
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit; 
  end;
  
procedure Rotate is
  l_blob blob;
  
  begin
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Places the cursor at the X and Y coordinate */
    plpdf.SetCurrentXY(
     p_x => 50,             -- X coordinate
     p_y => 50              -- Y coordinate
     );
    
    /* Sets the degree of rotation. Text and images can both be rotated. */    
    plpdf.SetRotate(
     p_angle => 45          -- Angle/degree of rotation
     );
    
   /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => 'B',             -- Font style: Bold
     p_size => 12                -- Font size: 12 pt
     );
     
     /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,           -- Rectangle width             
     p_h => 10,           -- Rectangle height                
     p_txt => 'ROTATE',   -- Text in rectangle
     p_ln => 1            -- Cursor position after the cell is printed
     );
     
     
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
     
    /* Sets the degree of rotation. Text and images can both be rotated. */
     plpdf.SetRotate(
     p_angle => 120,      -- Angle/degree of rotation
     p_x => 50,           -- X coordinate of the rotation point, if -1 then the X coordinate of the cursor
     p_y => 50            -- Y coordinate of the rotation point, if -1 then the Y coordinate of the cursor
     );
     
     /* Draws a rectangle cell with text inside. */
      plpdf.PrintCell(
     p_w => 50,           -- Rectangle width               
     p_h => 10,           -- Rectangle height              
     p_txt => 'ROTATE2'   -- Text in rectangle 
     ); 
     
	  /*Sets rotate back*/
    plpdf.SetRotate(0);
    
   /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure SetRotatePage is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Sets the degree of rotation for all pages. The value must be a multiple of 90. */
    plpdf.SetRotatePages(
    p_angle => 270     -- Angle/degree of rotation
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12                       -- Font size: 12
     ); 
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_txt => 'Sample Text'  -- Text in rectangle
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure CreateBookmark is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
     /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => 'B',             -- Font style: Bold
     p_size => 12                -- Font size: 12 pt
     );
    
    /* Create a bookmark in the PDF document. 
       Bookmarks are displayed in the PDF viewer program (e.g. Acrobat Reader). */
    plpdf.CrBookmark(
     p_txt => 'Page 1',         -- Text of bookmark
     p_level => 0,              -- Bookmark level
     p_y => -1                  -- Y coordinate of the bookmark within the current page: denoted 
     );
  
    /* Draws a rectangle cell with text inside. */
      plpdf.PrintCell(
     p_w => 50,           -- Rectangle width                        
     p_h => 10,           -- Rectangle height                 
     p_txt => 'Page 1'    -- Text in rectangle          
     ); 
	
    /* Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
    p_h => 20           -- Height of the line break. 
    );
     
    /* Create a bookmark in the PDF document. 
       Bookmarks are displayed in the PDF viewer program (e.g. Acrobat Reader). */
    plpdf.CrBookmark(
     p_txt => 'Paragraph 1.1',  -- Text of bookmark
     p_level => 1,              -- Bookmark level
     p_y => -1                  -- Y coordinate of the bookmark within the current page. �1 denotes the cursor position.
     );	
  	
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                 -- Rectangle width
     p_h => 10,                 -- Rectangle heigth
     p_txt => 'Paragraph 1.1'   -- Text in rectangle 
     );
     
    /* Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
    p_h => 40	           -- Height of the line break. 
    );
    
    /* Create a bookmark in the PDF document. 
       Bookmarks are displayed in the PDF viewer program (e.g. Acrobat Reader). */
    plpdf.CrBookmark(
     p_txt => 'Paragraph 1.2',  -- Text of bookmark
     p_level => 1,              -- Bookmark level
     p_y => -1                  -- Y coordinate of the bookmark within the current page. �1 denotes the cursor position.
     );
     
     /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                 -- Rectangle width
     p_h => 10,                 -- Rectangle heigth
     p_txt => 'Paragraph 1.2'   -- Text in rectangle 
     );
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Create a bookmark in the PDF document. 
       Bookmarks are displayed in the PDF viewer program (e.g. Acrobat Reader). */
    plpdf.CrBookmark(
     p_txt => 'Page 2',         -- Text of bookmark
     p_level => 0,              -- Bookmark level
     p_y => -1                  -- Y coordinate of the bookmark within the current page: denoted
     );	
	
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                 
     p_h => 10,          -- Rectangle height               
     p_txt => 'Page 2'   -- Text in rectangle          
     );
     
     /* Create a new page. Without parameters the default page orientation: portrait. */
     plpdf.NewPage;
    
    /* Create a bookmark in the PDF document. 
       Bookmarks are displayed in the PDF viewer program (e.g. Acrobat Reader). */
    plpdf.CrBookmark(
     p_txt => 'Page 3',         -- Text of bookmark
     p_level => 0,              -- Bookmark level
     p_y => -1                  -- Y coordinate of the bookmark within the current page: denoted
     );	
	
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                 -- Rectangle width                  
     p_h => 10,                 -- Rectangle height
     p_txt => 'Page 3'          -- Text in rectangle
     );
     
     /* Create a new page. Without parameters the default page orientation: portrait. */
     plpdf.NewPage;
    
    /* Create a bookmark in the PDF document. 
       Bookmarks are displayed in the PDF viewer program (e.g. Acrobat Reader). */
    plpdf.CrBookmark(
     p_txt => 'Page 4',         -- Text of bookmark
     p_level => 0,              -- Bookmark level
     p_y => -1                  -- Y coordinate of the bookmark within the current page: denoted
     );	
	
    /* Draws a rectangle cell with text inside. */
     plpdf.PrintCell(
     p_w => 50,                 -- Rectangle width                  
     p_h => 10,                 -- Rectangle height
     p_txt => 'Page 4'          -- Text in rectangle
     );
     	
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  

  
procedure TTFembending is
  
  l_blob blob;
  l_ttf plpdf_type.t_addfont;
  
  begin
    
    /* Retrieves the font form PLPDF_TTF_ADD table.*/
    l_ttf := plpdf_Ttf.GetTTF(
              p_id => 1  -- ID field of the PLPDF_TTF_ADD table
              );
  
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Imports a TTF (True Type Font). The imported font becomes
       available to the SetPrintFont procedure. */
    Plpdf.addTTF(
     p_family => 'ArialMT',  -- TTF name
     p_style => null,  -- Font style: Regular
     p_data => l_ttf  -- It contains the font definition binary file
     );
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
     /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'ArialMT',    -- Font family: ArialMT
     p_style => null,          -- Font style: regular        
     p_size => 12              -- Font sie 12;
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 100,         -- Rectangle width               
     p_h => 10,          -- Rectangle height             
     p_txt => 'Font family:ArialMT -> TTF Example' -- Text in rectangle  
     );
    
    	
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;  

procedure Clipping is
  l_blob blob;
  l_text varchar2(255) := 'Hello World! PLPDF Hello World! PLPDF';
  l_length number;
  
  begin
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',        -- Font family: Arial
     p_style => null,             -- Font style: Bold
     p_size => 12                -- Font size: 12 pt
     );
    
    /* function plpdf.GetTextWidth: 
       Returns the width of the parameter text. 
       The width of the text in the unit of measure specified in plpdf.Init */
    l_length := plpdf.GetTextWidth(
                 p_s => l_text  -- Parameter text
                 );
    
    /* Starts a clipping frame. 
       The clipping limits the region that can be paint. */
    plpdf.StartClipping(
    p_x => 20,                  -- X coordinate for the start of the clipping frame
    p_y => 15,                  -- Y coordinate for the start of the clipping frame
    p_w => 45,                  -- Height of clipping frame
    p_h => 60                   -- Width of clipping frame
    );
    
    for l_i in 1..10 loop
      /* Draws a rectangle cell with text inside. */
      plpdf.PrintCell(
       p_w => l_length,         -- Rectangle width
       p_h => 10,               -- Rectangle heigth
       p_txt => l_text,         -- Text in rectangle 
       p_border => '1',         -- With frame
       p_ln => 1,                -- Cursor position after the cell is printed: New line  
	   p_clipping => 0			-- no clipping
       );    
    end loop;
    
    /* The clipping affects for objects wich located between
       StartClipping and EndClipping. */
    plpdf.EndClipping; 
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;  
  
procedure Protect is
  l_blob blob;
  
  begin
      /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    /* Allows to protect the PDF document. */
    plpdf.SetProtection(
     p_print_perm => false,          -- Print the PDF
     p_modify_perm => true,         -- Modify the PDF
     p_copy_perm => true,           -- Copy the PDF
     p_annot_forms_perm => true,    -- Add annotations and forms
     p_user_pass => 'apple',        -- User password
     p_owner_pass=> 'pear'          -- Owner password
     );
    
     /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    
     /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => null,          -- Font style: regular        
     p_size => 12              -- Font sie 12;
     ); 
     
     /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 65,           -- Rectangle width                     
     p_h => 10,           -- Rectangle height
     p_txt => 'Protection example'     -- Text in rectangle
     );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;


procedure JavaScript is
  l_blob blob;
  
  begin
    
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
     /* Add JavaScript inside the PDF. */
    Plpdf.setJS(
    p_text => 'this.print(true);' -- JavaScript source code: print pdf when open
    ); 
    
     /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
      
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => null,          -- Font style: regular        
     p_size => 12              -- Font sie 12;
     ); 
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                
     p_h => 10,          -- Rectangle height              
     p_txt => 'JavaScript'  -- Text in rectangle
     );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure AttachFile is
  l_blob blob;
  l_pdf blob;
  
  begin
    /* Select another PDF into l_pdf */ 
    select blob_file
      into l_pdf
     from store_BLOB
     where rownum < 2;
     
      /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Attachs a file to the PDF document. */
    plpdf.AttachFile(
     p_filename => 'test.pdf',        -- Name of file
     p_fileblob => l_pdf,              -- BLOB containing the PDF as binary data 
     p_desc => 'Desctription text'    -- Desctription of file
     );
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
   
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => null,          -- Font style: regular        
     p_size => 12              -- Font sie 12;
     ); 
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 80,          -- Rectangle width                                
     p_h => 10,          -- Rectangle height             
     p_txt => 'Attached File'        -- Text in rectangle
     );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure PageNumber is
  l_blob blob;
  
  /*
  Logical Page | Command | PageNo
   1              -         1/2
   2              end       2/2
   3              -         -
   4              -         -
   5              start     1/4
   6              -         2/4
   7              -         3/3
   8              -         4/4
   9              start     1/2
   10             -         2/2  */ 
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Defines the page number alias. 
       Default: {nb} */    
    plpdf.nopAlias;
    
    
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.header2',    -- Page header procedure name: xheader
     p_height => 10               -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.footer2',   --Page footer procedure name: xfooter
     p_height => 10               --Height of footer section
     ); 
     
    
    /* Page 1, PageNo. 1/2 */
     
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
    
  
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => null,          -- Font style: regular        
     p_size => 12              -- Font sie 12;
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                   
     p_txt => 'Page 1'   -- Text in rectangle            
     ); 
	   
    
    /* Page 2, PageNo. 2/2 */
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
    
    /* Sets end of page numbering to the current page. */
    plpdf.SetPageNoEnd;
	   
    
   /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                    
     p_txt => 'Page 2'   -- Text in rectangle            
     );



    /* Page 3, PageNo. -- */
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
           
    
   /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                    
     p_txt => 'Page 3'   -- Text in rectangle            
     );
	   
    
    
    /* Page 4, PageNo. -- */
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
           
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                  
     p_txt => 'Page 4'   -- Text in rectangle         
     );
	   
    
    
    /* Page 5, PageNo. 1/4 */
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
      
    /* Sets start of page numbering to the current page. */
    plpdf.SetPageNoStart;
         
  
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                   
     p_txt => 'Page 5'   -- Text in rectangle         
     );
          
	   
    
    /* Page 6, PageNo. 2/4 */
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
           
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                    
     p_txt => 'Page 6'   -- Text in rectangle            
     );
    
    
    
    /* Page 7, PageNo. 3/4 */
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
           
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                    
     p_txt => 'Page 7'   -- Text in rectangle            
     );
	   
    
    
    /* Page 8, PageNo. 4/4 */
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
           
   
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                  
     p_txt => 'Page 8'   -- Text in rectangle          
     );
	   
    
    /* Page 9, PageNo. 1/2 */
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
      
    /* Sets start of page numbering to the current page. */
    plpdf.SetPageNoStart;
         

    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                   
     p_txt => 'Page 9'   -- Text in rectangle             
     );
	   
    
    
    /* Page 10, PageNo. 2/2 */
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage; 
      
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,          -- Rectangle width                     
     p_h => 10,          -- Rectangle height                    
     p_txt => 'Page 10'  -- Text in rectangle          
     );
    
      /* Returns the generated PDF document. 
         The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure header2 is
  l_blob blob;
  
  begin
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => 'BU',        -- Font style: Bold and Underline
     p_size => 12            -- Font size: 12 pt
     ); 
    
    /* Page title */
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 0,                          -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page title text',        -- Text in rectangle 
     p_border => '0',                   -- Without frame
     p_ln => '0',                       -- Cursor position after the cell is printed: Beside  
     p_align => 'C'                     -- Text alignment: Center
     );   
   
    /* Line break. 
       Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
     p_h => 20                          --Height of the line break.
     );
  end;


procedure footer2 is
  begin
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',     -- Font family: Arial
     p_style => 'I',          -- Font style: Italic
     p_size => 8              -- Font size: 8 pt
     ); 
   
    /* Print number of page */
   
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 0,                -- Rectangle width
     p_h => 10,               -- Rectangle heigth
     p_txt => '{cp}/{nb}',    -- Text in rectangle 
     p_border => '0',         -- Without frame
     p_ln => '0',             -- Cursor position after the cell is printed: Beside  
     p_align => 'C'           -- Text alignment: Center
     );   
  end;
  
procedure TextAnnotation is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* 1st annotation */
    
    /* Add Text annotation to the current page. */
    plpdf.AddTextAnnot(
      p_name => 'Note',     -- The name of an icon to be used in displaying the annotation.
      p_contents => 'With Oracle Enterprise Manager 10g Release 2, ' || 
                    'customers can manage many business applications, ' ||
                    'end-user services and the entire grid infrastructure ' || 
                    'as easily as managing one application running on one computer.', 
                    /* The text to be displayed in the pop-up window when the annotation is opened. */
      p_x => 20,            -- X coordinate of the annotation
      p_y => 30             -- Y coordinate of the annotation
      );

    
    
    /* 2nd annotation */
    
    /* Add Text annotation to the current page. */
    plpdf.AddTextAnnot(
      p_name => 'Key',      -- The name of an icon to be used in displaying the annotation.
      p_contents => 'Manage your grids as a single entity using improved ' || 
                    'tools such as new service modeling, broader support ' || 
                    'for service protocols, and comprehensive policies and templates. ' || 
                    'Virtualized application component resources, ' || 
                    'as well as virtualized infrastructure components, ' || 
                    'are transparently monitored, diagnosed, and provisioned.',
                    /* The text to be displayed in the pop-up window when the annotation is opened. */
      p_x => 20,            -- X coordinate of the annotation
      p_y => 50,            -- Y coordinate of the annotation
      p_label => 'Manage Virtualized Grid Resources', 
                    /* The text label to be displayed in the title bar 
                       of the annotation�s pop-up window when open and active. */
      p_popup_x  => 40,     -- X coordinate of the pop-up window
      p_popup_y  => 50,     -- Y coordinate of the pop-up window
      p_popup_w  => 100,    -- Width of the pop-up window
      p_popup_h  => 50      -- Height of the pop-up window
      );



    /* 3rd annotation */

    /* Add Text annotation to the current page. */
    plpdf.AddTextAnnot(
      p_name => 'Comment',  -- The name of an icon to be used in displaying the annotation.
      p_contents => 'Unique service management features such as graphical ' || 
                    'service topologies and service dashboards provide the ' || 
                    'right information to high-level decision makers and lines ' || 
                    'of business managers so they can better understand system ' ||
                    'and service level quality and plan effectively. ' || '
                    Robust automated provisioning and patching functionality ' || 
                    'give IT administrators the power make efficient, error-free changes.',
                    /* The text to be displayed in the pop-up window when the annotation is opened. */
      p_x => 20,            -- X coordinate of the annotation
      p_y => 70,            -- Y coordinate of the annotation
      p_label => 'Best Quality of Service at Lowest Management Cost',
                    /* The text label to be displayed in the title bar 
                       of the annotation�s pop-up window when open and active. */
      p_color => plpdf_const.Lime, -- This color will be used.(see User Guide)
      p_popup_x  => 40,     -- X coordinate of the pop-up window
      p_popup_y  => 70,     -- X coordinate of the pop-up window
      p_popup_w  => 140,    -- Width of the pop-up window
      p_popup_h  => 50      -- Height of the pop-up window
      );

    
    
    /* 4th annotation */
    
    /* Add Text annotation to the current page. */
    plpdf.AddTextAnnot(
      p_name => 'Help',     -- The name of an icon to be used in displaying the annotation.
      p_contents => 'Increased management scope for IT infrastructure products ' || 
                    'provide customers improved insight into every aspect of ' || 
                    'service performance � including application servers, ' || 
                    'firewalls, operating systems, load balancers, ' || 
                    'and storage components. Customers can easily detect and ' || 
                    'resolve issues throughout a grid as well as monitor and ' || 
                    'manage key non-Oracle products in the data center environment.',
                    /* The text to be displayed in the pop-up window when the annotation is opened. */
      p_x => 20,            -- X coordinate of the annotation
      p_y => 90,            -- X coordinate of the annotation
      p_label => 'Higher Value through Wider Breadth of Management',
                    /* The text label to be displayed in the title bar 
                       of the annotation�s pop-up window when open and active. */
      p_color => plpdf_const.Salmon,  -- This color will be used.(see User Guide)
      p_popup_x  => 40,     -- X coordinate of the pop-up window
      p_popup_y  => 90,     -- X coordinate of the pop-up window
      p_popup_w  => 140,    -- Width of the pop-up window
      p_popup_h  => 50,     -- Height of the pop-up window
      p_open => true        -- A flag specifying whether the pop-up window should initially be displayed open.
      );
    
    /* Returns the generated PDF document. 
         The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure FileAnnotation is
  l_blob blob;
  l_blob2 blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Get file from STORE_BLOB */
    select x.blob_file
      into l_blob2
     from store_blob x
     where rownum < 2;

   
   /* Add File annotation to the current page. */
   plpdf.AddFileAnnot(
     p_name => 'Paperclip',       -- The name of an icon to be used in displaying the annotation.
     p_contents => 'Oracle Database 10g has unique security features that ' || 
                   'address requirements in the areas of privacy, ' || 
                   'regulatory compliance, and data consolidation, ' || 
                   'including row-level security, fine grained auditing, ' || 
                   'and transparent data encryption.', 
                   /* The text to be displayed in the pop-up window when the 
                      annotation is opened. */
     p_x => 20,                   -- X coordinate of the annotation
     p_y => 20,                   -- Y coordinate of the annotation
     p_filename => '1.pdf',       -- name of file
     p_fileblob => l_blob2,       -- BLOB containing the PDF as binary data
     p_label => 'Industry-Leading Security', 
                  /* The text label to be displayed in the title bar of the 
                     annotation�s pop-up window when open and active. */
     p_color => plpdf_const.Lime  -- This color will be used.(see User Guide)
     );
     
    /* Returns the generated PDF document. 
         The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure MarkupAnnotation is
  l_blob blob;
  l_x number;
  l_y number;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 

    /* Gets the X coordinate of the cursor. */
    l_x := plpdf.GetCurrentX ; 
    /* Gets the Y coordinate of the cursor */
    l_y := plpdf.GetCurrentY;

    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 80,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Highlight Annotation'    -- Text in rectangle 
     ); 

    /* Add HighLight annotation to the current page. */
    plpdf.AddHighLightAnnot(
     p_contents => 'With Oracle Database 10g, the first relational database ' || 
                   'designed for Grid Computing, your information is always ' || 
                   'available and secure. Oracle Database 10g lowers the cost ' || 
                   'of ownership through automated management while providing ' || 
                   'the highest possible quality of service. And with Release 2, ' || 
                   'Oracle builds on Release 1''s foundation to further improve ' || 
                   'efficiencies and reduce the cost of information management. ' || 
                   'Oracle is the best choice for large enterprises, ' || 
                   'small and midsize businesses, and departments alike.',
                   /* The text to be displayed in the pop-up window when the annotation is opened. */
     p_x => l_x,                        -- X coordinate of the annotation
     p_y => l_y + 1,                    -- Y coordinate of the annotation
     p_w => 50,                         -- Width of the annotation
     p_h => 7,                          -- Height of the annotation
     p_label => 'The First Database Designed for Grid Computing',
                    /* The text label to be displayed in the title bar of the 
                    annotation�s pop-up window when open and active. */
     p_color => plpdf_const.Lime,       -- This color will be used.(see User Guide)
     p_popup_x => l_x,                  -- X coordinate of the pop-up window
     p_popup_y => l_y + 7,              -- Y coordinate of the pop-up window
     p_popup_w => 80,                   -- Width of the pop-up window
     p_popup_h => 50                    -- Height of the pop-up window
     );

    /* Places the cursor at the Y coordinate. */
    plpdf.SetCurrentY(
     p_y => l_y + 50                    -- Y coordinate
    );

    /* Gets the Y coordinate of the cursor */
    l_y := plpdf.GetCurrentY;

    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 80,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'StrikeOut Annotation'    -- Text in rectangle 
     );

   /* Add StrikeOut annotation to the current page. */
    plpdf.AddStrikeOutAnnot(
     p_contents => 'Oracle Database 10g delivers the response times your users' ||
                   'demand and reduces your cost of downtime. And only Oracle ' || 
                   'offers non-stop availability, scalability, and low-cost ' || 
                   'clustering with Oracle Real Application Clusters, ' || 
                   'the foundation for Grid Computing.',
                   /* The text to be displayed in the pop-up window 
                      when the annotation is opened. */
     p_x => l_x,                        -- X coordinate of the annotation
     p_y => l_y + 1,                    -- Y coordinate of the annotation
     p_w => 50,                         -- Width of the annotation
     p_h => 7,                          -- Height of the annotation
     p_label => 'Availability and Scalability with Grid Computing',
                   /* The text label to be displayed in the title bar of the 
                      annotation�s pop-up window when open and active. */
     p_color => plpdf_const.Turquoise,  -- This color will be used.(see User Guide)
     p_popup_x => l_x,                  -- X coordinate of the pop-up window
     p_popup_y => l_y + 7,              -- Y coordinate of the pop-up window
     p_popup_w => 80,                   -- Width of the pop-up window
     p_popup_h => 50                    -- Height of the pop-up window
     );

    /* Places the cursor at the Y coordinate. */
    plpdf.SetCurrentX(
     p_x => l_X + 100                   -- X coordinate
     );

    /* Gets the X coordinate of the cursor */
    l_x := plpdf.GetCurrentX;

    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 80,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Underline Annotation'    -- Text in rectangle 
     );

    /* Add Underline annotation to the current page. */
    plpdf.AddUnderlineAnnot(
     p_contents => 'Oracle automates time-consuming, error-prone administrative ' || 
                   'tasks, so DBAs can focus on strategic business objectives. ' || 
                   'Studies from the Edison Group prove Oracle Database 10g ' || 
                   'offers superior manageability and significant cost savings ' || 
                   'over IBM DB2 8.2 as well as Microsoft SQL Server 2000.',
                   /* The text to be displayed in the pop-up window when the 
                   annotation is opened. */
     p_x => l_x,                        -- X coordinate of the annotation
     p_y => l_y + 1,                    -- Y coordinate of the annotation
     p_w => 50,                         -- Width of the annotation
     p_h => 7,                          -- Height of the annotation
     p_label => 'Lower Costs with the Self-Managing Database',
                   /* The text label to be displayed in the title bar of the 
                      annotation�s pop-up window when open and active. */
     p_color => plpdf_const.Violet,     -- This color will be used.(see User Guide)
      p_popup_x => l_x,                 -- X coordinate of the pop-up window
     p_popup_y => l_y + 7,              -- Y coordinate of the pop-up window
     p_popup_w => 80,                   -- Width of the pop-up window
     p_popup_h => 50                    -- Height of the pop-up window
     );
     
    /* Returns the generated PDF document. 
         The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure ScreenAnnotation is
  l_blob blob;
  l_file blob;
  begin
     /* Select another PDF into l_pdf */ 
    select blob_file
      into l_file 
     from store_BLOB
     where rownum < 2;
     
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     );
     
     /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 80,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'ScreenAnnotation'    -- Text in rectangle 
     );
     
     /* Draws a rectangle on the page. */
    plpdf.DrawRect(
    p_x => 10,           -- X coordinate for the top left corner of the rectangle
    p_y => 20,           -- Y coordinate for the top left corner of the rectangle
    p_w => 50,          -- Rectangle width
    p_h => 50,           -- Rectangle height
    p_style => 'D'       -- Style: border
    );
    
    /* Draws a rectangle on the page. */
    plpdf.DrawRect(
    p_x => 80,           -- X coordinate for the top left corner of the rectangle
    p_y => 20,           -- Y coordinate for the top left corner of the rectangle
    p_w => 50,          -- Rectangle width
    p_h => 50,           -- Rectangle height
    p_style => 'D'       -- Style: border
    );
     
     /* A screen annotation specifies a region of a page upon which media clips may be played.
       Source of the media is an URL. */
     plpdf.AddScreenAnnotURL(
     p_name => 'ScreenAnnotationURL' ,      -- Name of the media clip.
     p_x => 10 ,                           -- X coordinate of the annotation
     p_y => 20,                           -- Y coordinate of the annotation
     p_w => 50,                           -- width of the annotation
     p_h => 50,                           -- height of the annotation
     p_url => 'http://www.plpdf.com',   -- URL of the annotation
     p_mime => '',                        -- MIME type of the annotation
     p_event => null                    -- dditional action when play annotation, (null - default)
     );
     
     /* A screen annotation specifies a region of a page upon which media clips may be played.
      Source of the media is an BLOB. */
     plpdf.AddScreenAnnotFile(
     p_name => 'ScreenAnnotationFile' ,     -- Name of the media clip.
     p_x => 80 ,                           -- X coordinate of the annotation
     p_y => 20,                           -- Y coordinate of the annotation
     p_w => 50,                           -- width of the annotation
     p_h => 50,                           -- height of the annotation
     p_fileblob => l_file,                -- File of the annotation
     p_mime => '',                        -- MIME type of the annotation
     p_event => null                    -- dditional action when play annotation, (null - default)
     );
      
    /* Returns the generated PDF document. 
         The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES(l_blob,sysdate);
    commit;
    end;
    
procedure ChineseFont is
  l_blob blob;
  l_chinese varchar2(2000 char);
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Create a new page. Without parameters the default page orientation: portrait. */
    plpdf.NewPage;
    
    /* Create a chinese text */
    l_chinese := UNISTR(
               '\53d6\6e96\53d7\4fdd\4eba\5728\6211\56fd\7ecf\6d4e\7ed3\6784'
            || '\8fdb\884c\6218\7565\6027\8c03\6574\7684'
            || '\80CC\666F\4e0B\ff0c\4FE1\606f\4ea7\4e1a'
            || '\5c06\6210\4E3A\62c9\52A8\7ecf\6d4e\589e'
            || '\957f\7684\65b0\52A8\529b\ff0c\800c\4f5c'
            || '\4E3A\4FE1\606f\6280\672f\6838\5fc3\4e4b'
            );    
       
    /* Add CJK (Chinese/Japanese/Korean) font. */
    plpdf.AddCJKFont(
      plpdf_const.font_chinese_GB -- Name of font
      );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => plpdf_const.font_chinese_GB,   -- Font family: STSongStd-Light-Acro 
     p_style => null,                             -- Font style: regular (default)
     p_size => 12                                 -- Font size: 12 pt
     ); 
    
    /* Draws a multi line cell. */
    plpdf.PrintMultiLineCell(
     p_w => 50, -- Rectangle width
     p_h => 10, -- Rectangle height
     p_txt => l_chinese -- Variable containing the chinese text
     );
     
    /* Returns the generated PDF document. 
         The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

  
procedure WithoutTOC is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.HeaderTOC1',    -- Page header procedure name
     p_height => 10                     -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.footerTOC1',    --Page footer procedure name
     p_height => 10                     --Height of footer section
     );
    
   
    /* Page 1 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 1'                  -- Text in rectangle 
     );
  
    
    /* Page 2 */
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
           
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 2'                  -- Text in rectangle 
     );
   
   
    /* Page 3 */
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
           
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 3'                  -- Text in rectangle 
     );
   
   
    /* Page 4 */
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
           
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 4'                  -- Text in rectangle 
     );
   
   
    /* Page 5 */
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
           
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 5'                  -- Text in rectangle 
     );
    
    /* Returns the generated PDF document. 
         The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
  
procedure HeaderTOC1 is

  
  begin
     /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => 'BU',        -- Font style: Bold and Underline
     p_size => 12            -- Font size: 12 pt
     ); 
    
    /* Page title */
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 0,                          -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page title text',        -- Text in rectangle 
     p_border => '0',                   -- Without frame
     p_ln => '0',                       -- Cursor position after the cell is printed: Beside  
     p_align => 'C'                     -- Text alignment: Center
     );   
  end;
  
procedure FooterTOC1 is

  
  begin
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => 'I',        -- Font style: regular (default)
     p_size => 8            -- Font size: 12 pt
     ); 
     
    /*Number of page*/
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 0,                          -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => To_CHAR(plpdf.CurrentPageNumber), -- Text in rectangle 
     p_border => '0',                   -- Without frame
     p_ln => '0',                       -- Cursor position after the cell is printed: Beside the cell  
     p_align => 'C'                     -- Alignment: Center
     ); 
  end;
 
procedure MinimalTOC is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'BasicExamples.HeaderTOC1',    -- Page header procedure name
     p_height => 10                     -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'BasicExamples.FooterTOC1',    --Page footer procedure name
     p_height => 10                     --Height of footer section
     );
   
    
    /* Page 1 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 1'                   -- Label of TOC item
     );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 1'                  -- Text in rectangle 
     );
   
    
    /* Page 2 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 2'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 2'                  -- Text in rectangle 
     );
   
   
    /* Page 3 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 3'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 3'                  -- Text in rectangle 
     );
   
    
    /* Page 4 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 4'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 4'                  -- Text in rectangle 
     );
   
    /* Construct Table of Contents. */ 
    plpdf.AddTOC(
     p_item_height => 10                -- Height of TOC item cell
     );
    
    /* Returns the generated PDF document. 
         The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure NormalTOC is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.HeaderTOC1',    -- Page header procedure name
     p_height => 10                     -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.FooterTOC1',    --Page footer procedure name
     p_height => 10                     --Height of footer section
     );
   
    
    /* Page 1 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 1'                   -- Label of TOC item
     );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 1'                  -- Text in rectangle 
     );
   
    
    /* Page 2 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 2'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 2'                  -- Text in rectangle 
     );
   
    
    /* Page 3 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 3'                   -- Label of TOC item
     );
   
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 3'                  -- Text in rectangle 
     );
   
    
    /* Page 4 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 4'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 4'                  -- Text in rectangle 
     );
   
    /* Construct Table of Contents. */  
    plpdf.AddTOC(
     p_item_height => 10,               -- Height of TOC item cell
     p_title_font_family => 'Courier',  -- Font family of title text
     p_title_font_style => 'BU',        -- Font style of title text
     p_title_font_size => 15,           -- Font size of title text
     p_title_height => 20,              -- Height of title's cell
     p_title_text => 'Table of Contents',  -- Title of TOC
     p_title_body_gap => 20,            -- Gap between title and TOC items
     p_separator => '.'                 -- Filler between TOC item and page number
     );
    
    /* Returns the generated PDF document. 
         The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
    p_blob => l_blob  -- The generated document
    );
    
    /* Print it:
      
    owa_util.mime_header('application/pdf',false);
          htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
          owa_util.http_header_close; 	
          wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure MovetoTOC is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.HeaderTOC1',    -- Page header procedure name
     p_height => 10                     -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.FooterTOC1',    --Page footer procedure name
     p_height => 10                     --Height of footer section
     );
     
    
    /* Page 1 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 1'                   -- Label of TOC item
     );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 1'                  -- Text in rectangle 
     );
   
    
    /* Page 2 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 2'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 2'                  -- Text in rectangle 
     );
   
    
    /* Page 3 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 3'                   -- Label of TOC item
     );
   
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 3'                  -- Text in rectangle 
     );
   
    
    /* Page 4 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 4'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 4'                  -- Text in rectangle 
     );
    
    /* Construct Table of Contents. */  
    plpdf.AddTOC(
     p_item_height => 10,               -- Height of TOC item cell
     p_title_font_family => 'Courier',  -- Font family of title text
     p_title_font_style => 'BU',        -- Font style of title text
     p_title_font_size => 15,           -- Font size of title text
     p_title_height => 20,              -- Height of title's cell
     p_title_text => 'Table of Contents',  -- Title of TOC
     p_title_body_gap => 20,            -- Gap between title and TOC items
     p_separator => '.',                -- Filler between TOC item and page number
     p_move_to => 1                     -- Move TOC pages to a new page number in PDF
     );
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;  

procedure CoverPageTOC is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.HeaderTOC1',    -- Page header procedure name
     p_height => 10                     -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.FooterTOC2',    --Page footer procedure name
     p_height => 10                     --Height of footer section
     );
   
    
    /* Cover Page */   
   
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => 'B',                    -- Font style: Bold
     p_size => 14                       -- Font size: 14 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Cover Page'              -- Text in rectangle 
     );
   
    
    /* Page 1 */
   
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 1'                   -- Label of TOC item
     );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 1'                  -- Text in rectangle 
     );
   
    
    /* Page 2 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 2'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 2'                  -- Text in rectangle 
     );
   
   
    /* Page 3 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 3'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 3'                  -- Text in rectangle 
     );
    
    /* Construct Table of Contents. */  
    plpdf.AddTOC(
     p_item_height => 10,               -- Height of TOC item cell
     p_title_font_family => 'Courier',  -- Font family of title text
     p_title_font_style => 'BU',        -- Font style of title text
     p_title_font_size => 15,           -- Font size of title text
     p_title_height => 20,              -- Height of title's cell
     p_title_text => 'Table of Contents',  -- Title of TOC
     p_title_body_gap => 20,            -- Gap between title and TOC items
     p_separator => '.',                -- Filler between TOC item and page number
     p_move_to => 2                     -- Move TOC pages to a new page number in PDF
     );
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure FooterTOC2 is
  
  
  begin
   /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => 'I',        -- Font style: regular (default)
     p_size => 8            -- Font size: 12 pt
     ); 
    
    /* CurrentPageNumber: Returns the page number of the current page. */
    if plpdf.CurrentPageNumber > 1 then -- If true then cover page
      /*Number of page*/
      /* Draws a rectangle cell with text inside. */
      plpdf.PrintCell(
       p_w => 0,                          -- Rectangle width
       p_h => 10,                         -- Rectangle heigth
       p_txt => To_CHAR(plpdf.CurrentPageNumber -1), -- Text in rectangle 
       p_border => '0',                   -- Without frame
       p_ln => '0',                       -- Cursor position after the cell is printed: Beside the cell  
       p_align => 'C'                     -- Alignment: Center
       ); 
    end if;  
  end; 

procedure DifferentFooter is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.HeaderTOC1',    -- Page header procedure name
     p_height => 10                     -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.FooterTOC3',    --Page footer procedure name
     p_height => 10                     --Height of footer section
     );
   
    
    /* Page 1 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 1'                   -- Label of TOC item
     );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 1'                  -- Text in rectangle 
     );
   
    
    /* Page 2 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 2'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 2'                  -- Text in rectangle 
     );
   
    
    /* Page 3 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 3'                   -- Label of TOC item
     );
   
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 3'                  -- Text in rectangle 
     );
   
    
    /* Page 4 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 4'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 4'                  -- Text in rectangle 
     );
    
    /* Construct Table of Contents. */  
    plpdf.AddTOC(
     p_item_height => 10,               -- Height of TOC item cell
     p_title_font_family => 'Courier',  -- Font family of title text
     p_title_font_style => 'BU',        -- Font style of title text
     p_title_font_size => 15,           -- Font size of title text
     p_title_height => 20,              -- Height of title's cell
     p_title_text => 'Table of Contents',  -- Title of TOC
     p_title_body_gap => 20,            -- Gap between title and TOC items
     p_separator => '.',                -- Filler between TOC item and page number
     p_move_to => 1,                    -- Move TOC pages to a new page number in PDF
     p_stop_footer => false             -- Do not print footer in TOC: false
     );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure FooterTOC3 is
  l_blob blob;
  
  begin
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => 'I',        -- Font style: regular (default)
     p_size => 8            -- Font size: 12 pt
     ); 
    
    /* InToc: Is current position inside TOC */
    if plpdf.InTOC then 
      /* Draws a rectangle cell with text inside. */
      plpdf.PrintCell(
       p_w => 0,                          -- Rectangle width
       p_h => 10,                         -- Rectangle heigth
       p_txt => lower(TO_CHAR(Plpdf.GetTOCPageNum,'RM')), -- Text in rectangle 
       p_border => '0',                   -- Without frame
       p_ln => '0',                       -- Cursor position after the cell is printed: Beside the cell  
       p_align => 'C'                     -- Alignment: Center
      ); 
    else
      plpdf.PrintCell(
       p_w => 0,                          -- Rectangle width
       p_h => 10,                         -- Rectangle heigth
       p_txt => TO_CHAR(Plpdf.CurrentPageNumber), -- Text in rectangle 
       p_border => '0',                   -- Without frame
       p_ln => '0',                       -- Cursor position after the cell is printed: Beside the cell  
       p_align => 'C'                     -- Alignment: Center
       ); 
    end if;

  end;


procedure TestTOC1Custom is
  l_toc plpdf_type.t_toc;
  
  begin
    /* Print title */
      
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Courier',         -- Font family: Arial
     p_style => 'B',                -- Font style: regular (default)
     p_size => 15                   -- Font size: 12 pt
     ); 
  
    /* Insert title section in TOC (for creating custom TOC). */
    plpdf.PrintTOCTitle(
     p_toc_title_text => 'Table of Contents', -- Text of title
     p_toc_title_height => 20       -- Height of title's cell
     );

    /* Insert gap between title and items (for creating custom TOC). */
    plpdf.TOCInsertGap(
     p_toc_title_body_gap => 20     -- Size of gap
     );

    
    /* Print items */
  
    /* Returns array of TOC items (for creating custom TOC). */
    l_toc := plpdf.GetTOCItems;
  
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',           -- Font family: Arial
     p_style => null,               -- Font style: regular (default)
     p_size => 12                   -- Font size: 12 pt
     ); 
     
    for l_i in 1..l_toc.count loop
        /* Print a TOC Item into the PDF (for creating custom TOC). */
        plpdf.PrintTOCItem(
         p_item => l_toc(l_i),      -- TOC Item
         p_toc_level_indent  => 0,  -- indent size for levels
         p_toc_item_height => 10,   -- height of TOC item cell
         p_toc_separator => '.'     -- filler between TOC item and page number
         );
  end loop;
  end;

procedure CustomTOC is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm 
     - default page format: A4 */
    plpdf.Init;
    
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.HeaderTOC1',    -- Page header procedure name
     p_height => 10                     -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.FooterTOC1',    --Page footer procedure name
     p_height => 10                     --Height of footer section
     );
   
    
    /* Page 1 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 1'                   -- Label of TOC item
     );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 1'                  -- Text in rectangle 
     );
   
    
    /* Page 2 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 2'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 2'                  -- Text in rectangle 
     );
   
    
    /* Page 3 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 3'                   -- Label of TOC item
     );
   
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 3'                  -- Text in rectangle 
     );
   
    
    /* Page 4 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 4'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 4'                  -- Text in rectangle 
     );
    
    /* Construct Table of Contents. */
    plpdf.AddTOC(
     p_custom_proc => 'BasicExamples.TestTOC1Custom' -- The name of the custom procedure which is used for creating TOC
     );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure ProfTOC is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'basicexamples.HeaderTOC1',    -- Page header procedure name
     p_height => 10                     -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'basicexamples.FooterTOC1',    --Page footer procedure name
     p_height => 10                     --Height of footer section
     );
   
    /* Page 1 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'Content 1',                   -- Label of TOC item
     p_add_link => true,                     -- create link from TOC item to page
     p_add_bookmark => true                  -- create bookmark for TOC item
     );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 1'                  -- Text in rectangle 
     );
   
    
    /* Page 2 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'Content 1.2',                   -- Label of TOC item
     p_level => 1,                             -- level, 0 is the highest level
     p_add_link => true,                       -- create link from TOC item to page
     p_add_bookmark => true                    -- create bookmark for TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 2'                  -- Text in rectangle 
     );
    
    /* Cursor is placed at the start of the next line. */
    plpdf.LineBreak(
    p_h => 150          -- Height of the line break.
    );
    
    
    
   
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Content 1.3'                  -- Text in rectangle 
     );
     
     /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'Content 1.3',                   -- Label of TOC item
     p_level => 1,                             -- level, 0 is the highest level
     p_add_link => true,                       -- create link from TOC item to page
     p_add_bookmark => true                    -- create bookmark for TOC item
     );
   
    
    /* Page 4 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'Content 2',                   -- Label of TOC item
     p_level => 0,                           -- level, 0 is the highest level
     p_add_link => true,                     -- create link from TOC item to page
     p_add_bookmark => true                  -- create bookmark for TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 4'                  -- Text in rectangle 
     );
    
    /* Construct Table of Contents. */
    plpdf.AddTOC(
    p_item_height => 10,                -- height of TOC item cell
    p_title_font_family => 'Arial',     -- font family of title text: Arial
    p_title_font_style => 'I',          -- font style: Italic          
    p_title_font_size => 14,            -- font size: 14
    p_title_height => 20,               -- height of title's cell         
    p_title_text => 'Table of Contents',-- title of TOC
    p_title_body_gap => 15,             -- gap between title and TOC items
    p_item_font_family => 'Courier',    -- ont family of TOC items: Courier
    p_item_font_style => null,          -- font style of TOC items: Regular
    p_item_font_size => 12,             -- font size: 12
    p_separator => '.',                 -- filler between TOC item and page number
    p_move_to => 1,                     -- move TOC pages to a new page number in PDF
    p_level_indent => 2                 -- indent size for levels
    );
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
 
procedure InsMoveTOC is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    /*Sets the page header procedure name. The program name passed 
      as a parameter executes when the page header is created. */
    plpdf.SetHeaderProcName(
     p_proc_name => 'BasicExamples.HeaderTOC1',    -- Page header procedure name
     p_height => 10                     -- Height of header section
     );
    
    /* Sets the page footer procedure name. The program name passed
       as a parameter executes when the page footer is created. */
    plpdf.SetFooterProcName(
     p_proc_name => 'BasicExamples.FooterTOC1',    --Page footer procedure name
     p_height => 10                     --Height of footer section
     );
   
    
    /* Page 1 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 1'                   -- Label of TOC item
     );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 1'                  -- Text in rectangle 
     );
   
    
    /* Page 2 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 2'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 2'                  -- Text in rectangle 
     );
   
   
    /* Page 3 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 3'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 3'                  -- Text in rectangle 
     );
   
    
    /* Page 4 */
     
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Add Table of Contents item. */
    plpdf.AddTOCItem(
     p_txt => 'TOC 4'                   -- Label of TOC item
     );
     
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 50,                         -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page 4'                  -- Text in rectangle 
     );
   
    /* Construct Table of Contents. */ 
    plpdf.AddTOC(
     p_item_height => 10                -- Height of TOC item cell
     );

    /* Move TOC to specified page number. */
    plpdf.InsMoveTOC(
    p_move_to => 2
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;   
  

procedure PrintText is
  l_blob blob;
  
  begin
      /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Begin a new page, without parameters means: - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',           -- Font family: Arial
     p_style => null,               -- Font style: regular (default)
     p_size => 12                   -- Font size: 12 pt
     ); 
    
    /* Prints a text starting from the specified position. */
    plpdf.PrintText(
     p_x => 50,                     -- X coordinate for the start of the text
     p_y => 50,                     -- Y coordinate for the start of the text
     p_txt => 'Print Text Example'  -- Text
     );
     
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure Acroform is
  l_blob blob;
  l_values  plpdf_type.t_opt_array;
  l_rb      plpdf_type.t_radiobutton_array;
  
  begin   
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Begin a new page, without parameters means: - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 12                       -- Font size: 12 pt
     ); 
    
    
    /* Add TextField. */
    plpdf.AcroForm_AddTextField(
     p_name => 'test1text',             -- Identifier of object
     p_value => 'Apple',                -- Value of field
     p_default_value => 'Default',      -- The default value
     p_x => 10,                         -- X coordinate for the field
     p_y => 20,                         -- Y coordinate for the field
     p_width => 100,                    -- The width of the field
     p_height => 30,                    -- The height of the field
     p_border_width => 0.2,             -- width of border
     p_border_color => plpdf_const.Lime,-- Color of border
     p_fill_color => plpdf_const.Spring_Green, -- Color for filling the field
     p_hint => 'initialize, without parameters means: ' || 
               'page orientation: portrait, unit: mm, ' || 
               'default page format: A4'-- Messages for the field
     );
   
    /* Add choicefield values */
    l_values(1) := 'ONE';
    l_values(2) := 'TWO';
    l_values(3) := 'THREE';
   
    /* Add ChoiceField. */
    plpdf.AcroForm_AddChoiceField(
     p_name => 'ch1',                   -- Identifier of object
     p_values => l_values,              -- Value set of field
     p_value => 'TWO',                  -- Value of field
     p_default_value => 'ONE',          -- The default value
     p_combo => true,                   -- If set, the field is a combo box
     p_x => 10,                         -- X coordinate for the field
     p_y => 70,                         -- Y coordinate for the field
     p_width => 100,                    -- The width of the field
     p_height => 10,                    -- The height of the field
     p_border_width => 0.2,             -- width of border
     p_hint => 'Oracle Application Express (Oracle APEX), ' || 
               'formerly called HTML DB, is a rapid web' 
               -- Messages for the field
     );
       
    /* Add Pushbutton */
    plpdf.AcroForm_AddPushbutton(
     p_name => 'pb1',                   -- Identifier of object
     p_label => 'Say Hello!',           -- Caption of button
     p_x => 10,                         -- X coordinate for the field
     p_y => 110,                        -- Y coordinate for the field
     p_width => 50,                     -- The width of the field
     p_height => 10,                    -- The height of the field
     p_action => plpdf_const.button_action_javascript,  -- Set supported action
     p_javascript => 'app.alert("Hello!");',  -- JavaScript for execution
     p_fill_color => plpdf_const.Light_Grey,  -- Color for filling the field
     p_border_width => 0.3,                   -- Width of border of the field
     p_border_color => plpdf_const.Steelblue, -- Color of border
     p_font_size_auto => true,                -- The text size automatic
     p_hint => 'Oracle Application Express (Oracle APEX), ' || 
               'formerly called HTML DB, is a rapid web'  
                -- messages for the field
     );
         
    /* Add Pushbutton */     
    plpdf.AcroForm_AddPushbutton(
     p_name => 'pb2',                   -- Identifier of object
     p_label => 'Reset',                -- Caption of button
     p_x => 70,                         -- X coordinate for the field
     p_y => 110,                        -- Y coordinate for the field
     p_width => 50,                     -- The width of the field
     p_height => 10,                    -- The height of the field
     p_action => plpdf_const.button_action_resetform, -- Set supported action
     p_border_width => 0.3,                   -- Width of border of the field
     p_border_color => plpdf_const.Steelblue, -- Color of border
     p_font_size_auto => true,                -- The text size automatic
     p_hint => 'Oracle Application Express (Oracle APEX), ' || 
               'formerly called HTML DB, is a rapid web'  
               -- Messages for the field
     );
         
    /* Begin a new page, without parameters means: 
      page orientation: default (portrait) */
    plpdf.NewPage;
         
    /* Set values of RadioButtonfield */ 
    l_rb(1).value := 'one';
    l_rb(1).x := 10;
    l_rb(1).y := 10;
    l_rb(1).label := 'Choose the ONE!';
    
    l_rb(2).value := 'two';
    l_rb(2).x := 10;
    l_rb(2).y := 30;
    l_rb(2).label := 'Or choose the TWO!';
         
    
    /* Add Radiobutton field */
    plpdf.AcroForm_AddRadiobuttonField(
     p_name => 'radio1',                -- Identifier of object
     p_values => l_rb,                  -- Value set of field
     p_value => 'one',                  -- Value of field
     p_default_value => 'one',          -- The default value of field
     p_read_only => false,              -- If set, the user may not change the value
     p_required => false,               -- If set, the field must have a value
     p_NoToggleToOff  => false,         -- If set, exactly one radio button must be selected
     p_height => 10,                    -- The height of the field
     p_gap => 2,                        -- Gap bettween graphical symbol and text
     p_fill_color => plpdf_const.dark_khaki,  -- Color for filling the field
     p_hint => 'Oracle Application Express (Oracle APEX), ' || 
               'formerly called HTML DB, is a rapid web' 
               -- Message for the field
     );   
   
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                   -- Font style: regular (default)
     p_size => 10                       -- Font size: 12 pt
     );
   
    plpdf.AcroForm_AddCheckBoxField(
     p_name => 'cb1',                   -- Identifier of object
     p_label => 'Try it!',              -- Caption of checkbox
     p_checked => false,                -- If set, the checkbox is checked
     p_default_checked => false,        -- The default value
     p_read_only => false,              -- If set, the user may not change the value
     p_required => false,               -- If set, the field must have a value
     p_x => 10,                         -- X coordinate for the field
     p_y => 70,                         -- Y coordinate for the field
     p_height => 30,                    -- The height of the field
     p_gap => 0,                        -- Gap bettween graphical symbol and text
     p_fill_color => plpdf_const.Black, -- Color for filling the field
     p_hint => 'Oracle Application Express (Oracle APEX), ' || 
               'formerly called HTML DB, is a rapid web' 
               -- Message for field
     );  
     
      /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure TextSetRTOL is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Set text direction Right to Left. 
        Set RtoL is an initialization procedure, 
        therefore it may only be used once.
        null: only LtoR text
        false: LtoR text with some RtoL text in it
        */
        
    plpdf.setRTOL(
    p_full => true   -- True: full RtoL with right alignment by default
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 14                       -- Font size: 14 pt
     ); 
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_txt => 'Sample Text'  -- Text in rectangle
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure SetAutoNewPage is
  l_blob blob;
  
  begin
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /*
    Enables or disables automatic page breaks. The p_margin parameter is
    only relevant when enabling automatic page breaks. It sets the bottom
    margin size under which an automatic page break is triggered.
    */
    plpdf.SetAutoNewPage(
    p_auto => true,   -- Automatic page break
    p_margin => 200   -- Bottom margin size, if not set, then 1 cm
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 14                       -- Font size: 14
     );
    
    /* Draw multiline cell with text inside */
    plpdf.PrintMultiLineCell(
    p_w => 0,          -- Rectangle width
    p_h => 20,         -- Rectangle height
    p_txt => 'Generate dynamic PDF documents from data stored in Oracle databases ' ||
            'using the PL/PDF program package. PL/PDF is written exclusively in PL/SQL. ' ||
            'It is able to either store the generated PDF document in the database or ' ||
            'provide the results directly to a browser using MOD_PLSQL. No third-party ' ||
            'software is needed; PL/PDF only uses tools provided by the installation ' ||
            'package of an Oracle Database. Use PL/PDF to quickly and easily develop ' ||
            'applications with dynamic content but also quality ' ||
            'presentation and printing capabilities.' -- Text
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure SetCompress is
  l_blob blob;
  
  begin
     /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
     /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Enables or disables the compression of PDF documents. 
       By default compression is enabled. */
    plpdf.SetCompress(
	  p_compress => true,                    -- Compression 
    p_method => plpdf_const.comp_LZWDecode   -- plpdf_const.comp_FlateDecode: FlateDecode (Java) / plpdf_const.comp_LZWDecode: LZWDecode / plpdf_const.comp_PLDeflate: FlateDecode (PL/SQL)
    );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_txt => 'Compressed file'        -- Text in rectangle
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

  
procedure SetNOLastpageProcName is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
     /* Sets the not last page procedure name. 
       The program name passed as a parameter
       executes when the not last page closed.*/
    plpdf.SetNOLastpageProcName(
    p_proc_name => 'basicexamples.notlastpage'      -- Procedure name
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 1',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 2',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Begin a new page, without parameters means: - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 3',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 4',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
     /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
    
     /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 5',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;
  
procedure NotLastPage is
  l_blob blob;
  
  begin
    /* Add JavaScript inside the PDF. */
    Plpdf.setJS(
    p_text => 'this.print(true);' -- JavaScript source code: print pdf when open
    ); 
  end;
procedure InsertMovePage is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Insert a new page and move it by changing order of pages. */
    plpdf.InsertMovePage(
    p_orig_pos => 2,      -- origin page position
    p_new_pos => 5        -- new page position
    );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 1',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Begin a new page, without parameters means: - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 2',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 3',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 4',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
      
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 0,            -- Rectangle with
    p_h => 10,           -- Rectangle height
    p_txt => 'Page 5',   -- Text in rectangle
    p_border => '1'      -- Border: outline
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob                   -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;



procedure Opacity is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Set the fill color */
    plpdf.SetColor4Filling(
    p_r => 255,     -- Red component code. Number between 0 and 255
    p_g => 0,   	  -- Green component code. Number between 0 and 255
    p_b => 0        -- Blue component code. Number between 0 and 255
    );
    
    /* Draws a rectangle on the page */  
    plpdf.DrawRect(
    p_x => 10,           -- X coordinate for the top left corner of the rectangle
    p_y => 10,           -- Y coordinate for the top left corner of the rectangle
    p_w => 100,          -- The width of the rectangle
    p_h => 30,           -- The height of the rectangle
    p_style => 'F'       -- Style: fill, no border line
    );
    
    /* Starts a transparency. The transparency affects for
  objects wich located between StartOpacity and EndOpacity. */
    plpdf.StartOpacity(
    p_val => 0.5       -- can be a value from 0.0 - 1.0. A lower value makes the element more transparent.
    );
    
    /* Set the fill color */
    plpdf.SetColor4Filling(
    p_r => 255,     -- Red component code. Number between 0 and 255
    p_g => 0,   	  -- Green component code. Number between 0 and 255
    p_b => 0        -- Blue component code. Number between 0 and 255
    );
    
     /* Draws a rectangle on the page */  
    plpdf.DrawRect(
    p_x => 10,           -- X coordinate for the top left corner of the rectangle
    p_y => 60,           -- Y coordinate for the top left corner of the rectangle
    p_w => 100,          -- The width of the rectangle
    p_h => 30,           -- The height of the rectangle
    p_style => 'F'       -- Style: fill, no border line
    );
    
    /* End a transparency. */
    plpdf.EndOpacity;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => 'I',                    -- Font style: Italic
     p_size => 12	                       -- Font size: 12
     );
    
    /* Places the cursor at the X and Y coordinate.*/
    plpdf.SetCurrentXY(
    p_x => 110,
    p_y => 25
    );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_txt => 'No transparency'        -- Text in rectangle
    );
    
    /* Places the cursor at the X and Y coordinate.*/
    plpdf.SetCurrentXY(
    p_x => 110,          -- X coordinate
    p_y => 75            -- Y coordinate
    );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
    p_w => 100,          -- Rectangle width
    p_h => 10,           -- Rectangle height
    p_txt => '50% transparency'       -- Text in rectangle
    );
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;

procedure OptCont is
  l_blob blob;
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Start an optional content. */
    plpdf.StartOptCont(
    p_name => 'Name of Content',  -- name of optional content
    p_state => true,              -- default state is visible or invisible
    p_ui_order => false,          -- insert into the state array
    p_print => false              -- printed out
    );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => null,                    -- Font style: Regular
     p_size => 12	                       -- Font size: 12
     );
     
     /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 160,         -- Rectangle width             
     p_h => 50,          -- Rectangle height
     p_txt => 'Optional Content Area',  -- Text in rectangle
     p_border => '1'     -- Border: outline 
     ); 
    
    /* End an optional content. */
    plpdf.EndOptCont;
    
    /* Start an optional content. */
    plpdf.StartOptCont(
    p_name => 'Name of Content',  -- name of optional content
    p_state => false,              -- default state is visible or invisible
    p_ui_order => false,          -- insert into the state array
    p_print => false              -- printed out
    );
     
     /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 160,         -- Rectangle width             
     p_h => 50,          -- Rectangle height
     p_txt => 'Optional Content Area2',  -- Text in rectangle
     p_border => '1'     -- Border: outline 
     ); 
    
    /* End an optional content. */
    plpdf.EndOptCont;
    
    
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
       
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES(l_blob,sysdate);
    commit;
    end;

procedure TemplatePage is
  l_blob blob;
  
  begin
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.Init;
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',               -- Font family: Arial
     p_style => 'B',                    -- Font style: Regular
     p_size => 72	                       -- Font size: 72
     );
    
    /* Sets the text color for objects inserted after this statement.
  Colors must be specified according to the RGB pallet.*/
    plpdf.SetColor4Text(
     p_r => 255,           -- Red component code. Number between 0 and 255           
     p_g => 230,           -- Green component code. Number between 0 and 255 
     p_b => 230            -- Blue component code. Number between 0 and 255 
     );	    
    
    /* Places the cursor at the X and Y coordinate. */
    plpdf.SetCurrentXY(
     p_x => 25,          -- X coordinate
     p_y => 10           -- Y coordinate       
    );
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 160,         -- Rectangle width             
     p_h => 50,          -- Rectangle height
     p_txt => 'TEMPLATE!'  -- Text in rectangle
     ); 
    
    /* Places the cursor at the X and Y coordinate. */
    plpdf.SetCurrentXY(
     p_x => 25,          -- X coordinate                 
     p_y => 110          -- Y coordinate                  
    );
    
    plpdf.PrintCell(
     p_w => 160,         -- Rectangle width              
     p_h => 50,          -- Rectangle height            
     p_txt => 'TEMPLATE!'-- Text in rectangle
     ); 
     
    /* Places the cursor at the X and Y coordinate. */ 
    plpdf.SetCurrentXY(
     p_x => 25,          -- X coordinate                 
     p_y => 210          -- Y coordinate                 
    );
    
    plpdf.PrintCell(
     p_w => 160,         -- Rectangle width             
     p_h => 50,          -- Rectangle height              
     p_txt => 'TEMPLATE!' -- Text in rectangle
     ); 

    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES (l_blob,sysdate);
    commit;
  end;  

procedure template_init is
  
  l_pdf blob;
begin
  
  /* Select template PDF*/
  select t.orig_pdf
     into l_pdf
   from plpdf_template t
   where id = 1;
   
   /* Parsing data */
   v_tpl := plpdf_parser.GetTemplate(
   p_blob => l_pdf,
   p_page_id => 1
   );
   
end;


/* Procedure which use the template page */
procedure template_eg is
  
  l_blob blob;
  l_tpl_id number;
 begin
    /* Select template PDF*/
    template_init;
    
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.init; 
    
    /* Insert a template into the pdf.
       Return: Template ID */
    l_tpl_id := plpdf.InsTemplate(
                 p_tpl => v_tpl   -- Template data
                 );
                  
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Use a template. */
    plpdf.useTemplate(
     p_tplidx => l_tpl_id         -- Template ID
     );
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',         -- Font family: Arial
     p_style => null,             -- Font style: regular (default)
     p_size => 12                 -- Font size: 12 pt
     ); 
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,                   -- Rectangle width
     p_h => 10,                   -- Rectangle heigth
     p_txt => 'Template Example'  -- Text in rectangle 
     );
     
     /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',         -- Font family: Arial
     p_style => null,             -- Font style: regular (default)
     p_size => 12                 -- Font size: 12 pt
     ); 
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,                   -- Rectangle width
     p_h => 10,                   -- Rectangle heigth
     p_txt => 'Template Example'  -- Text in rectangle 
     );
       
       
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */ 
     insert into STORE_BLOB (blob_file, created_date) values (l_blob, sysdate);   
    commit;
 end;

procedure DefaultTemplate is
  l_blob blob;
  l_tpl_id number;
  begin
    /* Select template PDF*/
    template_init;
    
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
     plpdf.Init;
     
     /* Insert a template into the pdf.
       Return: Template ID */
    l_tpl_id := plpdf.InsTemplate(
                 p_tpl => v_tpl   -- Template data
                 );
     
     plpdf.DefaultTemplate(
     p_tplidx => l_tpl_id,       -- template ID
     p_fittopage => true         -- fit template to page size
     );
     
      /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',         -- Font family: Arial
     p_style => null,             -- Font style: regular (default)
     p_size => 12                 -- Font size: 12 pt
     ); 
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,                   -- Rectangle width
     p_h => 10,                   -- Rectangle heigth
     p_txt => 'Template Example'  -- Text in rectangle 
     );
     
      /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage;
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',         -- Font family: Arial
     p_style => null,             -- Font style: regular (default)
     p_size => 12                 -- Font size: 12 pt
     ); 
	
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,                   -- Rectangle width
     p_h => 10,                   -- Rectangle heigth
     p_txt => 'Template Example'  -- Text in rectangle 
     );
     
     /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */  
      plpdf.SendDoc(
      p_blob => l_blob  -- The generated document
      );
      
      /* Print it:
        
      owa_util.mime_header('application/pdf',false);
            htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
            owa_util.http_header_close;   
            wpg_docload.download_file(l_blob);   */
      
      /* Store */ 
    insert into STORE_BLOB(BLOB_FILE,CREATED_DATE) VALUES(l_blob,sysdate);
    commit;
    end; 

/*******************/
/* End of package */
/*****************/
end;
/

  
