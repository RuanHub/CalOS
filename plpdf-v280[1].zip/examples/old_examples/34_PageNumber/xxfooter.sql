CREATE OR REPLACE procedure Xxfooter is
 begin
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',     -- Font family: Arial
     p_style => 'I',          -- Font style: Italic
     p_size => 8              -- Font size: 8 pt
     ); 
   
    /* Print number of page */
   
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 0,                -- Rectangle width
     p_h => 10,               -- Rectangle heigth
     p_txt => '{cp}/{nb}',    -- Text in rectangle 
     p_border => '0',         -- Without frame
     p_ln => '0',             -- Cursor position after the cell is printed: Beside  
     p_align => 'C'           -- Text alignment: Center
     );   
   	
 end;
/