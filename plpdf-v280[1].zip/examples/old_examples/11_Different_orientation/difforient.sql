CREATE OR REPLACE procedure difforient is
    /* 11. Exmaple:  Different orientation */
    
  l_blob blob;
 begin
    
    /* Initialize, without parameters means: 
     - page orientation: portrait
     - unit: mm
     - default page format: A4 */
    plpdf.init; 
    
    /* Begin a new page, without parameters means: 
     - page orientation: default (portrait) */
    plpdf.NewPage; 
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',         -- Font family: Arial
     p_style => null,             -- Font style: regular (default)
     p_size => 12                 -- Font size: 12 pt
     ); 
    
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,                    -- Rectangle width
     p_h => 10,                    -- Rectangle heigth
     p_txt => 'Portrait (default)' -- Text in rectangle 
     ); 
	
    /* Begin a new page */
    plpdf.NewPage(
     p_orientation => 'L'           -- Page orientation: Landscape
     ); 
      
    /* Draws a rectangle cell with text inside. 
       The rectangle may have a border and fill color specified. */
    plpdf.PrintCell(
     p_w => 50,                     -- Rectangle width
     p_h => 10,                     -- Rectangle heigth
     p_txt => 'Landscape'           -- Text in rectangle 
     ); 
     
    /* Returns the generated PDF document. 
       The document is closed and then returned in the OUT parameter. */
    plpdf.SendDoc(
     p_blob => l_blob               -- The generated document
     );
	
        
    /* Print it:
    
	owa_util.mime_header('application/pdf',false);
        htp.p('Content-Length: ' || dbms_lob.getlength(l_blob)); 
        owa_util.http_header_close; 	
        wpg_docload.download_file(l_blob);   */
    
    /* Store */
    insert into STORE_BLOB (blob_file, created_date) values (l_blob, sysdate);
    
    commit;
 end;
/

