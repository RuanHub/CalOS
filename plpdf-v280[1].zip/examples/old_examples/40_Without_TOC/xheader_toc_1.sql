CREATE OR REPLACE procedure xheader_toc_1 is
begin
    
    /* Sets the font and its properties */
    plpdf.SetPrintFont(
     p_family => 'Arial',    -- Font family: Arial
     p_style => 'BU',        -- Font style: Bold and Underline
     p_size => 12            -- Font size: 12 pt
     ); 
    
    /* Page title */
    
    /* Draws a rectangle cell with text inside. */
    plpdf.PrintCell(
     p_w => 0,                          -- Rectangle width
     p_h => 10,                         -- Rectangle heigth
     p_txt => 'Page title text',        -- Text in rectangle 
     p_border => '0',                   -- Without frame
     p_ln => '0',                       -- Cursor position after the cell is printed: Beside  
     p_align => 'C'                     -- Text alignment: Center
     );   
    
end;
/
