create or replace package body plpdf_cert is
---------------------------------------------------------------------------------------------------
function setcertkey 
  return varchar2 is
begin 
  return 'TRIAL';
end;
---------------------------------------------------------------------------------------------------
-- mod:v1.2.4
/*
Default value for encoding.
Encoding is independent from Certification Key!
*/
function GetDefaultEncoding return varchar2 is
begin
  -- default value: cp1252
  return 'cp1252';
end;
---------------------------------------------------------------------------------------------------
end;
/

