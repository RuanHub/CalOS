prompt creating user
create user plpdf identified by plpdf;
prompt grant connect
grant connect to plpdf;
prompt grant resource
grant resource to plpdf;
prompt grant select 
grant select on sys.v_$database to plpdf;
GRANT execute on sys.DBMS_CRYPTO to plpdf;
