create or replace package plpdf_metric is
--v1.5.0
---------------------------------------------------------------------------------------------------
procedure set_metrics(
  p_cw out plpdf_type.t_charwidths
  );
---------------------------------------------------------------------------------------------------
procedure cjk_set_metrics(
  p_font varchar2, 
  p_fullwidth boolean default true, 
  p_cw in out plpdf_type.t_charwidths
  );
---------------------------------------------------------------------------------------------------  
end;
/

