create or replace package plpdf_const is
--v2.7.0

  -- colors: http://www.forret.com/tools/color_palette.asp
	Black constant plpdf_type.t_color := plpdf_util.set_color(0,0,0);
	Navy constant plpdf_type.t_color := plpdf_util.set_color(0,0,128);
	Dark_blue constant plpdf_type.t_color := plpdf_util.set_color(0,0,139);
	Medium_blue constant plpdf_type.t_color := plpdf_util.set_color(0,0,205);
	Blue constant plpdf_type.t_color := plpdf_util.set_color(0,0,255);
	Dark_green constant plpdf_type.t_color := plpdf_util.set_color(0,100,0);
	Green constant plpdf_type.t_color := plpdf_util.set_color(0,128,0);
	Teal constant plpdf_type.t_color := plpdf_util.set_color(0,128,128);
	Dark_cyan constant plpdf_type.t_color := plpdf_util.set_color(0,139,139);
	Deep_sky_blue constant plpdf_type.t_color := plpdf_util.set_color(0,191,255);
	Dark_turquoise constant plpdf_type.t_color := plpdf_util.set_color(0,222,209);
	Medium_spring_green constant plpdf_type.t_color := plpdf_util.set_color(0,250,154);
	Lime constant plpdf_type.t_color := plpdf_util.set_color(0,255,0);
	Spring_green constant plpdf_type.t_color := plpdf_util.set_color(0,255,127);
	Cyan constant plpdf_type.t_color := plpdf_util.set_color(0,255,255);
	Midnight_blue constant plpdf_type.t_color := plpdf_util.set_color(25,25,112);
	Dodger_blue constant plpdf_type.t_color := plpdf_util.set_color(30,144,255);
	Light_seagreen constant plpdf_type.t_color := plpdf_util.set_color(32,178,170);
	Forest_green constant plpdf_type.t_color := plpdf_util.set_color(34,139,34);
	Sea_green constant plpdf_type.t_color := plpdf_util.set_color(46,139,87);
	Dark_slate_gray constant plpdf_type.t_color := plpdf_util.set_color(47,79,79);
	Lime_green constant plpdf_type.t_color := plpdf_util.set_color(50,205,50);
	Medium_sea_green constant plpdf_type.t_color := plpdf_util.set_color(60,179,113);
	Turquoise constant plpdf_type.t_color := plpdf_util.set_color(64,224,208);
	Royal_blue constant plpdf_type.t_color := plpdf_util.set_color(65,105,225);
	Steelblue constant plpdf_type.t_color := plpdf_util.set_color(70,130,180);
	Dark_slate_blue constant plpdf_type.t_color := plpdf_util.set_color(72,61,139);
	Medium_turquoise constant plpdf_type.t_color := plpdf_util.set_color(72,209,204);
	Indigo constant plpdf_type.t_color := plpdf_util.set_color(75,0,130);
	Dark_olive_green constant plpdf_type.t_color := plpdf_util.set_color(85,107,47);
	Cadet_blue constant plpdf_type.t_color := plpdf_util.set_color(95,158,160);
	Cornflower_blue constant plpdf_type.t_color := plpdf_util.set_color(100,149,237);
	Medium_aquamarine constant plpdf_type.t_color := plpdf_util.set_color(102,205,170);
	Dim_gray constant plpdf_type.t_color := plpdf_util.set_color(105,105,105);
	Slate_blue constant plpdf_type.t_color := plpdf_util.set_color(106,90,205);
	Olive_drab constant plpdf_type.t_color := plpdf_util.set_color(107,142,35);
	Light_slate_gray constant plpdf_type.t_color := plpdf_util.set_color(119,136,153);
	Medium_slate_blue constant plpdf_type.t_color := plpdf_util.set_color(123,104,238);
	Lawngreen constant plpdf_type.t_color := plpdf_util.set_color(124,252,0);
	Chartreuse constant plpdf_type.t_color := plpdf_util.set_color(127,255,0);
	Aquamarine constant plpdf_type.t_color := plpdf_util.set_color(127,255,212);
	Maroon constant plpdf_type.t_color := plpdf_util.set_color(128,0,0);
	Purple constant plpdf_type.t_color := plpdf_util.set_color(128,0,128);
	Gray constant plpdf_type.t_color := plpdf_util.set_color(128,128,128);
	Sky_blue constant plpdf_type.t_color := plpdf_util.set_color(135,206,235);
	Light_sky_blue constant plpdf_type.t_color := plpdf_util.set_color(135,206,250);
	Blue_violet constant plpdf_type.t_color := plpdf_util.set_color(138,43,226);
	Dark_red constant plpdf_type.t_color := plpdf_util.set_color(139,0,0);
	Dark_magenta constant plpdf_type.t_color := plpdf_util.set_color(139,0,139);
	Saddle_brown constant plpdf_type.t_color := plpdf_util.set_color(139,69,19);
	Dark_seagreen constant plpdf_type.t_color := plpdf_util.set_color(141,188,143);
	Light_green constant plpdf_type.t_color := plpdf_util.set_color(144,238,144);
	Medium_purple constant plpdf_type.t_color := plpdf_util.set_color(147,112,219);
	Dark_violet constant plpdf_type.t_color := plpdf_util.set_color(148,0,211);
	Pale_green constant plpdf_type.t_color := plpdf_util.set_color(152,251,152);
	Dark_orchid constant plpdf_type.t_color := plpdf_util.set_color(153,50,204);
	Yellow_green constant plpdf_type.t_color := plpdf_util.set_color(154,205,50);
	Sienna constant plpdf_type.t_color := plpdf_util.set_color(160,82,45);
	Brown constant plpdf_type.t_color := plpdf_util.set_color(165,42,42);
	Dark_gray constant plpdf_type.t_color := plpdf_util.set_color(169,169,169);
	Light_blue constant plpdf_type.t_color := plpdf_util.set_color(173,216,230);
	Green_yellow constant plpdf_type.t_color := plpdf_util.set_color(173,255,47);
	Pale_turquoise constant plpdf_type.t_color := plpdf_util.set_color(175,238,238);
	Light_steel_blue constant plpdf_type.t_color := plpdf_util.set_color(176,196,222);
	Powder_blue constant plpdf_type.t_color := plpdf_util.set_color(176,224,230);
	Firebrick constant plpdf_type.t_color := plpdf_util.set_color(178,34,34);
	Dark_goldenrod constant plpdf_type.t_color := plpdf_util.set_color(184,134,11);
	Medium_orchid constant plpdf_type.t_color := plpdf_util.set_color(186,85,211);
	Rosy_brown constant plpdf_type.t_color := plpdf_util.set_color(188,143,143);
	Dark_khaki constant plpdf_type.t_color := plpdf_util.set_color(189,183,107);
	Silver constant plpdf_type.t_color := plpdf_util.set_color(192,192,192);
	Medium_violet_red constant plpdf_type.t_color := plpdf_util.set_color(199,21,133);
	Indian_red constant plpdf_type.t_color := plpdf_util.set_color(205,92,92);
	Peru constant plpdf_type.t_color := plpdf_util.set_color(205,133,63);
	Chocolate constant plpdf_type.t_color := plpdf_util.set_color(210,105,30);
	Tan constant plpdf_type.t_color := plpdf_util.set_color(210,180,140);
	Light_grey constant plpdf_type.t_color := plpdf_util.set_color(211,211,211);
	Thistle constant plpdf_type.t_color := plpdf_util.set_color(216,191,216);
	Orchid constant plpdf_type.t_color := plpdf_util.set_color(218,112,214);
	Goldenrod constant plpdf_type.t_color := plpdf_util.set_color(218,165,32);
	Pale_violet_red constant plpdf_type.t_color := plpdf_util.set_color(219,112,147);
	Crimson constant plpdf_type.t_color := plpdf_util.set_color(220,20,60);
	Gainsboro constant plpdf_type.t_color := plpdf_util.set_color(220,220,220);
	Plum constant plpdf_type.t_color := plpdf_util.set_color(221,160,221);
	Burlywood constant plpdf_type.t_color := plpdf_util.set_color(222,184,135);
	Light_cyan constant plpdf_type.t_color := plpdf_util.set_color(224,255,255);
	Lavender constant plpdf_type.t_color := plpdf_util.set_color(230,230,250);
	Dark_salmon constant plpdf_type.t_color := plpdf_util.set_color(233,150,122);
	Violet constant plpdf_type.t_color := plpdf_util.set_color(238,130,238);
	Pale_goldenrod constant plpdf_type.t_color := plpdf_util.set_color(238,232,170);
	Light_coral constant plpdf_type.t_color := plpdf_util.set_color(240,128,128);
	Khaki constant plpdf_type.t_color := plpdf_util.set_color(240,230,140);
	Alice_blue constant plpdf_type.t_color := plpdf_util.set_color(240,248,255);
	Honeydew constant plpdf_type.t_color := plpdf_util.set_color(240,255,240);
	Azure constant plpdf_type.t_color := plpdf_util.set_color(240,255,255);
	Sandy_brown constant plpdf_type.t_color := plpdf_util.set_color(244,164,96);
	Wheat constant plpdf_type.t_color := plpdf_util.set_color(245,222,179);
	Beige constant plpdf_type.t_color := plpdf_util.set_color(245,245,220);
	Whitesmoke constant plpdf_type.t_color := plpdf_util.set_color(245,245,245);
	Mint_cream constant plpdf_type.t_color := plpdf_util.set_color(245,255,250);
	Ghost_white constant plpdf_type.t_color := plpdf_util.set_color(248,248,255);
	Salmon constant plpdf_type.t_color := plpdf_util.set_color(250,128,114);
	Antique_white constant plpdf_type.t_color := plpdf_util.set_color(250,235,215);
	Linen constant plpdf_type.t_color := plpdf_util.set_color(250,240,230);
	Light_goldenrod_yellow constant plpdf_type.t_color := plpdf_util.set_color(250,250,210);
	Old_lace constant plpdf_type.t_color := plpdf_util.set_color(253,245,230);
	Red constant plpdf_type.t_color := plpdf_util.set_color(255,0,0);
	Magenta constant plpdf_type.t_color := plpdf_util.set_color(255,0,255);
	Deep_pink constant plpdf_type.t_color := plpdf_util.set_color(255,20,147);
	Orange_red constant plpdf_type.t_color := plpdf_util.set_color(255,69,0);
	Tomato constant plpdf_type.t_color := plpdf_util.set_color(255,99,71);
	Hot_pink constant plpdf_type.t_color := plpdf_util.set_color(255,105,180);
	Coral constant plpdf_type.t_color := plpdf_util.set_color(255,127,80);
	Dark_orange constant plpdf_type.t_color := plpdf_util.set_color(255,140,0);
	Light_salmon constant plpdf_type.t_color := plpdf_util.set_color(255,160,122);
	Orange constant plpdf_type.t_color := plpdf_util.set_color(255,165,0);
	Light_pink constant plpdf_type.t_color := plpdf_util.set_color(255,182,193);
	Pink constant plpdf_type.t_color := plpdf_util.set_color(255,200,203);
	Gold constant plpdf_type.t_color := plpdf_util.set_color(255,215,0);
	Peach_puff constant plpdf_type.t_color := plpdf_util.set_color(255,218,185);
	Navajo_white constant plpdf_type.t_color := plpdf_util.set_color(255,222,173);
	Moccasin constant plpdf_type.t_color := plpdf_util.set_color(255,228,181);
	Bisque constant plpdf_type.t_color := plpdf_util.set_color(255,228,196);
	Misty_rose constant plpdf_type.t_color := plpdf_util.set_color(255,228,225);
	Blanche_dalmond constant plpdf_type.t_color := plpdf_util.set_color(255,235,205);
	Papaya_whip constant plpdf_type.t_color := plpdf_util.set_color(255,239,213);
	Lavender_blush constant plpdf_type.t_color := plpdf_util.set_color(255,240,245);
	Sea_shell constant plpdf_type.t_color := plpdf_util.set_color(255,245,238);
	Cornsilk constant plpdf_type.t_color := plpdf_util.set_color(255,248,220);
	Lemon_chiffon constant plpdf_type.t_color := plpdf_util.set_color(255,250,205);
	Floral_white constant plpdf_type.t_color := plpdf_util.set_color(255,250,240);
	Snow constant plpdf_type.t_color := plpdf_util.set_color(255,250,250);
	Yellow constant plpdf_type.t_color := plpdf_util.set_color(255,255,0);
	Light_yellow constant plpdf_type.t_color := plpdf_util.set_color(255,255,224);
	Ivory constant plpdf_type.t_color := plpdf_util.set_color(255,255,240);
	White constant plpdf_type.t_color := plpdf_util.set_color(255,255,255);

  -- pageformat
	a0 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(2383.94,3370.39);
	a1 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1683.78,2383.94);
	a2 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1190.55,1683.78);
	a3 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(841.89,1190.55);
	a4 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(595.28,841.89);
	a5 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(419.53,595.28);
	a6 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(297.64,419.53);
	a7 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(209.76,297.64);
	a8 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(147.40,209.76);
	a9 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(104.88,147.40);
	a10 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(73.70,104.88);
	b0 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(2834.65,4008.19);
	b1 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(2004.09,2834.65);
	b2 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1417.32,2004.09);
	b3 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1000.63,1417.32);
	b4 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(708.66,1000.63);
	b5 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(498.90,708.66);
	b6 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(354.33,498.90);
	b7 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(249.45,354.33);
	b8 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(175.75,249.45);
	b9 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(124.72,175.75);
	b10 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(87.87,124.72);
	c0 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(2599.37,3676.54);
	c1 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1836.85,2599.37);
	c2 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1298.27,1836.85);
	c3 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(918.43,1298.27);
	c4 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(649.13,918.43);
	c5 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(459.21,649.13);
	c6 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(323.15,459.21);
	c7 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(229.61,323.15);
	c8 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(161.57,229.61);
	c9 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(113.39,161.57);
	c10 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(79.37,113.39);
	ra0 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(2437.80,3458.27);
	ra1 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1729.13,2437.80);
	ra2 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1218.90,1729.13);
	ra3 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(864.57,1218.90);
	ra4 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(609.45,864.57);
	sra0 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(2551.18,3628.35);
	sra1 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1814.17,2551.18);
	sra2 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(1275.59,1814.17);
	sra3 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(907.09,1275.59);
	sra4 constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(637.80,907.09);
	letter constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(612.00,792.00);
	legal constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(612.00,1008.00);
	executive constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(521.86,756.00);
	folio constant plpdf_type.t_pageformat := plpdf_util.set_pageformat(612.00,936.00);
  
 -- Text annotations
 Comment_Annot constant varchar2(20 char) := 'Comment';
 Key_Annot constant varchar2(20 char) := 'Key';
 Note_Annot constant varchar2(20 char) := 'Note';
 Help_Annot constant varchar2(20 char) := 'Help';
 NewParagraph_Annot constant varchar2(20 char) := 'NewParagraph';
 Paragraph_Annot constant varchar2(20 char) := 'Paragraph';
 Insert_Annot constant varchar2(20 char) := 'Insert';

 -- File annotations
 PushPin_Annot constant varchar2(20 char) := 'PushPin';
 Graph_Annot constant varchar2(20 char) := 'Graph';
 Paperclip_Annot constant varchar2(20 char) := 'Paperclip';
 Tag_Annot constant varchar2(20 char) := 'Tag';

 -- Encodings
cp1250 constant varchar2(20 char) := 'cp1250';
cp1251 constant varchar2(20 char) := 'cp1251';
cp1252 constant varchar2(20 char) := 'cp1252';
cp1253 constant varchar2(20 char) := 'cp1253';
cp1254 constant varchar2(20 char) := 'cp1254';
cp1255 constant varchar2(20 char) := 'cp1255';
cp1257 constant varchar2(20 char) := 'cp1257';
cp1258 constant varchar2(20 char) := 'cp1258';
cp874 constant varchar2(20 char) := 'cp874';
iso_8859_1 constant varchar2(20 char) := 'iso-8859-1';
iso_8859_2 constant varchar2(20 char) := 'iso-8859-2';
iso_8859_4 constant varchar2(20 char) := 'iso-8859-4';
iso_8859_5 constant varchar2(20 char) := 'iso-8859-5';
iso_8859_7 constant varchar2(20 char) := 'iso-8859-7';
iso_8859_9 constant varchar2(20 char) := 'iso-8859-9';
iso_8859_11 constant varchar2(20 char) := 'iso-8859-11';
iso_8859_15 constant varchar2(20 char) := 'iso-8859-15';
iso_8859_16 constant varchar2(20 char) := 'iso-8859-16';
koi8_r constant varchar2(20 char) := 'koi8-r';
koi8_u constant varchar2(20 char) := 'koi8-u';
utf16 constant varchar2(20 char) := 'utf16';

---------------------------------------------------------------------------------------------------
-- CJK
-- japanese
font_japanese constant varchar2(30 char) := 'HeiseiKakuGo-W5'; --v2.0.0
CMap_japanese constant varchar2(30 char) := 'UniJIS-UCS2-H'; --v2.0.0
-- korean
font_korean constant varchar2(30 char) := 'HYSMyeongJoStd-Medium-Acro'; --v2.0.0
CMap_korean constant varchar2(30 char) := 'UniKS-UCS2-H'; --v2.0.0
-- chinese
font_chinese_Big5 constant varchar2(30 char) := 'MSungStd-Light-Acro'; --v2.0.0
CMap_chinese_Big5 constant varchar2(30 char) := 'UniCNS-UCS2-H'; --v2.0.0
font_chinese_GB constant varchar2(30 char) := 'STSongStd-Light-Acro'; --v2.0.0
CMap_chinese_GB constant varchar2(30 char) := 'UniGB-UCS2-H'; --v2.0.0  
---------------------------------------------------------------------------------------------------
-- PushButton
button_action_submitform constant varchar2(10 char) := 'SubmitForm'; --v2.0.0
button_action_resetform constant varchar2(10 char) := 'ResetForm'; --v2.0.0
-- button_action_importdata constant varchar2(10 char) := 'ImportData'; unsupported --v2.0.0
button_action_javascript constant varchar2(10 char) := 'JavaScript'; --v2.0.0
-- request
submit_format_html constant varchar2(4 char) := 'HTML'; --v2.0.0
submit_format_fdf constant varchar2(4 char) := 'FDF'; --v2.0.0

submit_request_post constant varchar2(4 char) := 'POST'; --v2.0.0
submit_request_get constant varchar2(4 char) := 'GET'; --v2.0.0
---------------------------------------------------------------------------------------------------
pdf_version constant varchar2(3 char) := '1.3'; --v2.0.0
pi constant number := 4 * atan(1); --v2.0.0
padding_string constant raw(32) := hextoraw('28BF4E5E4E758A4164004E56FFFA01082E2E00B6D0683E802F0CA9FE6453697A'); --v2.0.0
cr constant varchar2(1 char) := chr(13); --v2.0.0
lf constant varchar2(1 char) := chr(10); --v2.0.0
---------------------------------------------------------------------------------------------------
comp_FlateDecode constant varchar2(20 char) := 'FlateDecode'; --v2.0.0
comp_LZWDecode constant varchar2(20 char) := 'LZWDecode'; --v2.0.0
comp_PLDeflate constant varchar2(20 char) := 'PLDeflate'; --v2.0.0 internal
---------------------------------------------------------------------------------------------------
--v2.7.0
--unit of measure
point constant varchar2(5 char) := 'pt';
inch constant varchar2(5 char) := 'in';
mm constant varchar2(5 char) := 'mm';
cm constant varchar2(5 char) := 'cm';
--
inch_mm constant number := 25.4; --inch/mm 
ps_point constant pls_integer := 72;
--
portrait constant varchar2(1 char) := 'P'; 
landscape constant varchar2(1 char) := 'L';
---------------------------------------------------------------------------------------------------
end;
/

