set define off

prompt Creating TTF tables
@@plpdf_ttf_tables.sql

prompt Creating Parser tables
@@plpdf_parser_tables.sql


prompt Creating package headers
prompt Creating TYPE package
@@plpdf_type_h.sql
prompt Creating UTIL package
@@plpdf_util_h.sql
prompt Creating CONSTANT package
@@plpdf_const_h.sql
prompt Creating PLPDF MAIN package
@@plpdf_h.sql
prompt Creating CERTIFICATION package
@@plpdf_cert_h.sql
prompt Creating COMPRESSOR package
@@plpdf_comp_h.sql
prompt Creating DIGSIG package
@@plpdf_digsig_h.sql
prompt Creating ENCODING package
@@plpdf_enc_h.sql
prompt Creating ERROR package
@@plpdf_err_h.sql
prompt Creating GLYPHS package
@@plpdf_gl_h.sql
prompt Creating IMAGE package
@@plpdf_img2_h.sql
prompt Creating IMAGE ERROR package
@@plpdf_img2_err_h.sql
prompt Creating METRIC package
@@plpdf_metric_h.sql
prompt Creating PARSER package
@@plpdf_parser_h.sql
prompt Creating PDFX package
@@plpdf_pdfx_h.sql
prompt Creating ROW_PRINT package
@@plpdf_row_print_h.sql
prompt Creating TEXT DIRECTION package
@@plpdf_rtol_h.sql
prompt Creating TEXT package
@@plpdf_text2_h.sql
prompt Creating TTF package
@@plpdf_ttf_h.sql
prompt Creating TTF PARSER package
@@plpdf_ttf_parser_h.sql
prompt Creating TTF SUBSET package
@@plpdf_ttf_subset_h.sql


prompt Creating package bodies
prompt Creating PLPDF MAIN package
@@plpdf_b.sql
prompt Creating CERTIFICATION package
@@plpdf_cert_b.sql
prompt Creating COMPRESSOR package
@@plpdf_comp_b.sql
prompt Creating DIGSIG package
@@plpdf_digsig_b.sql
prompt Creating ENCODING package
@@plpdf_enc_b.sql
prompt Creating ERROR package
@@plpdf_err_b.sql
prompt Creating GLYPHS package
@@plpdf_gl_b.sql
prompt Creating IMAGE package
@@plpdf_img2_b.sql
prompt Creating IMAGE ERROR package
@@plpdf_img2_err_b.sql
prompt Creating METRIC package
@@plpdf_metric_b.sql
prompt Creating PARSER package
@@plpdf_parser_b.sql
prompt Creating PDFX package
@@plpdf_pdfx_b.sql
prompt Creating ROW_PRINT package
@@plpdf_row_print_b.sql
prompt Creating TEXT DIRECTION package
@@plpdf_rtol_b.sql
prompt Creating TEXT package
@@plpdf_text2_b.sql
prompt Creating TTF package
@@plpdf_ttf_b.sql
prompt Creating TTF PARSER package
@@plpdf_ttf_parser_b.sql
prompt Creating TTF SUBSET package
@@plpdf_ttf_subset_b.sql
prompt Creating UTIL package
@@plpdf_util_b.sql

EXIT


