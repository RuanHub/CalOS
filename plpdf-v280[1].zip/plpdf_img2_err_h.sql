create or replace package plpdf_img2_err is
--v2.4.0 
c_handle varchar2(5 char) := 'FALSE';
--
function errorhandler(
  p_img in out nocopy blob, 
  p_name varchar2
  ) return blob;
--
end plpdf_img2_err;
/

