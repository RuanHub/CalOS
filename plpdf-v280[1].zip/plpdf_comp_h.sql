create or replace package plpdf_comp is
--v2.7.0
---------------------------------------------------------------------------------------------------
c_support constant varchar2(3 char) := 'NO';
c_checksum constant varchar2(3 char) := 'NO'; --2.7.0
---------------------------------------------------------------------------------------------------
function blob_compress(p_blob blob) return blob;
function blob_decompress(p_blob blob) return blob;
---------------------------------------------------------------------------------------------------
function lzw_compress(p_blob blob) return blob;
function lzw_decompress(p_blob blob) return blob;
---------------------------------------------------------------------------------------------------
function inflate(p_blob blob) return blob;
function deflate(p_blob blob) return blob;
---------------------------------------------------------------------------------------------------
end;
/

