create or replace package plpdf_cert is
---------------------------------------------------------------------------------------------------
function setcertkey 
  return varchar2;
---------------------------------------------------------------------------------------------------
-- mod:v1.2.4
/*
Default value for encoding.
Encoding is independent from Certification Key!
*/
function GetDefaultEncoding 
  return varchar2;
---------------------------------------------------------------------------------------------------  
end;
/


