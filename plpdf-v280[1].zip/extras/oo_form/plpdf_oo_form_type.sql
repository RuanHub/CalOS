CREATE OR REPLACE TYPE plpdf_type_prepform_obj AS OBJECT (
  obj number,
  gen number,
  field_name varchar2(255 char),
  field_subtype varchar2(20 char),
  value_type varchar2(10 char),
  orig_value varchar2(2000 char),
  orig_read_only number(1,0), -- boolean
  new_value varchar2(2000 char),
  new_read_only number(1,0), -- boolean
  orig_flag number,
  value_ref number,
  flag_ref number
);


CREATE OR REPLACE TYPE plpdf_type_prepform_objs AS TABLE OF plpdf_type_prepform_obj;

CREATE OR REPLACE TYPE plpdf_type_prepform_xref AS TABLE OF number;

CREATE OR REPLACE TYPE plpdf_type_obj_ref AS OBJECT (obj number, gen number);

CREATE OR REPLACE TYPE plpdf_type_prepform AS OBJECT (
    pdf_blob blob,
    last_obj_end number,
    xref plpdf_type_prepform_xref,
    objs plpdf_type_prepform_objs,
    root_ref plpdf_type_obj_ref,
    info_ref plpdf_type_obj_ref
    );
