create table plpdf_00_form_store
(
id number not null,
filename varchar2(255 char),
orig_pdf blob,
prepform plpdf_type_prepform
)
nested table prepform.xref store as xref_table,
nested table prepform.objs store as objs_table
;
