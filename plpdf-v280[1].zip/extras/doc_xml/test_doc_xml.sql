declare
l_pdf blob;
begin
  
  plpdf_doc_xml.setSource(p_name => 'PLPDF',p_owner => 'PLPDF',p_type => 'PACKAGE');
  plpdf_doc_xml.init;
  l_pdf := plpdf_doc_xml.generate;
  delete from store_blob;
  insert into store_blob (blob_file,created_date) values (l_pdf,sysdate);
  commit;
end;
/
