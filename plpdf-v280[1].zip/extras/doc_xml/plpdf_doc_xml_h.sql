create or replace package plpdf_doc_xml as
/**
v2.6.0
*/
procedure setSource(p_name varchar2,p_owner varchar2, p_type varchar2);

procedure plpdf_header;
procedure plpdf_footer;

procedure init;
function generate return blob;

end plpdf_doc_xml;
/
