create or replace package plzip as

/**
<config>
  <pck-name>PL/ZIP</pck-name>
  <pck-title>User's Guide</pck-title>
  <pck-version>v1.1.0</pck-version>
   <header-prc>plpdf_doc_xml.plpdf_header</header-prc>
  <header-size>10</header-size>
  <footer-prc>plpdf_doc_xml.plpdf_footer</footer-prc>
  <footer-size>10</footer-size>
</config>
*/

/**
<h1>Introdution</h1>
<br/>
<p>
  PL/ZIP is a PL/SQL package for creating ZIP files. The method consist of three easy steps, create new archive,
  add files and finally save the complete ZIP. TRIAL limitation is a Random message: It''s not error! Certification is TRIAL!
</p>
<br/>
<h2>Installation</h2>
<p>
System requirements: Oracle 10g RDBMS Release 2 or higher. Oracle 10g Express Edition is supported.
</p>
<br/>
*/

/**
<newpage/>
<h1>Procedures and Functions </h1>
<br/>
*/

/**
<name>GetVersion</name>
<type>function</type>
<desc>
Gets the version number of PL/ZIP package.
</desc>
<version>v1.0.0</version>
<params>-</params>
<return>
  <return-def>varchar2</return-def>
  <return-desc>number of current version</return-desc>
</return>
*/
function getVersion return varchar2;

/**
 <name>CertKeyCheck</name>
 <type>Function</type>
 <desc>
  Checks the certification key.<br/>
  Usage:<br/>
  declare                            <br/>
    l_ret boolean;                   <br/>
  begin                              <br/>
    l_ret := plzip.CertKeyCheck;     <br/>
    if l_ret then                    <br/>
      dbms_output.put_line('true');  <br/>
    else                             <br/>
      dbms_output.put_line('false'); <br/>
    end if;                          <br/>
  end;                               <br/>
 </desc>
 <version>v1.1.0</version>
 <params>-</params>
 <return>
  <return-def>boolean</return-def>
  <return-desc>validity of the key</return-desc>
 </return>
*/
function CertKeyCheck
  return boolean;

/**
<name>createNewZip</name>
<type>Procedure</type>
<desc>
  Initializes the package, creates a new zip archive.
</desc>
<version>v1.0.0</version>
<params>-</params>
<return>-</return>
*/
procedure createNewZip;

/**
<name>addFile</name>
<type>Procedure</type>
<desc>
  Adds a file to the ZIP archive. To place a file into a subdirectory inside the ZIP archive, set the full path as p_filename.
</desc>
<version>v1.0.0</version>
<params>
  <param>
   <param-def>p_filename varchar2</param-def>
   <param-desc>[<i>path/</i>]name of the file</param-desc>
  </param>
  <param>
   <param-def>p_file varchar2</param-def>
   <param-desc>file</param-desc>
  </param>
</params>
<return>-</return>
*/
procedure addFile(
  p_filename varchar2,
  p_file blob
  );

/**
<name>saveZip</name>
<type>Function</type>
<desc>
  Builds entries to ZIP file format.
</desc>
<version>v1.0.0</version>
<params>-</params>
<return>
  <return-def>blob</return-def>
  <return-desc>The ZIP archive</return-desc>
</return>
*/
function saveZip
  return blob;

end plzip;
/

create or replace package body plzip wrapped 
0
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
3
b
9200000
1
4
0 
d3
2 :e:
1PACKAGE:
1BODY:
1PLZIP:
1G_VERSION:
1CONSTANT:
1VARCHAR2:
1CHAR:
15:
11.1.0:
1V_PAD_CHR:
11:
1~:
1V_CERT_KEY:
1100:
1V_CERT_OK:
1BOOLEAN:
1FALSE:
1V_CERT_ERR_MISSING:
1PLPDF_TYPE:
1V2AVG:
1Certification key is missing.:
1V_CERT_ERR_INVALID:
1Certification key is invalid. Please contact Support.:
1V_TRIAL_ERROR:
1255:
1Random message:: It's not error! Certification is TRIAL!:
1V_BLOB_FILE:
1BLOB:
1FUNCTION:
1GETVERSION:
1RETURN:
1RAISE_ERROR:
1P_MSG:
1RAISE_APPLICATION_ERROR:
1-:
120000:
1CR_ERROR:
1P_CODE:
1P_1:
1L_MSG:
1=:
1301:
1Stream error:: &1.:
1ELSIF:
1302:
1Buffer error:: &1.:
1303:
1Data error:: &1.:
1IS NOT NULL:
1REPLACE:
1&1:
1SUBSTR:
1ERR-:
1||:
1 :
1GETADDRSTRING:
1L_RET:
1UTL_INADDR:
1GET_HOST_ADDRESS:
1DBMS_STANDARD:
1DATABASE_NAME:
1DUAL:
1ROWNUM:
1<:
12:
1GETDBID:
1TO_CHAR:
1DBID:
1SYS:
1V_$DATABASE:
1CHECKKEY:
1P_KEY:
1P_CACTH:
1TRUE:
1L_STR:
1L_DATE:
1DATE:
1L_ADDR:
1L_RAW:
1RAW:
12048:
1L_CHECK_KEY:
1L_DEVLIC:
1UTL_RAW:
1CAST_TO_RAW:
1SQRT:
113:
13:
138:
1DBMS_OBFUSCATION_TOOLKIT:
1DESDECRYPT:
1INPUT:
1HEXTORAW:
1KEY:
1DECRYPTED_DATA:
1RTRIM:
1CAST_TO_VARCHAR2:
1TO_DATE:
120:
16:
1YYYYMMDD:
17:
1ASPASIA:
1COGNOTEC:
1ISDHR:
1PERFIT:
1DBVALLEY:
1QUINN:
1BERENBERG:
1MYTHICS:
1ELUCID:
1MCGILL:
1SOCHO:
1CAISO:
1DCDK12:
1NTUEDUSG:
1GWIC:
1OHIO:
1FORCES:
14:
1!=:
1TRUNC:
1SYSDATE:
1<=:
1OTHERS:
1RAISE:
1CERTKEYCHECK:
1PLPDF_CERT:
1SETCERTKEY:
1IS NULL:
1UPPER:
1TRIAL:
1P_PROC:
1ERROR:: proc:::
1,msg:: :
1CREATENEWZIP:
1DBMS_LOB:
1CREATETEMPORARY:
1LITTLE_ENDIAN:
1P_IN_BIG:
1NUMBER:
1P_IN_BYTES:
1PLS_INTEGER:
1CAST_FROM_BINARY_INTEGER:
1ADDFILE:
1P_FILENAME:
1P_FILE:
1L_NOW:
1L_BLOB:
1L_CLEN:
1INTEGER:
1UTL_COMPRESS:
1LZ_COMPRESS:
1GETLENGTH:
1APPEND:
1CONCAT:
1504B0304:
11400:
10000:
10800:
1TO_NUMBER:
1ss:
1/:
1+:
1mi:
1*:
132:
1hh24:
1dd:
1mm:
1yyyy:
11980:
1512:
118:
1LENGTH:
1COPY:
111:
1FREETEMPORARY:
1ADDPRECOMPRESSEDFILE:
1P_CRC32:
1P_OSIZE:
1CREATEPRECOMPRESSEDFILE:
1P_CFILE:
1OUT:
1NOCOPY:
1SAVEZIP:
1L_CNT:
10:
1L_OFFS:
1L_OFFS_DIR_HEADER:
1L_OFFS_END_HEADER:
1L_COMMENT:
132767:
1PL/PDF PL/ZIP:
1L_SS:
1NOT:
1SS:
1MOD:
110:
1INSTR:
1WHILE:
1>:
1LOOP:
1504B0102:
126:
10100:
12000B681:
1CAST_TO_BINARY_INTEGER:
130:
1504B0506:
1NVL:
0

0
0
584
2
0 :2 a0 97 87 :3 a0 51 a5 1c
6e 1b b0 a3 :2 a0 51 a5 1c
6e 81 b0 a3 :2 a0 51 a5 1c
81 b0 a3 a0 1c a0 81 b0
a3 :2 a0 6b 1c 6e 81 b0 a3
:2 a0 6b 1c 6e 81 b0 a3 :2 a0
51 a5 1c 6e 81 b0 a3 a0
1c 81 b0 a0 8d a0 b4 a0
2c 6a :2 a0 65 b7 a4 b1 11
68 4f 9a 8f a0 b0 3d b4
55 6a a0 7e 51 b4 2e a0
a5 57 b7 a4 b1 11 68 4f
9a 8f a0 b0 3d 8f a0 b0
3d b4 55 6a a3 :2 a0 51 a5
1c 81 b0 a0 7e 6e b4 2e
a0 6e d a0 b7 a0 7e 6e
b4 2e a0 6e d a0 b7 19
a0 7e 6e b4 2e a0 6e d
b7 :2 19 3c a0 7e b4 2e :3 a0
6e a0 a5 b d b7 19 3c
:2 a0 6e 7e a0 b4 2e 7e 6e
b4 2e 7e a0 b4 2e :2 51 a5
b d a0 7e 51 b4 2e a0
a5 57 b7 a4 b1 11 68 4f
a0 8d a0 b4 a0 2c 6a a3
:2 a0 6b 1c 81 b0 :2 a0 6b 7e
:2 a0 6b b4 2e ac :2 a0 b2 ee
a0 7e 51 b4 2e ac e5 d0
b2 e9 :2 a0 65 b7 a4 b1 11
68 4f a0 8d a0 b4 a0 2c
6a a3 :2 a0 6b 1c 81 b0 :2 a0
a5 b ac :3 a0 6b b2 ee a0
7e 51 b4 2e ac e5 d0 b2
e9 :2 a0 65 b7 a4 b1 11 68
4f a0 8d 8f a0 b0 3d 8f
:2 a0 b0 3d b4 :2 a0 2c 6a a3
a0 1c a0 81 b0 a3 :2 a0 6b
1c 81 b0 a3 a0 1c 81 b0
a3 :2 a0 6b 1c 81 b0 a3 a0
51 a5 1c 81 b0 a3 a0 51
a5 1c 81 b0 a3 a0 1c a0
81 b0 :3 a0 6b :3 a0 51 a5 b
a5 b :2 51 a5 b a5 b d
:2 a0 6b :3 a0 a5 b e :2 a0 e
:2 a0 e a5 57 :4 a0 6b a0 a5
b a0 a5 b d :2 a0 6e 7e
:2 a0 :2 51 a5 b b4 2e 6e a5
b d :3 a0 51 a5 b d a0
3e :11 6e 5 48 :2 a0 d b7 19
3c :2 a0 :2 51 a5 b 7e 6e b4
2e :3 a0 a5 b a0 7e b4 2e
:2 a0 d b7 :2 a0 d b7 :2 19 3c
b7 :2 a0 7e b4 2e :2 a0 a5 b
a0 7e b4 2e a 10 :2 a0 d
b7 :2 a0 d b7 :2 19 3c b7 :2 19
3c b7 :2 a0 51 a5 b a0 7e
b4 2e :2 a0 a5 b a0 7e b4
2e a 10 :2 a0 d b7 :2 a0 d
b7 :2 19 3c b7 :2 19 3c b7 a0
53 :3 a0 d b7 a0 62 b7 :2 19
3c b7 a6 9 a4 b1 11 4f
:2 a0 65 b7 a4 b1 11 68 4f
a0 8d a0 b4 a0 2c 6a a3
a0 1c 81 b0 :2 a0 6b 7e b4
2e :2 a0 d a0 b7 :3 a0 6b a5
b 7e 6e b4 2e :2 a0 d b7
19 :4 a0 6b a0 a5 b d b7
:2 19 3c :2 a0 65 b7 a4 b1 11
68 4f 9a 8f a0 b0 3d 8f
a0 b0 3d b4 55 6a a0 7e
51 b4 2e 6e 7e a0 b4 2e
7e 6e b4 2e 7e a0 b4 2e
a5 57 b7 a4 b1 11 68 4f
9a b4 55 6a :2 a0 6b :2 a0 a5
57 b7 a4 b1 11 68 4f a0
8d 8f a0 b0 3d 8f a0 51
b0 3d b4 :2 a0 2c 6a :3 a0 6b
:2 a0 6b :3 a0 6b a5 b 51 a0
a5 b 65 b7 a4 b1 11 68
4f 9a 8f a0 b0 3d 8f a0
b0 3d b4 55 6a a3 a0 1c
81 b0 a3 a0 1c 81 b0 a3
a0 1c 81 b0 :2 a0 d :3 a0 6b
a0 a5 b d :3 a0 6b a0 a5
b d :2 a0 6b :3 a0 6b a0 6e
a5 b a0 6e a5 b a0 6e
a5 b a0 6e a5 b :4 a0 6e
a5 b a5 b 7e 51 b4 2e
7e :3 a0 6e a5 b a5 b 7e
51 b4 2e b4 2e 7e :3 a0 6e
a5 b a5 b 7e 51 b4 2e
b4 2e 51 a5 b :4 a0 6e a5
b a5 b 7e :3 a0 6e a5 b
a5 b 7e 51 b4 2e b4 2e
7e :3 a0 6e a5 b a5 b 7e
51 b4 2e 5a 7e 51 b4 2e
b4 2e 51 a5 b :2 a0 6b a0
51 a0 7e 51 b4 2e a5 b
:2 a0 7e 51 b4 2e a5 b :3 a0
6b a0 a5 b a5 b :3 a0 a5
b 51 a5 b a0 6e a5 b
:2 a0 6b a0 a5 b a5 b a5
57 :2 a0 6b :3 a0 7e 51 b4 2e
:2 a0 6b a0 a5 b 7e 51 b4
2e 51 a5 57 :2 a0 6b a0 a5
57 b7 a4 b1 11 68 4f 9a
8f a0 b0 3d 8f a0 b0 3d
8f a0 b0 3d 8f a0 b0 3d
b4 55 6a 4f b7 a4 b1 11
68 4f 9a 8f a0 b0 3d 96
:3 a0 b0 54 96 :3 a0 b0 54 96
:3 a0 b0 54 b4 55 6a 4f b7
a4 b1 11 68 4f a0 8d a0
b4 a0 2c 6a a3 a0 1c 51
81 b0 a3 a0 1c 81 b0 a3
a0 1c 81 b0 a3 a0 1c 81
b0 a3 a0 51 a5 1c :2 a0 6b
6e a5 b 81 b0 a3 a0 1c
81 b0 :3 a0 6b d a0 7e b4
2e :2 a0 a5 b 7e 6e b4 2e
:2 a0 d b7 :3 a0 a5 b d b7
:2 19 3c b7 :2 a0 a5 57 b7 :2 19
3c a0 5a 7e b4 2e :2 a0 a5
57 b7 19 3c :2 a0 a5 b 7e
6e b4 2e :4 a0 6e a5 b a5
b d :2 a0 51 7e a5 2e 7e
51 b4 2e :2 a0 a5 57 b7 19
3c b7 19 3c :3 a0 6b a0 a5
b d :3 a0 6b :2 a0 6e a5 b
51 a5 b d :2 a0 7e 51 a0
b4 2e 82 :2 a0 7e 51 b4 2e
d :2 a0 6b :3 a0 6b a0 6e a5
b a0 6e a5 b :2 a0 6b a0
51 a0 7e 51 b4 2e a5 b
a0 6e a5 b a0 6e a5 b
a0 6e a5 b a0 6e a5 b
:2 a0 7e 51 b4 2e a5 b :2 a0
6b :3 a0 6b :2 a0 6b a0 51 a0
7e 51 b4 2e a5 b :2 a0 6b
a5 b a0 7e 51 b4 2e a5
b a5 b a5 57 :3 a0 6b :2 a0
6e a5 b a0 7e 51 b4 2e
a5 b d b7 a0 47 :3 a0 6b
a0 a5 b d :2 a0 6b :3 a0 6b
a0 6e a5 b a0 6e a5 b
a0 6e a5 b :2 a0 51 a5 b
:2 a0 51 a5 b :2 a0 7e a0 b4
2e a5 b :2 a0 a5 b :4 a0 6b
a0 a5 b 51 a5 b 51 a5
b a0 a5 b a5 57 :2 a0 65
b7 a4 b1 11 68 4f b1 b7
a4 11 a0 b1 56 4f 1d 17
b5 
584
2
0 3 7 b 3a 19 1d 21
25 28 29 31 36 18 60 45
49 15 4d 4e 56 5b 44 81
6b 6f 41 73 74 7c 6a a1
8c 90 98 9c 67 c5 a8 ac
b0 b3 bb c0 8b ea d0 d4
88 d8 e0 e5 cf 110 f5 f9
cc fd fe 106 10b f4 12c 11b
11f 127 f1 117 133 147 14b 14c
150 154 158 15c 160 164 166 16a
16c 178 17c 17e 19a 196 195 1a2
192 1a7 1ab 1af 1b3 1b6 1b9 1ba
1bf 1c3 1c4 1c9 1cb 1cf 1d1 1dd
1e1 1e3 1ff 1fb 1fa 207 214 210
1f7 21c 20f 221 225 243 22d 231
20c 235 236 23e 22c 24a 229 24e
253 254 259 25d 262 266 26a 26c
270 273 278 279 27e 282 287 28b
28f 291 295 299 29c 2a1 2a2 2a7
2ab 2b0 2b4 2b6 2ba 2be 2c1 2c5
2c8 2c9 2ce 2d2 2d6 2da 2df 2e3
2e4 2e6 2ea 2ec 2f0 2f3 2f7 2fb
300 303 307 308 30d 310 315 316
31b 31e 322 323 328 32b 32e 32f
331 335 339 33c 33f 340 345 349
34a 34f 351 355 357 363 367 369
36d 381 385 386 38a 38e 3ae 396
39a 39e 3a1 3a9 395 3b5 3b9 392
3bd 3c0 3c4 3c8 3cb 3cc 3d1 3d2
3d6 3da 3db 3e2 3e6 3e9 3ec 3ed
3f2 3f3 3f9 3fd 3fe 403 407 40b
40f 411 415 417 423 427 429 42d
441 445 446 44a 44e 46e 456 45a
45e 461 469 455 475 479 452 47d
47f 480 484 488 48c 48f 490 497
49b 49e 4a1 4a2 4a7 4a8 4ae 4b2
4b3 4b8 4bc 4c0 4c4 4c6 4ca 4cc
4d8 4dc 4de 4e2 4fe 4fa 4f9 506
517 50f 513 4f6 51f 50e 524 528
52c 530 54d 538 53c 544 548 50b
56c 554 558 55c 55f 567 537 588
577 57b 583 534 5a7 58f 593 597
59a 5a2 576 5c4 5b2 573 5b6 5b7
5bf 5b1 5e1 5cf 5ae 5d3 5d4 5dc
5ce 601 5ec 5f0 5f8 5fc 5cb 5e8
608 60c 610 613 617 61b 61f 622
623 625 626 628 62b 62e 62f 631
632 634 638 63c 640 643 647 64b
64f 650 652 654 658 65c 65e 662
666 668 669 66e 672 676 67a 67e
681 685 686 688 68c 68d 68f 693
697 69b 6a0 6a3 6a7 6ab 6ae 6b1
6b2 6b4 6b5 6ba 6bf 6c0 6c2 6c6
6ca 6ce 6d2 6d5 6d6 6d8 6dc 1
6e0 6e5 6ea 6ef 6f4 6f9 6fe 703
708 70d 712 717 71c 721 726 72b
730 735 739 73c 740 744 748 74a
74e 751 755 759 75c 75f 760 762
765 76a 76b 770 774 778 77c 77d
77f 783 786 787 78c 790 794 798
79a 79e 7a2 7a6 7a8 7ac 7b0 7b3
7b5 7b9 7bd 7c0 7c1 7c6 7ca 7ce
7cf 7d1 7d5 7d8 7d9 1 7de 7e3
7e7 7eb 7ef 7f1 7f5 7f9 7fd 7ff
803 807 80a 80c 810 814 817 819
81d 821 824 825 827 82b 82e 82f
834 838 83c 83d 83f 843 846 847
1 84c 851 855 859 85d 85f 863
867 86b 86d 871 875 878 87a 87e
882 885 887 1 88b 88f 893 897
89b 89d 8a1 8a4 8a6 8aa 8ae 8b1
8b3 8b4 8b9 8bd 8bf 8cb 8cd 8d1
8d5 8d9 8db 8df 8e1 8ed 8f1 8f3
8f7 90b 90f 910 914 918 931 920
924 92c 91f 938 93c 91c 940 943
944 949 94d 951 955 959 95b 95f
963 967 96a 96b 96d 970 975 976
97b 97f 983 987 989 98d 991 995
999 99d 9a0 9a4 9a5 9a7 9ab 9ad
9b1 9b5 9b8 9bc 9c0 9c4 9c6 9ca
9cc 9d8 9dc 9de 9fa 9f6 9f5 a02
a0f a0b 9f2 a17 a0a a1c a20 a24
a07 a28 a2b a2c a31 a36 a39 a3d
a3e a43 a46 a4b a4c a51 a54 a58
a59 a5e a5f a64 a66 a6a a6c a78
a7c a7e a92 a93 a97 a9b a9f aa3
aa6 aaa aae aaf ab4 ab6 aba abc
ac8 acc ace ad2 aee aea ae9 af6
b03 aff ae6 afe b0b afb b10 b14
b18 b1c b20 b24 b28 b2c b2f b33
b37 b3a b3e b42 b46 b49 b4a b4c
b4f b53 b54 b56 b5a b5c b60 b62
b6e b72 b74 b90 b8c b8b b98 ba5
ba1 b88 bad ba0 bb2 bb6 bcf bbe
bc2 bca b9d be7 bd6 bda be2 bbd
c03 bf2 bf6 bfe bba bee c0a c0e
c12 c16 c1a c1e c21 c25 c26 c28
c2c c30 c34 c38 c3b c3f c40 c42
c46 c4a c4e c51 c55 c59 c5d c60
c64 c69 c6a c6c c70 c75 c76 c78
c7c c81 c82 c84 c88 c8d c8e c90
c94 c98 c9c ca0 ca5 ca6 ca8 ca9
cab cae cb1 cb2 cb7 cba cbe cc2
cc6 ccb ccc cce ccf cd1 cd4 cd7
cd8 cdd cde ce3 ce6 cea cee cf2
cf7 cf8 cfa cfb cfd d00 d03 d04
d09 d0a d0f d12 d13 d15 d19 d1d
d21 d25 d2a d2b d2d d2e d30 d33
d37 d3b d3f d44 d45 d47 d48 d4a
d4d d50 d51 d56 d57 d5c d5f d63
d67 d6b d70 d71 d73 d74 d76 d79
d7c d7d d82 d85 d88 d8b d8c d91
d92 d97 d9a d9b d9d da1 da5 da8
dac daf db3 db6 db9 dba dbf dc0
dc2 dc6 dca dcd dd0 dd1 dd6 dd7
dd9 ddd de1 de5 de8 dec ded def
df0 df2 df6 dfa dfe dff e01 e04
e05 e07 e0b e10 e11 e13 e17 e1b
e1e e22 e23 e25 e26 e28 e29 e2e
e32 e36 e39 e3d e41 e45 e48 e4b
e4c e51 e55 e59 e5c e60 e61 e63
e66 e69 e6a e6f e72 e73 e78 e7c
e80 e83 e87 e88 e8d e8f e93 e95
ea1 ea5 ea7 ec3 ebf ebe ecb ed8
ed4 ebb ee0 ee9 ee5 ed3 ef1 efe
efa ed0 f06 ef9 f0b f0f ef6 f13
f15 f19 f1b f27 f2b f2d f49 f45
f44 f51 f66 f5a f5e f62 f41 f6d
f7e f72 f76 f7a f59 f85 f9a f8e
f92 f96 f56 fa1 f8d fa6 faa f8a
fae fb0 fb4 fb6 fc2 fc6 fc8 fcc
fe0 fe4 fe5 fe9 fed 1009 ff5 ff9
1001 1004 ff4 1025 1014 1018 1020 ff1
103d 102c 1030 1038 1013 1059 1048 104c
1054 1010 1088 1060 1064 1067 1068 1070
1074 1078 107b 1080 1081 1083 1047 10a4
1093 1097 109f 1044 108f 10ab 10af 10b3
10b6 10ba 10be 10c1 10c2 10c7 10cb 10cf
10d0 10d2 10d5 10da 10db 10e0 10e4 10e8
10ec 10ee 10f2 10f6 10fa 10fb 10fd 1101
1103 1107 110b 110e 1110 1114 1118 1119
111e 1120 1124 1128 112b 112f 1132 1135
1136 113b 113f 1143 1144 1149 114b 114f
1152 1156 115a 115b 115d 1160 1165 1166
116b 116f 1173 1177 117b 1180 1181 1183
1184 1186 118a 118e 1192 1195 1198 1199
119e 11a1 11a4 11a5 11aa 11ae 11b2 11b3
11b8 11ba 11be 11c1 11c3 11c7 11ca 11ce
11d2 11d6 11d9 11dd 11de 11e0 11e4 11e8
11ec 11f0 11f3 11f7 11fb 1200 1201 1203
1206 1207 1209 120d 1211 1215 1218 121b
121f 1220 1225 1227 122b 122f 1232 1235
1236 123b 123f 1243 1247 124a 124e 1252
1256 1259 125d 1262 1263 1265 1269 126e
126f 1271 1275 1279 127c 1280 1283 1287
128a 128d 128e 1293 1294 1296 129a 129f
12a0 12a2 12a6 12ab 12ac 12ae 12b2 12b7
12b8 12ba 12be 12c3 12c4 12c6 12ca 12ce
12d1 12d4 12d5 12da 12db 12dd 12e1 12e5
12e8 12ec 12f0 12f4 12f7 12fb 12ff 1302
1306 1309 130d 1310 1313 1314 1319 131a
131c 1320 1324 1327 1328 132a 132e 1331
1334 1335 133a 133b 133d 133e 1340 1341
1346 134a 134e 1352 1355 1359 135d 1362
1363 1365 1369 136c 136f 1370 1375 1376
1378 137c 137e 1382 1389 138d 1391 1395
1398 139c 139d 139f 13a3 13a7 13ab 13ae
13b2 13b6 13ba 13bd 13c1 13c6 13c7 13c9
13cd 13d2 13d3 13d5 13d9 13de 13df 13e1
13e5 13e9 13ec 13ed 13ef 13f3 13f7 13fa
13fb 13fd 1401 1405 1408 140c 140d 1412
1413 1415 1419 141d 141e 1420 1424 1428
142c 1430 1433 1437 1438 143a 143d 143e
1440 1443 1444 1446 144a 144b 144d 144e
1453 1457 145b 145f 1461 1465 1467 1473
1477 1479 147b 147d 1481 148d 1491 1493
1496 1498 1499 14a2 
584
2
0 1 9 e 1 b 14 1f
:2 1c 14 28 b 1 3 11 1c
:2 19 11 25 11 :2 3 e 1b :2 16
:2 e 3 2 :2 c 17 c :2 2 15
20 :2 15 29 15 2 3 16 21
:2 16 2a 16 :2 3 11 1e :2 19 11
27 11 :2 3 :3 f 3 2 b 5
0 c :2 2 5 c 5 :2 3 :4 2
b 3 9 :2 3 16 :2 1 3 1b
1c :2 1b 22 :2 3 :6 1 b 3 a
:3 3 7 :2 3 13 :2 1 3 9 16
:2 11 :2 9 3 6 d f :2 d 5
e 5 3 15 9 10 12 :2 10
5 e 5 3 18 15 9 10
12 :2 10 5 e 5 18 15 :2 3
:4 6 5 e 16 1c 21 :2 e 5
16 :3 3 b 12 19 1c :2 12 23
26 :2 12 2a 2d :2 12 33 35 :2 b
:2 3 1b 1c :2 1b 22 :2 3 :7 1 a
3 0 a :2 1 3 9 14 :3 9
3 a :2 15 26 29 :2 37 :4 a 8
3 8 9 10 12 :2 10 :6 3 a
3 :7 1 a 3 0 a :2 1 3
9 14 :3 9 3 a 12 :4 a 8
c 8 3 8 9 10 12 :2 10
:6 3 a 3 :7 1 a 3 9 :3 3
b 1b :2 3 12 5 c :2 1 3
:2 9 14 9 :2 3 9 14 :3 9 :2 3
:3 a :2 3 a 15 :3 a :2 3 9 d
c :2 9 :2 3 11 15 14 :2 11 :2 3
:2 c 17 c 3 5 14 :2 1c 28
2f 37 3c :2 37 :2 2f 41 43 :2 28
:2 14 :2 5 :2 1e 7 10 19 :2 10 :2 7
e :2 7 19 7 :2 5 3 c 12
:2 1a 2b :2 12 32 :2 c 3 2 c
14 19 1c 23 29 2b :2 1c :2 14
2e :2 c :2 2 c 13 19 :2 c 2
:2 6 12 1d 29 12 1b 26 2e
12 1c :2 12 1a 22 12 1d 24
2b :2 6 5 11 5 15 :2 3 5
c 13 15 :2 5 18 1b :2 18 8
a 10 :2 a 1c :3 19 9 12 9
23 9 12 9 :4 7 11 a 13
:3 11 25 2b :2 25 37 :3 34 :2 a 9
12 9 3e 9 12 9 :4 7 :4 5
22 7 e 15 :2 7 1a :3 18 26
2c :2 26 38 :3 35 :2 7 6 f 6
3f 6 f 6 :4 4 5 :3 2 3
:2 a 8 4 d 4 10 :2 7 :4 5
11 :2 5 3 :3 1 3 a 3 :7 1
a 3 0 a :2 1 3 :3 9 3
6 :2 11 :3 6 5 e 5 3 24
9 f :2 1a :2 9 26 28 :2 26 5
e 5 30 24 5 e 17 :2 22
2d :2 e 5 :5 3 a 3 :6 1 b
17 1e :2 17 28 2e :2 28 16 :2 1
5 1d 1e :2 1d 25 34 37 :2 25
3e 41 :2 25 4a 4d :2 25 :2 5 :2 3
:4 1 b 0 :2 1 3 :2 c 1c 29
:2 3 :7 1 a 3 c :3 3 e 1d
:2 3 17 5 c :2 1 3 a :2 12
19 :2 21 3a 43 :2 4b :2 19 5a 5c
:2 a 3 :6 1 b 3 e :3 3 a
:2 3 12 :2 1 3 :3 a :2 3 :3 a :2 3
:3 a :2 3 d :2 3 d :2 1a 26 :2 d
:2 3 d :2 16 20 :2 d :2 3 :2 c :2 13
:2 1b 22 2b :2 22 37 40 :2 37 48
51 :2 48 59 62 :2 59 22 30 3a
42 49 :2 3a :2 30 50 52 :2 30 54
30 3a 42 49 :2 3a :2 30 50 52
:4 30 55 30 3a 42 48 :2 3a :2 30
51 53 :4 30 58 :3 22 30 3a 42
49 :2 3a :2 30 50 30 3a 42 49
:2 3a :2 30 50 52 :4 30 55 31 3b
43 49 :2 3b :2 31 52 54 :2 31 30
5a 5c :4 30 60 :3 22 :2 2b 32 3a
3d 44 46 :2 3d :2 22 24 32 39
3b :2 32 :3 24 32 :2 3b 45 :2 32 :3 24
32 39 :2 32 46 :3 24 2d :3 24 :2 2c
38 :2 24 :2 13 :3 3 :2 c :3 11 18 1a
:3 11 :2 1a 24 :2 11 31 33 :3 11 :3 3
:2 c 1a :2 3 :6 1 b 3 e :3 3
a :3 3 b :3 3 b :2 3 1f :2 1
3 :6 1 b 3 d :3 3 b f
16 :3 3 b f 16 :3 3 b f
16 :2 3 22 :2 1 3 :7 1 a 3
0 a :2 1 3 :2 15 24 15 :2 3
:3 15 :2 3 :3 15 :2 3 :3 15 :2 3 15 19
18 15 23 :2 2b 37 :2 23 15 :2 3
:3 8 :2 3 11 :2 1c 3 :4 5 7 d
:2 7 19 1b :2 19 6 13 6 23
6 13 1c :2 13 6 :4 4 1c 4
10 :2 4 :4 2 a 9 :3 6 4 10
:2 4 15 :2 3 6 c :2 6 18 1a
:2 18 3 b 15 1d 25 :2 15 :2 b
3 8 c 11 :3 8 15 17 :2 15
8 14 :2 8 19 :2 5 22 :3 3 18
:2 21 2b :2 18 :2 3 18 :2 21 27 33
3c :2 33 48 :2 18 :2 3 9 10 12
14 :2 10 3 5 e 14 16 :2 e
:2 5 :2 e :2 15 :2 1d 24 2d :3 24 2d
:3 24 :2 2d 34 40 43 4a 4c :2 43
:3 24 2d :3 24 2d :3 24 2d :3 24 2d
:3 24 32 39 3b :2 32 :3 24 :2 2d :2 34
:2 3c 34 :2 3d 44 50 52 59 5b
:2 52 :2 34 5f :2 67 :3 34 3b 3d :2 34
:2 24 :2 15 :3 5 f :2 18 1e 2a 33
:2 2a 3f 46 48 :2 3f :2 f 5 14
7 :2 3 18 :2 21 2b :2 18 3 5
:2 e :2 15 :2 1d 24 2d :3 24 2d :3 24
2d :3 24 32 39 :3 24 32 39 :3 24
32 44 46 :2 32 :3 24 32 :3 24 32
36 :2 3e 45 :2 36 50 :2 32 53 :3 24
:2 15 :2 5 3 a 3 :6 1 :4 2 5
:6 1 
584
4
0 :3 1 :a 3 :9 7
:8 8 :6 9 :8 b :8 c
:9 d :5 f :2 11 12
0 12 :2 11 :3 14
:2 13 :4 11 17 :4 18
:3 17 :8 1c :2 1a :4 17
1f :4 20 :4 21 :3 1f
:8 24 :5 26 :3 27 28
26 :5 28 :3 29 2a
28 26 :5 2a :3 2b
2a :3 26 :4 2d :8 2e
:3 2d :14 30 :8 32 :2 25
:4 1f :2 36 37 0
37 :2 36 :7 38 :a 3a
3b :3 3c :5 3d 3c
:4 3a :3 3f :2 39 :4 36
:2 42 43 0 43
:2 42 :7 44 :5 46 47
:5 48 :5 49 48 :4 46
:3 4b :2 45 :4 42 :2 4e
:4 4f :5 50 4e :2 51
:2 4e :6 52 :7 53 :5 54
:7 55 :7 56 :7 57 :6 58
:13 5b :3 5c :6 5d :3 5e
:3 5f :2 5c :c 60 :10 61
:7 62 :5 64 :4 65 :2 66
67 :3 68 :4 69 :2 64
:3 6b 6a :2 64 :a 6e
6f :8 70 :3 71 70
:3 73 72 :3 70 6f
:f 76 :3 77 76 :3 79
78 :3 76 75 :3 6f
6e :13 7d :3 7e 7d
:3 80 7f :3 7d 7c
:3 6e 5a :2 84 85
:3 86 85 :2 88 87
:3 85 :3 84 83 :3 59
:3 8c :2 59 :4 4e :2 8f
90 0 90 :2 8f
:5 91 :6 93 :3 94 95
93 :a 95 :3 96 95
93 :9 98 97 :3 93
:3 9a :2 92 :4 8f :c 9d
:14 9f :2 9e :4 9d a2
0 :2 a2 :7 a5 :2 a4
:4 a2 :2 a8 :4 a9 :5 aa
a8 :2 ab :2 a8 :12 ad
:2 ac :4 a8 b0 :4 b1
:4 b2 :3 b0 :5 b4 :5 b5
:5 b6 :3 b8 :8 b9 :8 ba
:4 bb :13 bc :e bd :c be
:2 bd be :c bf :2 bd
bf :2 bd :a c0 :c c1
:2 c0 c1 :11 c2 :2 c0
c2 :2 c0 :c c3 :8 c4
:9 c5 :8 c6 :4 c7 :6 c8
:2 bc :2 bb :4 cb cc
:5 cd :a ce cf :2 cb
:6 d0 :2 b7 :4 b0 d3
:4 d4 :4 d5 :4 d6 :4 d7
:3 d3 da :2 d9 :4 d3
dd :4 de :6 df :6 e0
:6 e1 :3 dd e4 :2 e3
:4 dd :2 e7 e8 0
e8 :2 e7 :6 e9 :5 ea
:5 eb :5 ec :d ed :5 ee
:5 f1 :4 f2 :8 f3 :3 f4
f3 :6 f6 f5 :3 f3
f2 :4 f9 f8 :3 f2
:5 fb :4 fc :3 fb :8 ff
:a 100 :a 101 :4 102 :3 101
:3 ff :8 107 :d 108 :8 10a
:7 10b :4 10c :7 10d :4 10e
:c 10f :4 110 :4 111 :4 112
:4 113 :8 114 :4 115 :3 116
:f 117 :2 116 :5 118 :2 115
:2 10d :2 10c :11 11c 10a
11d 10a :8 11f :4 120
:7 121 :4 122 :4 123 :5 124
:5 125 :8 126 :4 127 :e 128
129 :2 121 :2 120 :3 12b
:2 ef :4 e7 :4 11 131
:6 1 
14a4
4
:3 0 1 :3 0 2
:3 0 3 :6 0 1
:2 0 b :2 0 6
5 :3 0 6 :3 0
7 :3 0 8 :2 0
3 6 9 :6 0
9 :4 0 d a
b 57e 4 :6 0
e :2 0 b 6
:3 0 7 :3 0 8
f 12 :6 0 c
:4 0 16 13 14
57e 0 a :6 0
12 88 0 10
6 :3 0 7 :3 0
d 18 1b :6 0
1e 1c 0 57e
0 d :6 0 2e
2f 0 14 10
:3 0 20 :7 0 11
:3 0 24 21 22
57e 0 f :6 0
13 :3 0 14 :2 0
4 26 27 0
28 :7 0 15 :4 0
2c 29 2a 57e
0 12 :6 0 19
:2 0 16 13 :3 0
14 :2 0 4 30
:7 0 17 :4 0 34
31 32 57e 0
16 :6 0 1d 117
0 1b 6 :3 0
7 :3 0 18 36
39 :6 0 1a :4 0
3d 3a 3b 57e
0 18 :6 0 1d
:3 0 1c :3 0 3f
:7 0 42 40 0
57e 0 1b :6 0
1e :a 0 51 2
:7 0 1f :4 0 6
:3 0 46 47 0
51 44 48 :2 0
1f :3 0 4 :3 0
4b :2 0 4d 1f
50 :3 0 50 0
50 4f 4d 4e
:6 0 51 1 0
44 48 50 57e
:2 0 20 :a 0 67
3 :7 0 23 :2 0
21 6 :3 0 21
:7 0 56 55 :3 0
58 :2 0 67 53
59 :2 0 22 :3 0
23 :2 0 24 :2 0
25 5c 5e :3 0
21 :3 0 27 5b
61 :2 0 63 2a
66 :3 0 66 0
66 65 63 64
:6 0 67 1 0
53 59 66 57e
:2 0 25 :a 0 cd
4 :7 0 2e 20c
0 2c 6 :3 0
26 :7 0 6c 6b
:3 0 19 :2 0 30
6 :3 0 27 :7 0
70 6f :3 0 72
:2 0 cd 69 73
:2 0 29 :2 0 36
6 :3 0 7 :3 0
33 76 79 :6 0
7c 7a 0 cb
0 28 :6 0 26
:3 0 2a :4 0 3a
7e 80 :3 0 28
:3 0 2b :4 0 82
83 0 86 2c
:3 0 3d 9c 26
:3 0 29 :2 0 2d
:4 0 41 88 8a
:3 0 28 :3 0 2e
:4 0 8c 8d 0
90 2c :3 0 44
91 8b 90 0
9d 26 :3 0 29
:2 0 2f :4 0 48
93 95 :3 0 28
:3 0 30 :4 0 97
98 0 9a 4b
9b 96 9a 0
9d 81 86 0
9d 4d 0 c9
27 :3 0 31 :2 0
51 9f a0 :3 0
28 :3 0 32 :3 0
28 :3 0 33 :4 0
27 :3 0 53 a3
a7 a2 a8 0
aa 57 ab a1
aa 0 ac 59
0 c9 28 :3 0
34 :3 0 35 :4 0
36 :2 0 26 :3 0
5b b0 b2 :3 0
36 :2 0 37 :4 0
5e b4 b6 :3 0
36 :2 0 28 :3 0
61 b8 ba :3 0
b :2 0 19 :2 0
64 ae be ad
bf 0 c9 22
:3 0 23 :2 0 24
:2 0 68 c2 c4
:3 0 28 :3 0 6a
c1 c7 :2 0 c9
6d cc :3 0 cc
72 cc cb c9
ca :6 0 cd 1
0 69 73 cc
57e :2 0 1d :3 0
38 :a 0 fc 5
:7 0 1f :4 0 6
:3 0 d2 d3 0
fc d0 d4 :2 0
dd de 0 74
13 :3 0 14 :2 0
4 d7 d8 0
d9 :7 0 dc da
0 fa 0 39
:6 0 3a :3 0 3b
:3 0 36 :2 0 3c
:3 0 3d :3 0 e1
e2 0 76 e0
e4 :3 0 79 39
:3 0 3e :3 0 7b
e9 ef 0 f0
:3 0 3f :3 0 40
:2 0 41 :2 0 7f
ec ee :4 0 f2
f3 :5 0 e6 ea
0 82 0 f1
:2 0 f8 1f :3 0
39 :3 0 f6 :2 0
f8 84 fb :3 0
fb 87 fb fa
f8 f9 :6 0 fc
1 0 d0 d4
fb 57e :2 0 1d
:3 0 42 :a 0 128
6 :7 0 1f :4 0
6 :3 0 101 102
0 128 ff 103
:2 0 8b :2 0 89
13 :3 0 14 :2 0
4 106 107 0
108 :7 0 10b 109
0 126 0 39
:6 0 43 :3 0 44
:3 0 10c 10e 8d
39 :3 0 45 :3 0
46 :2 0 4 112
113 0 8f 115
11b 0 11c :3 0
3f :3 0 40 :2 0
41 :2 0 93 118
11a :4 0 11e 11f
:5 0 110 116 0
96 0 11d :2 0
124 1f :3 0 39
:3 0 122 :2 0 124
98 127 :3 0 127
9b 127 126 124
125 :6 0 128 1
0 ff 103 127
57e :2 0 1d :3 0
47 :a 0 245 7
:7 0 9f 50b 0
9d 6 :3 0 48
:7 0 12e 12d :3 0
a4 534 0 a1
10 :3 0 4a :3 0
49 :7 0 133 131
132 :2 0 1f :3 0
10 :3 0 135 137
0 245 12b 138
:2 0 a8 573 0
a6 10 :3 0 13b
:7 0 11 :3 0 13f
13c 13d 243 0
39 :6 0 13 :3 0
14 :2 0 4 141
142 0 143 :7 0
146 144 0 243
0 4b :6 0 51
:2 0 aa 4d :3 0
148 :7 0 14b 149
0 243 0 4c
:6 0 13 :3 0 14
:2 0 4 14d 14e
0 14f :7 0 152
150 0 243 0
4e :6 0 51 :2 0
ae 50 :3 0 ac
154 156 :6 0 159
157 0 243 0
4f :6 0 b4 5e8
0 b2 50 :3 0
b0 15b 15d :6 0
160 15e 0 243
0 52 :6 0 52
:3 0 10 :3 0 162
:7 0 11 :3 0 166
163 164 243 0
53 :6 0 54 :3 0
55 :3 0 168 169
0 34 :3 0 43
:3 0 56 :3 0 57
:2 0 b6 16d 16f
b8 16c 171 58
:2 0 59 :2 0 ba
16b 175 be 16a
177 167 178 0
229 5a :3 0 5b
:3 0 17a 17b 0
5c :3 0 5d :3 0
48 :3 0 c0 17e
180 17d 181 5e
:3 0 52 :3 0 183
184 5f :3 0 4f
:3 0 186 187 c2
17c 189 :2 0 229
4b :3 0 60 :3 0
54 :3 0 61 :3 0
18d 18e 0 4f
:3 0 c6 18f 191
a :3 0 c8 18c
194 18b 195 0
229 4c :3 0 62
:3 0 63 :4 0 36
:2 0 34 :3 0 4b
:3 0 b :2 0 64
:2 0 cb 19b 19f
cf 19a 1a1 :3 0
65 :4 0 d2 198
1a4 197 1a5 0
229 4e :3 0 34
:3 0 4b :3 0 66
:2 0 d5 1a8 1ab
1a7 1ac 0 229
4e :3 0 67 :4 0
68 :4 0 69 :4 0
6a :4 0 6b :4 0
6c :4 0 6d :4 0
6e :4 0 6f :4 0
70 :4 0 71 :4 0
72 :4 0 73 :4 0
74 :4 0 75 :4 0
76 :4 0 77 :4 0
d8 :3 0 1ae 1af
1c1 53 :3 0 4a
:3 0 1c3 1c4 0
1c6 ea 1c7 1c2
1c6 0 1c8 ec
0 229 34 :3 0
4e :3 0 b :2 0
78 :2 0 ee 1c9
1cd 79 :2 0 44
:4 0 f4 1cf 1d1
:3 0 53 :3 0 7a
:3 0 7b :3 0 f7
1d4 1d6 4c :3 0
7c :2 0 fb 1d9
1da :3 0 39 :3 0
4a :3 0 1dc 1dd
0 1df fe 1e4
39 :3 0 11 :3 0
1e0 1e1 0 1e3
100 1e5 1db 1df
0 1e6 0 1e3
0 1e6 102 0
1e7 105 203 4e
:3 0 38 :3 0 29
:2 0 109 1ea 1eb
:3 0 7a :3 0 7b
:3 0 10c 1ed 1ef
4c :3 0 7c :2 0
110 1f2 1f3 :3 0
1ec 1f5 1f4 :2 0
39 :3 0 4a :3 0
1f7 1f8 0 1fa
113 1ff 39 :3 0
11 :3 0 1fb 1fc
0 1fe 115 200
1f6 1fa 0 201
0 1fe 0 201
117 0 202 11a
204 1d3 1e7 0
205 0 202 0
205 11c 0 206
11f 226 34 :3 0
4e :3 0 8 :2 0
121 207 20a 42
:3 0 29 :2 0 126
20d 20e :3 0 7a
:3 0 7b :3 0 129
210 212 4c :3 0
7c :2 0 12d 215
216 :3 0 20f 218
217 :2 0 39 :3 0
4a :3 0 21a 21b
0 21d 130 222
39 :3 0 11 :3 0
21e 21f 0 221
132 223 219 21d
0 224 0 221
0 224 134 0
225 137 227 1d2
206 0 228 0
225 0 228 139
0 229 13c 23c
7d :3 0 49 :3 0
39 :3 0 11 :3 0
22d 22e 0 230
144 234 7e :5 0
233 146 235 22c
230 0 236 0
233 0 236 148
0 237 14b 239
14d 238 237 :2 0
23a 14f :2 0 23c
0 23c 23b 229
23a :6 0 241 7
:3 0 1f :3 0 39
:3 0 23f :2 0 241
151 244 :3 0 244
154 244 243 241
242 :6 0 245 1
0 12b 138 244
57e :2 0 1d :3 0
7f :a 0 281 9
:7 0 1f :4 0 10
:3 0 24a 24b 0
281 248 24c :2 0
253 254 0 15c
10 :3 0 24f :7 0
252 250 0 27f
0 39 :6 0 80
:3 0 81 :3 0 82
:2 0 15e 256 257
:3 0 39 :3 0 11
:3 0 259 25a 0
25d 2c :3 0 160
277 83 :3 0 80
:3 0 81 :3 0 25f
260 0 162 25e
262 29 :2 0 84
:4 0 166 264 266
:3 0 39 :3 0 4a
:3 0 268 269 0
26b 169 26c 267
26b 0 279 39
:3 0 47 :3 0 80
:3 0 81 :3 0 26f
270 0 11 :3 0
16b 26e 273 26d
274 0 276 16e
278 258 25d 0
279 0 276 0
279 170 0 27d
1f :3 0 39 :3 0
27b :2 0 27d 174
280 :3 0 280 177
280 27f 27d 27e
:6 0 281 1 0
248 24c 280 57e
:2 0 20 :a 0 2a7
a :7 0 17b a07
0 179 6 :3 0
85 :7 0 286 285
:3 0 23 :2 0 17d
6 :3 0 21 :7 0
28a 289 :3 0 28c
:2 0 2a7 283 28d
:2 0 22 :3 0 24
:2 0 180 290 292
:3 0 86 :4 0 36
:2 0 85 :3 0 182
295 297 :3 0 36
:2 0 87 :4 0 185
299 29b :3 0 36
:2 0 21 :3 0 188
29d 29f :3 0 18b
28f 2a1 :2 0 2a3
18e 2a6 :3 0 2a6
0 2a6 2a5 2a3
2a4 :6 0 2a7 1
0 283 28d 2a6
57e :2 0 88 :a 0
2b8 b :8 0 2aa
:2 0 2b8 2a9 2ab
:2 0 89 :3 0 8a
:3 0 2ad 2ae 0
1b :3 0 4a :3 0
190 2af 2b2 :2 0
2b4 193 2b7 :3 0
2b7 0 2b7 2b6
2b4 2b5 :6 0 2b8
1 0 2a9 2ab
2b7 57e :2 0 1d
:3 0 8b :a 0 2e0
c :7 0 78 :2 0
195 8d :3 0 8c
:7 0 2be 2bd :3 0
199 :2 0 197 8f
:3 0 8e :7 0 2c3
2c1 2c2 :2 0 1f
:3 0 50 :3 0 2c5
2c7 0 2e0 2bb
2c8 :2 0 1f :3 0
54 :3 0 34 :3 0
2cb 2cc 0 54
:3 0 90 :3 0 2ce
2cf 0 8c :3 0
54 :3 0 8b :3 0
2d2 2d3 0 19c
2d0 2d5 b :2 0
8e :3 0 19f 2cd
2d9 2da :2 0 2dc
1a3 2df :3 0 2df
0 2df 2de 2dc
2dd :6 0 2e0 1
0 2bb 2c8 2df
57e :2 0 91 :a 0
3d8 d :7 0 1a7
b9d 0 1a5 6
:3 0 92 :7 0 2e5
2e4 :3 0 1ac bba
0 1a9 1c :3 0
93 :7 0 2e9 2e8
:3 0 2eb :2 0 3d8
2e2 2ec :2 0 1b0
bee 0 1ae 4d
:3 0 2ef :7 0 2f2
2f0 0 3d6 0
94 :6 0 1c :3 0
2f4 :7 0 2f7 2f5
0 3d6 0 95
:6 0 94 :3 0 97
:3 0 2f9 :7 0 2fc
2fa 0 3d6 0
96 :6 0 7b :3 0
2fd 2fe 0 3d4
95 :3 0 98 :3 0
99 :3 0 301 302
0 93 :3 0 1b2
303 305 300 306
0 3d4 96 :3 0
89 :3 0 9a :3 0
309 30a 0 95
:3 0 1b4 30b 30d
308 30e 0 3d4
89 :3 0 9b :3 0
310 311 0 1b
:3 0 54 :3 0 9c
:3 0 314 315 0
5d :3 0 9d :4 0
1b6 317 319 5d
:3 0 9e :4 0 1b8
31b 31d 5d :3 0
9f :4 0 1ba 31f
321 5d :3 0 a0
:4 0 1bc 323 325
8b :3 0 a1 :3 0
43 :3 0 94 :3 0
a2 :4 0 1be 329
32c 1c1 328 32e
a3 :2 0 41 :2 0
1c3 330 332 :3 0
a4 :2 0 a1 :3 0
43 :3 0 94 :3 0
a5 :4 0 1c6 336
339 1c9 335 33b
a6 :2 0 a7 :2 0
1cb 33d 33f :3 0
1ce 334 341 :3 0
a4 :2 0 a1 :3 0
43 :3 0 94 :3 0
a8 :4 0 1d1 345
348 1d4 344 34a
a6 :2 0 51 :2 0
1d6 34c 34e :3 0
1d9 343 350 :3 0
41 :2 0 1dc 327
353 8b :3 0 a1
:3 0 43 :3 0 94
:3 0 a9 :4 0 1df
357 35a 1e2 356
35c a4 :2 0 a1
:3 0 43 :3 0 94
:3 0 aa :4 0 1e4
360 363 1e7 35f
365 a6 :2 0 a7
:2 0 1e9 367 369
:3 0 1ec 35e 36b
:3 0 a4 :2 0 a1
:3 0 43 :3 0 94
:3 0 ab :4 0 1ef
36f 372 1f2 36e
374 23 :2 0 ac
:2 0 1f4 376 378
:3 0 379 :2 0 a6
:2 0 ad :2 0 1f7
37b 37d :3 0 1fa
36d 37f :3 0 41
:2 0 1fd 355 382
89 :3 0 34 :3 0
384 385 0 95
:3 0 78 :2 0 96
:3 0 23 :2 0 66
:2 0 200 38a 38c
:3 0 203 386 38e
8b :3 0 96 :3 0
23 :2 0 ae :2 0
207 392 394 :3 0
20a 390 396 8b
:3 0 89 :3 0 9a
:3 0 399 39a 0
93 :3 0 20c 39b
39d 20e 398 39f
8b :3 0 af :3 0
92 :3 0 210 3a2
3a4 41 :2 0 212
3a1 3a7 5d :3 0
9f :4 0 215 3a9
3ab 54 :3 0 55
:3 0 3ad 3ae 0
92 :3 0 217 3af
3b1 219 316 3b3
226 312 3b5 :2 0
3d4 89 :3 0 b0
:3 0 3b7 3b8 0
1b :3 0 95 :3 0
96 :3 0 23 :2 0
ae :2 0 229 3bd
3bf :3 0 89 :3 0
9a :3 0 3c1 3c2
0 1b :3 0 22c
3c3 3c5 a4 :2 0
b :2 0 22e 3c7
3c9 :3 0 b1 :2 0
231 3b9 3cc :2 0
3d4 89 :3 0 b2
:3 0 3ce 3cf 0
95 :3 0 237 3d0
3d2 :2 0 3d4 239
3d7 :3 0 3d7 240
3d7 3d6 3d4 3d5
:6 0 3d8 1 0
2e2 2ec 3d7 57e
:2 0 b3 :a 0 3f3
e :7 0 246 ed0
0 244 6 :3 0
92 :7 0 3dd 3dc
:3 0 24a ef6 0
248 1c :3 0 93
:7 0 3e1 3e0 :3 0
50 :3 0 b4 :7 0
3e5 3e4 :4 0 3ef
0 24c 50 :3 0
b5 :7 0 3e9 3e8
:3 0 3eb :2 0 3f3
3da 3ec :2 0 251
3f2 :3 0 3f2 0
3f2 3f1 3ef 3f0
:6 0 3f3 1 0
3da 3ec 3f2 57e
:2 0 b6 :a 0 414
f :7 0 255 f56
0 253 1c :3 0
93 :7 0 3f8 3f7
:3 0 259 f8a 0
257 b8 :3 0 b9
:3 0 1c :3 0 b7
:5 0 1 3fe 3fd
:3 0 b8 :3 0 b9
:3 0 50 :3 0 b4
:5 0 1 404 403
:4 0 410 0 25b
b8 :3 0 b9 :3 0
50 :3 0 b5 :5 0
1 40a 409 :3 0
40c :2 0 414 3f5
40d :2 0 260 413
:3 0 413 0 413
412 410 411 :6 0
414 1 0 3f5
40d 413 57e :2 0
1d :3 0 ba :a 0
577 10 :7 0 1f
:4 0 1c :3 0 419
41a 0 577 417
41b :2 0 264 1010
0 262 8f :3 0
41e :7 0 bc :2 0
422 41f 420 575
0 bb :6 0 268
1044 0 266 97
:3 0 424 :7 0 427
425 0 575 0
bd :6 0 97 :3 0
429 :7 0 42c 42a
0 575 0 be
:6 0 270 108f 0
26e 97 :3 0 42e
:7 0 431 42f 0
575 0 bf :6 0
50 :3 0 c1 :2 0
26a 433 435 :6 0
54 :3 0 55 :3 0
437 438 0 c2
:4 0 26c 439 43b
43e 436 43c 575
0 c0 :6 0 d
:3 0 8d :3 0 440
:7 0 443 441 0
575 0 c3 :6 0
80 :3 0 81 :3 0
445 446 0 444
447 0 573 d
:3 0 31 :2 0 272
44a 44b :3 0 83
:3 0 d :3 0 274
44d 44f 29 :2 0
84 :4 0 278 451
453 :3 0 f :3 0
4a :3 0 455 456
0 458 27b 460
f :3 0 47 :3 0
d :3 0 27d 45a
45c 459 45d 0
45f 27f 461 454
458 0 462 0
45f 0 462 281
0 463 284 469
20 :3 0 12 :3 0
286 464 466 :2 0
468 288 46a 44c
463 0 46b 0
468 0 46b 28a
0 573 f :3 0
46c :2 0 c4 :2 0
28d 46e 46f :3 0
20 :3 0 16 :3 0
28f 471 473 :2 0
475 291 476 470
475 0 477 293
0 573 83 :3 0
d :3 0 295 478
47a 29 :2 0 84
:4 0 299 47c 47e
:3 0 c3 :3 0 a1
:3 0 43 :3 0 7b
:3 0 c5 :4 0 29c
482 485 29f 481
487 480 488 0
49b c6 :3 0 c3
:3 0 c7 :2 0 c6
:2 0 2a1 48d 48e
:3 0 29 :2 0 bc
:2 0 2a6 490 492
:3 0 20 :3 0 18
:3 0 2a9 494 496
:2 0 498 2ab 499
493 498 0 49a
2ad 0 49b 2af
49c 47f 49b 0
49d 2b2 0 573
be :3 0 89 :3 0
9a :3 0 49f 4a0
0 1b :3 0 2b4
4a1 4a3 49e 4a4
0 573 bd :3 0
89 :3 0 c8 :3 0
4a7 4a8 0 1b
:3 0 5d :3 0 9d
:4 0 2b6 4ab 4ad
b :2 0 2b8 4a9
4b0 4a6 4b1 0
573 c9 :3 0 bd
:3 0 ca :2 0 bc
:2 0 cb :3 0 2be
4b5 4b8 :3 0 4b9
52b bb :3 0 bb
:3 0 a4 :2 0 b
:2 0 2c1 4bd 4bf
:3 0 4bb 4c0 0
529 89 :3 0 9b
:3 0 4c2 4c3 0
1b :3 0 54 :3 0
9c :3 0 4c6 4c7
0 5d :3 0 cc
:4 0 2c4 4c9 4cb
5d :3 0 9e :4 0
2c6 4cd 4cf 89
:3 0 34 :3 0 4d1
4d2 0 1b :3 0
cd :2 0 bd :3 0
a4 :2 0 78 :2 0
2c8 4d7 4d9 :3 0
2cb 4d3 4db 5d
:3 0 9f :4 0 2cf
4dd 4df 5d :3 0
9f :4 0 2d1 4e1
4e3 5d :3 0 ce
:4 0 2d3 4e5 4e7
5d :3 0 cf :4 0
2d5 4e9 4eb 8b
:3 0 bd :3 0 23
:2 0 b :2 0 2d7
4ef 4f1 :3 0 2da
4ed 4f3 89 :3 0
34 :3 0 4f5 4f6
0 1b :3 0 54
:3 0 d0 :3 0 4f9
4fa 0 89 :3 0
34 :3 0 4fc 4fd
0 1b :3 0 41
:2 0 bd :3 0 a4
:2 0 cd :2 0 2dc
502 504 :3 0 2df
4fe 506 54 :3 0
8b :3 0 508 509
0 2e3 4fb 50b
bd :3 0 a4 :2 0
d1 :2 0 2e6 50e
510 :3 0 2e9 4f7
512 2ed 4c8 514
2f7 4c4 516 :2 0
529 bd :3 0 89
:3 0 c8 :3 0 519
51a 0 1b :3 0
5d :3 0 9d :4 0
2fa 51d 51f bd
:3 0 a4 :2 0 a7
:2 0 2fc 522 524
:3 0 2ff 51b 526
518 527 0 529
303 52b cb :3 0
4ba 529 :4 0 573
bf :3 0 89 :3 0
9a :3 0 52d 52e
0 1b :3 0 307
52f 531 52c 532
0 573 89 :3 0
9b :3 0 534 535
0 1b :3 0 54
:3 0 9c :3 0 538
539 0 5d :3 0
d2 :4 0 309 53b
53d 5d :3 0 9f
:4 0 30b 53f 541
5d :3 0 9f :4 0
30d 543 545 8b
:3 0 bb :3 0 41
:2 0 30f 547 54a
8b :3 0 bb :3 0
41 :2 0 312 54c
54f 8b :3 0 bf
:3 0 23 :2 0 be
:3 0 315 553 555
:3 0 318 551 557
8b :3 0 be :3 0
31a 559 55b 8b
:3 0 d3 :3 0 54
:3 0 af :3 0 55f
560 0 c0 :3 0
31c 561 563 bc
:2 0 31e 55e 566
41 :2 0 321 55d
569 c0 :3 0 324
53a 56c 32e 536
56e :2 0 573 1f
:3 0 1b :3 0 571
:2 0 573 331 576
:3 0 576 33c 576
575 573 574 :6 0
577 1 0 417
41b 576 57e :3 0
57c 0 57c :3 0
57c 57e 57a 57b
:6 0 57f :2 0 3
:3 0 343 0 3
57c 582 :3 0 581
57f 583 :8 0 
35a
4
:3 0 2 8 7
1 4 2 11
10 1 e 2
1a 19 1 17
1 1f 1 25
1 2d 2 38
37 1 35 1
3e 1 4c 1
54 1 57 1
5d 2 5f 60
1 62 1 6a
1 6e 2 6d
71 2 78 77
1 75 1 7f
2 7d 7f 1
84 1 89 2
87 89 1 8e
1 94 2 92
94 1 99 3
9c 91 9b 1
9e 3 a4 a5
a6 1 a9 1
ab 2 af b1
2 b3 b5 2
b7 b9 3 bb
bc bd 1 c3
2 c5 c6 4
9d ac c0 c8
1 7b 1 d6
2 df e3 1
e5 1 e8 1
ed 2 eb ed
1 e7 2 f4
f7 1 db 1
105 1 10d 1
10f 1 114 1
119 2 117 119
1 111 2 120
123 1 10a 1
12c 1 130 2
12f 134 1 13a
1 140 1 147
1 14c 1 155
1 153 1 15c
1 15a 1 161
1 16e 1 170
3 172 173 174
1 176 1 17f
3 182 185 188
1 190 2 192
193 3 19c 19d
19e 2 199 1a0
2 1a2 1a3 2
1a9 1aa 11 1b0
1b1 1b2 1b3 1b4
1b5 1b6 1b7 1b8
1b9 1ba 1bb 1bc
1bd 1be 1bf 1c0
1 1c5 1 1c7
3 1ca 1cb 1cc
1 1d0 2 1ce
1d0 1 1d5 1
1d8 2 1d7 1d8
1 1de 1 1e2
2 1e4 1e5 1
1e6 1 1e9 2
1e8 1e9 1 1ee
1 1f1 2 1f0
1f1 1 1f9 1
1fd 2 1ff 200
1 201 2 203
204 1 205 2
208 209 1 20c
2 20b 20c 1
211 1 214 2
213 214 1 21c
1 220 2 222
223 1 224 2
226 227 7 179
18a 196 1a6 1ad
1c8 228 1 22f
1 232 2 234
235 1 236 1
22b 1 239 2
23c 240 7 13e
145 14a 151 158
15f 165 1 24e
1 255 1 25b
1 261 1 265
2 263 265 1
26a 2 271 272
1 275 3 277
26c 278 2 279
27c 1 251 1
284 1 288 2
287 28b 1 291
2 294 296 2
298 29a 2 29c
29e 2 293 2a0
1 2a2 2 2b0
2b1 1 2b3 1
2bc 1 2c0 2
2bf 2c4 2 2d1
2d4 3 2d6 2d7
2d8 1 2db 1
2e3 1 2e7 2
2e6 2ea 1 2ee
1 2f3 1 2f8
1 304 1 30c
1 318 1 31c
1 320 1 324
2 32a 32b 1
32d 2 32f 331
2 337 338 1
33a 2 33c 33e
2 333 340 2
346 347 1 349
2 34b 34d 2
342 34f 2 351
352 2 358 359
1 35b 2 361
362 1 364 2
366 368 2 35d
36a 2 370 371
1 373 2 375
377 2 37a 37c
2 36c 37e 2
380 381 2 389
38b 3 387 388
38d 2 391 393
1 395 1 39c
1 39e 1 3a3
2 3a5 3a6 1
3aa 1 3b0 c
31a 31e 322 326
354 383 38f 397
3a0 3a8 3ac 3b2
2 313 3b4 2
3bc 3be 1 3c4
2 3c6 3c8 5
3ba 3bb 3c0 3ca
3cb 1 3d1 6
2ff 307 30f 3b6
3cd 3d3 3 2f1
2f6 2fb 1 3db
1 3df 1 3e3
1 3e7 4 3de
3e2 3e6 3ea 1
3ee 1 3f6 1
3fa 1 400 1
406 4 3f9 3ff
405 40b 1 40f
1 41d 1 423
1 428 1 42d
1 434 1 43a
1 432 1 43f
1 449 1 44e
1 452 2 450
452 1 457 1
45b 1 45e 2
460 461 1 462
1 465 1 467
2 469 46a 1
46d 1 472 1
474 1 476 1
479 1 47d 2
47b 47d 2 483
484 1 486 2
48b 48c 1 491
2 48f 491 1
495 1 497 1
499 2 489 49a
1 49c 1 4a2
1 4ac 3 4aa
4ae 4af 1 4b6
2 4b4 4b6 2
4bc 4be 1 4ca
1 4ce 2 4d6
4d8 3 4d4 4d5
4da 1 4de 1
4e2 1 4e6 1
4ea 2 4ee 4f0
1 4f2 2 501
503 3 4ff 500
505 2 507 50a
2 50d 50f 3
4f8 50c 511 9
4cc 4d0 4dc 4e0
4e4 4e8 4ec 4f4
513 2 4c5 515
1 51e 2 521
523 3 51c 520
525 3 4c1 517
528 1 530 1
53c 1 540 1
544 2 548 549
2 54d 54e 2
552 554 1 556
1 55a 1 562
2 564 565 2
567 568 9 53e
542 546 54b 550
558 55c 56a 56b
2 537 56d a
448 46b 477 49d
4a5 4b2 52b 533
56f 572 6 421
426 42b 430 43d
442 16 c 15
1d 23 2b 33
3c 41 51 67
cd fc 128 245
281 2a7 2b8 2e0
3d8 3f3 414 577

1
4
0 
582
0
1
14
11
3e
0 1 1 1 1 1 1 7
1 1 1 1 1 1 1 1
10 0 0 0 
2a9 1 b
3fa f 0
417 1 10
2d 1 0
400 f 0
3e3 e 0
2f8 d 0
2f3 d 0
ff 1 6
e 1 0
153 7 0
75 4 0
24e 9 0
13a 7 0
105 6 0
d6 5 0
406 f 0
3e7 e 0
3f5 1 f
2ee d 0
43f 10 0
6a 4 0
283 1 a
53 1 3
2bc c 0
4 1 0
3f6 f 0
3df e 0
2e7 d 0
3db e 0
2e3 d 0
42d 10 0
428 10 0
35 1 0
248 1 9
140 7 0
6e 4 0
d0 1 5
130 7 0
14c 7 0
12c 7 0
1f 1 0
284 a 0
3 0 1
3da 1 e
15a 7 0
2c0 c 0
41d 10 0
44 1 2
288 a 0
54 3 0
423 10 0
3e 1 0
12b 1 7
2bb 1 c
69 1 4
161 7 0
147 7 0
432 10 0
2e2 1 d
25 1 0
17 1 0
0

/
