set scan off

prompt Creating PL/ZIP packages...
@@plzip.sql


