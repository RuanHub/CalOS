create table zip_example
(
  id            number not null,
  filename      varchar2(4000 char),
  original_file blob
);