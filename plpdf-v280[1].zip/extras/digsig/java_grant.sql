begin
dbms_java.grant_permission( 'PLPDF', 'SYS:java.security.SecurityPermission', 'putProviderProperty.BC', '' );
dbms_java.grant_permission( 'PLPDF', 'SYS:java.security.SecurityPermission', 'insertProvider.BC', '' );
dbms_java.grant_permission( 'PLPDF', 'SYS:java.security.SecurityPermission', 'insertProviderProperty.BC', '');
end;