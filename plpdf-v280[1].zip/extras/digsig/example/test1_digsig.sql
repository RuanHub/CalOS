create or replace procedure test1_digsig is
l_blob blob;
l_text varchar2(255 char) := 'Hello World!';
l_cert blob;
begin

select t.file1 into l_cert
from digsigtest t
where name1 = 'keystore.pfx';

plpdf.init();
plpdf.NewPage;
plpdf.SetPrintFont('Arial',null,12);
plpdf.PrintCell(100,20,l_text);

plpdf_digsig.setKeyStore(l_cert);
plpdf_digsig.setCertAlias('ll');
plpdf_digsig.setKeyStorePassword('password');
plpdf_digsig.setPrivKeyPassword('password');

plpdf.setDigSig(
  p_access_perms => 2,
  p_Name => 'Neve',
  p_Location => 'Helye',
  p_Reason => 'Oka',
  p_ContactInfo => 'Kapcsolat',
  p_x => 10,
  p_y => 20,
  p_w => 50,
  p_h => 70
  );

plpdf.DrawRect(10,20,50,70);

plpdf.SendDoc(l_blob); -- create content


delete from STORE_BLOB;
insert into STORE_BLOB (blob_file, created_date) values (l_blob, sysdate);
commit;

end;
/
