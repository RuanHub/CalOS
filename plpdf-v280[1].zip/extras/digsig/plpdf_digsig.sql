create or replace package plpdf_digsig is
--v2.4.0

  v_original_data blob;
  v_signed_data blob;
  v_signproc varchar2(255 char) := 'PKCS7Sign';


  v_digsig_keystore blob;
  v_digsig_certalias varchar2(255 char);
  v_digsig_keystore_password varchar2(255 char);
  v_digsig_privkey_password varchar2(255 char);
  
--v2.4.0
procedure setSignProc(
  p_signproc varchar2
  );
--v2.4.0
procedure setOrignaldata(
  p_original_data blob
  );  
--v2.4.0
function getSigneddata
  return blob;  
--v2.4.0
procedure setKeyStore(
  p_digsig_keystore blob
  );
--v2.4.0
procedure setCertAlias(
  p_digsig_certalias varchar2
  );  
--v2.4.0
procedure setKeyStorePassword(
  p_digsig_keystore_password varchar2
  );  
--v2.4.0
procedure setPrivKeyPassword(
  p_digsig_privkey_password varchar2
  );    
--v2.4.0
procedure PKCS7Sign;

end plpdf_digsig;
/

create or replace package body plpdf_digsig wrapped 
0
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
3
b
9200000
1
4
0 
35
2 :e:
1PACKAGE:
1BODY:
1PLPDF_DIGSIG:
1RAISE_ERROR:
1P_MSG:
1VARCHAR2:
1RAISE_APPLICATION_ERROR:
1-:
120000:
1SETSIGNPROC:
1P_SIGNPROC:
1V_SIGNPROC:
1SETORIGNALDATA:
1P_ORIGINAL_DATA:
1BLOB:
1V_ORIGINAL_DATA:
1EMPTY_BLOB:
1DBMS_LOB:
1CREATETEMPORARY:
1TRUE:
1SESSION:
1FUNCTION:
1GETSIGNEDDATA:
1RETURN:
1V_SIGNED_DATA:
1SETKEYSTORE:
1P_DIGSIG_KEYSTORE:
1V_DIGSIG_KEYSTORE:
1SETCERTALIAS:
1P_DIGSIG_CERTALIAS:
1V_DIGSIG_CERTALIAS:
1SETKEYSTOREPASSWORD:
1P_DIGSIG_KEYSTORE_PASSWORD:
1V_DIGSIG_KEYSTORE_PASSWORD:
1SETPRIVKEYPASSWORD:
1P_DIGSIG_PRIVKEY_PASSWORD:
1V_DIGSIG_PRIVKEY_PASSWORD:
1PKCS7SIGN:
1P_INPUTFILE:
1P_OUTPUTFILE:
1P_KEYSTORE:
1P_CERTALIAS:
1P_KEYSTOREPASSWORD:
1P_PRIVATEKEYPASSWORD:
1LANGUAGE:
1JAVA:
1NAME:
1com.plpdf.digsig.BCSign.PKCS7Sign(:n     oracle.sql.BLOB,:n     oracle.sql.BL+
1OB,:n     oracle.sql.BLOB,:n     oracle.sql.CHAR,:n     oracle.sql.CHAR,:n   +
1  oracle.sql.CHAR:n     ) return java.lang.String:
1L_ERROR:
1CHAR:
132000:
1IS NOT NULL:
1PKCS7Sign:
0

0
0
15a
2
0 :2 a0 97 9a 8f a0 b0 3d
b4 55 6a a0 7e 51 b4 2e
a0 a5 57 b7 a4 b1 11 68
4f 9a 8f a0 b0 3d b4 55
6a :2 a0 d b7 a4 b1 11 68
4f 9a 8f a0 b0 3d b4 55
6a :2 a0 b4 2e d :2 a0 6b :4 a0
6b a5 57 :2 a0 d b7 a4 b1
11 68 4f a0 8d a0 b4 a0
2c 6a :2 a0 65 b7 a4 b1 11
68 4f 9a 8f a0 b0 3d b4
55 6a :2 a0 b4 2e d :2 a0 6b
:4 a0 6b a5 57 :2 a0 d b7 a4
b1 11 68 4f 9a 8f a0 b0
3d b4 55 6a :2 a0 d b7 a4
b1 11 68 4f 9a 8f a0 b0
3d b4 55 6a :2 a0 d b7 a4
b1 11 68 4f 9a 8f a0 b0
3d b4 55 6a :2 a0 d b7 a4
b1 11 68 4f a0 8d 8f a0
b0 3d 8f a0 b0 3d 8f a0
b0 3d 8f a0 b0 3d 8f a0
b0 3d 8f a0 b0 3d b4 :2 a0
2c 6a :3 a0 6e fe 68 9a b4
55 6a a3 :2 a0 51 a5 1c 81
b0 :2 a0 b4 2e d :2 a0 6b :4 a0
6b a5 57 :4 a0 e :2 a0 e :2 a0
e :2 a0 e :2 a0 e :2 a0 e a5
b d a0 7e b4 2e :2 a0 a5
57 b7 19 3c b7 a4 b1 11
68 4f a0 6e d :2 a0 b4 2e
d a0 4d d a0 4d d a0
4d d :2 a0 b4 2e d :2 a0 b4
2e d :2 a0 6b :4 a0 6b a5 57
:2 a0 6b :4 a0 6b a5 57 :2 a0 6b
:4 a0 6b a5 57 b7 a4 b1 11
a0 b1 56 4f 1d 17 b5 
15a
2
0 3 7 b 15 31 2d 2c
39 29 3e 42 46 4a 4d 50
51 56 5a 5b 60 62 66 68
74 78 7a 96 92 91 9e 8e
a3 a7 ab af b3 b7 b9 bd
bf cb cf d1 ed e9 e8 f5
e5 fa fe 102 106 10a 10b 110
114 118 11c 11f 123 127 12b 12f
132 133 138 13c 140 144 146 14a
14c 158 15c 15e 162 176 17a 17b
17f 183 187 18b 18f 193 195 199
19b 1a7 1ab 1ad 1c9 1c5 1c4 1d1
1c1 1d6 1da 1de 1e2 1e6 1e7 1ec
1f0 1f4 1f8 1fb 1ff 203 207 20b
20e 20f 214 218 21c 220 222 226
228 234 238 23a 256 252 251 25e
24e 263 267 26b 26f 273 277 279
27d 27f 28b 28f 291 2ad 2a9 2a8
2b5 2a5 2ba 2be 2c2 2c6 2ca 2ce
2d0 2d4 2d6 2e2 2e6 2e8 304 300
2ff 30c 2fc 311 315 319 31d 321
325 327 32b 32d 339 33d 33f 343
35f 35b 35a 367 374 370 357 37c
385 381 36f 38d 39a 396 36c 3a2
3ab 3a7 395 3b3 3c0 3bc 392 3c8
3bb 3cd 3d1 3d5 3d9 3dd 3e1 3e5
3e9 3ee 3fb 3ff 3b8 413 417 438
41f 423 427 42a 42b 433 41e 43f
443 41b 447 44c 450 454 458 45b
45f 463 467 46b 46e 46f 474 478
47c 480 484 486 48a 48e 490 494
498 49a 49e 4a2 4a4 4a8 4ac 4ae
4b2 4b6 4b8 4b9 4bb 4bf 4c3 4c6
4c7 4cc 4d0 4d4 4d5 4da 4dc 4e0
4e3 4e5 4e9 4eb 4f7 4fb 4fd 501
506 50a 50e 512 513 518 51c 520
521 525 529 52a 52e 532 533 537
53b 53f 540 545 549 54d 551 552
557 55b 55f 563 566 56a 56e 572
576 579 57a 57f 583 587 58a 58e
592 596 59a 59d 59e 5a3 5a7 5ab
5ae 5b2 5b6 5ba 5be 5c1 5c2 5c7
5c9 5cd 5cf 5db 5df 5e1 5e4 5e6
5e7 5f0 
15a
2
0 1 9 e b 17 1d :2 17
16 :2 1 3 1b 1c :2 1b 23 :2 3
:6 1 b 3 e :2 3 16 :2 1 3
11 3 :6 1 b 3 13 :2 3 19
:2 1 3 :3 16 :2 3 :2 c 1c 2d 33
:2 3c :3 3 16 3 :7 1 a 3 0
a :2 1 3 a 3 :6 1 b 3
15 :2 3 16 :2 1 3 :3 18 :2 3 :2 c
1c 2f 35 :2 3e :3 3 18 3 :6 1
b 3 16 :2 3 17 :2 1 3 19
3 :6 1 b 3 1e :2 3 1e :2 1
3 21 3 :6 1 b 3 1d :2 3
1d :2 1 3 20 3 :7 1 a 3
f :3 3 10 :3 3 e :3 3 f :3 3
16 :3 3 18 :2 3 13 5 c :2 1
18 21 :3 26 1 b 0 :2 1 3
b 1a :2 13 :2 b :2 3 :3 14 :2 3 :2 c
1c 2b 31 :2 3a :3 3 e 5 14
:2 5 15 :2 5 13 :2 5 14 :2 5 1b
:2 5 1d 5 :2 e 3 :4 6 5 11
:2 5 1a :2 3 :6 1 3 11 :2 3 :3 18
:2 3 19 :2 3 21 :2 3 20 :2 3 :3 14
:2 3 :3 16 :2 3 :2 c 1c 2f 35 :2 3e
:3 3 :2 c 1c 2b 31 :2 3a :3 3 :2 c
1c 2d 33 :2 3c :2 3 :4 1 5 :6 1

15a
4
0 :3 1 :8 3 :8 6
:2 4 :4 3 9 :4 a
:3 9 :3 d :2 c :4 9
10 :4 11 :3 10 :5 14
:a 15 :3 16 :2 13 :4 10
:2 19 1a 0 1a
:2 19 :3 1c :2 1b :4 19
1f :4 20 :3 1f :5 23
:a 24 :3 25 :2 22 :4 1f
28 :4 29 :3 28 :3 2c
:2 2b :4 28 2f :4 30
:3 2f :3 33 :2 32 :4 2f
36 :4 37 :3 36 :3 3a
:2 39 :4 36 :2 3d :4 3e
:4 3f :4 40 :4 41 :4 42
:4 43 3d :2 44 :2 3d
:5 44 3d 4f 0
:2 4f :8 51 :5 53 :a 54
:2 56 :3 57 :3 58 :3 59
:3 5a :3 5b :3 5c :3 56
:4 5f :4 60 :3 5f :2 52
:4 4f :3 66 :5 67 :3 68
:3 69 :3 6a :5 6b :5 6c
:a 6d :a 6e :a 6f :4 65
71 :6 1 
5f2
4
:3 0 1 :3 0 2
:3 0 3 :6 0 1
:2 0 4 :a 0 18
2 :7 0 5 :2 0
3 6 :3 0 5
:7 0 7 6 :3 0
9 :2 0 18 4
a :2 0 7 :3 0
8 :2 0 9 :2 0
7 d f :3 0
5 :3 0 9 c
12 :2 0 14 c
17 :3 0 17 0
17 16 14 15
:6 0 18 1 0
4 a 17 154
:2 0 a :a 0 29
3 :7 0 10 :2 0
e 6 :3 0 b
:7 0 1d 1c :3 0
1f :2 0 29 1a
20 :2 0 c :3 0
b :3 0 22 23
0 25 12 28
:3 0 28 0 28
27 25 26 :6 0
29 1 0 1a
20 28 154 :2 0
d :a 0 49 4
:7 0 16 :2 0 14
f :3 0 e :7 0
2e 2d :3 0 30
:2 0 49 2b 31
:2 0 10 :3 0 11
:4 0 34 35 :3 0
33 36 0 45
12 :3 0 13 :3 0
38 39 0 10
:3 0 14 :3 0 12
:3 0 15 :3 0 3d
3e 0 18 3a
40 :2 0 45 10
:3 0 e :3 0 42
43 0 45 1c
48 :3 0 48 0
48 47 45 46
:6 0 49 1 0
2b 31 48 154
:2 0 16 :3 0 17
:a 0 59 5 :7 0
18 :4 0 f :3 0
4e 4f 0 59
4c 50 :2 0 18
:3 0 19 :3 0 53
:2 0 55 20 58
:3 0 58 0 58
57 55 56 :6 0
59 1 0 4c
50 58 154 :2 0
1a :a 0 79 6
:7 0 24 :2 0 22
f :3 0 1b :7 0
5e 5d :3 0 60
:2 0 79 5b 61
:2 0 1c :3 0 11
:4 0 64 65 :3 0
63 66 0 75
12 :3 0 13 :3 0
68 69 0 1c
:3 0 14 :3 0 12
:3 0 15 :3 0 6d
6e 0 26 6a
70 :2 0 75 1c
:3 0 1b :3 0 72
73 0 75 2a
78 :3 0 78 0
78 77 75 76
:6 0 79 1 0
5b 61 78 154
:2 0 1d :a 0 8a
7 :7 0 30 :2 0
2e 6 :3 0 1e
:7 0 7e 7d :3 0
80 :2 0 8a 7b
81 :2 0 1f :3 0
1e :3 0 83 84
0 86 32 89
:3 0 89 0 89
88 86 87 :6 0
8a 1 0 7b
81 89 154 :2 0
20 :a 0 9b 8
:7 0 36 :2 0 34
6 :3 0 21 :7 0
8f 8e :3 0 91
:2 0 9b 8c 92
:2 0 22 :3 0 21
:3 0 94 95 0
97 38 9a :3 0
9a 0 9a 99
97 98 :6 0 9b
1 0 8c 92
9a 154 :2 0 23
:a 0 ac 9 :7 0
3c :2 0 3a 6
:3 0 24 :7 0 a0
9f :3 0 a2 :2 0
ac 9d a3 :2 0
25 :3 0 24 :3 0
a5 a6 0 a8
3e ab :3 0 ab
0 ab aa a8
a9 :6 0 ac 1
0 9d a3 ab
154 :2 0 16 :3 0
26 :a 0 d2 a
:7 0 42 36c 0
40 f :3 0 27
:7 0 b2 b1 :3 0
46 392 0 44
f :3 0 28 :7 0
b6 b5 :3 0 f
:3 0 29 :7 0 ba
b9 :3 0 4a 3b8
0 48 6 :3 0
2a :7 0 be bd
:3 0 6 :3 0 2b
:7 0 c2 c1 :6 0
4c 6 :3 0 2c
:7 0 c6 c5 :3 0
18 :3 0 6 :3 0
c8 ca 0 d2
af cb :2 0 2d
:3 0 2e :3 0 2f
:3 0 30 :4 0 d0
:3 0 3 0 1000
d2 :5 0 af cb
d1 154 26 :a 0
114 b :7 0 d4
:2 0 114 d3 d5
:5 0 56 6 :3 0
32 :3 0 33 :2 0
53 d8 db :6 0
de dc 0 112
0 31 :6 0 19
:3 0 11 :3 0 e0
e1 :3 0 df e2
0 110 12 :3 0
13 :3 0 e4 e5
0 19 :3 0 14
:3 0 12 :3 0 15
:3 0 e9 ea 0
58 e6 ec :2 0
110 31 :3 0 26
:3 0 27 :3 0 10
:3 0 f0 f1 28
:3 0 19 :3 0 f3
f4 29 :3 0 1c
:3 0 f6 f7 2a
:3 0 1f :3 0 f9
fa 2b :3 0 22
:3 0 fc fd 2c
:3 0 25 :3 0 ff
100 5c ef 102
ee 103 0 110
31 :3 0 34 :2 0
63 106 107 :3 0
4 :3 0 31 :3 0
65 109 10b :2 0
10d 67 10e 108
10d 0 10f 69
0 110 6b 113
:3 0 113 70 113
112 110 111 :6 0
114 1 0 d3
d5 113 154 :2 0
c :3 0 35 :4 0
116 117 0 14f
1c :3 0 11 :4 0
11a 11b :3 0 119
11c 0 14f 1f
:4 0 11e 11f 0
14f 22 :4 0 121
122 0 14f 25
:4 0 124 125 0
14f 19 :3 0 11
:4 0 128 129 :3 0
127 12a 0 14f
10 :3 0 11 :4 0
12d 12e :3 0 12c
12f 0 14f 12
:3 0 13 :3 0 131
132 0 1c :3 0
14 :3 0 12 :3 0
15 :3 0 136 137
0 72 133 139
:2 0 14f 12 :3 0
13 :3 0 13b 13c
0 19 :3 0 14
:3 0 12 :3 0 15
:3 0 140 141 0
76 13d 143 :2 0
14f 12 :3 0 13
:3 0 145 146 0
10 :3 0 14 :3 0
12 :3 0 15 :3 0
14a 14b 0 7a
147 14d :2 0 14f
7e 152 :3 0 152
0 152 154 14f
150 :6 0 155 :2 0
3 :3 0 89 0
3 152 158 :3 0
157 155 159 :8 0

94
4
:3 0 1 5 1
8 1 e 2
10 11 1 13
1 1b 1 1e
1 24 1 2c
1 2f 3 3b
3c 3f 3 37
41 44 1 54
1 5c 1 5f
3 6b 6c 6f
3 67 71 74
1 7c 1 7f
1 85 1 8d
1 90 1 96
1 9e 1 a1
1 a7 1 b0
1 b4 1 b8
1 bc 1 c0
1 c4 6 b3
b7 bb bf c3
c7 2 da d9
1 d7 3 e7
e8 eb 6 f2
f5 f8 fb fe
101 1 105 1
10a 1 10c 1
10e 4 e3 ed
104 10f 1 dd
3 134 135 138
3 13e 13f 142
3 148 149 14c
a 118 11d 120
123 126 12b 130
13a 144 14e a
18 29 49 59
79 8a 9b ac
d2 114 
1
4
0 
158
0
1
14
b
19
0 1 1 1 1 1 1 1
1 1 1 0 0 0 0 0
0 0 0 0 
8c 1 8
5c 6 0
2c 4 0
8d 8 0
9d 1 9
c4 a 0
7b 1 7
9e 9 0
d7 b 0
bc a 0
1a 1 3
3 0 1
c0 a 0
b4 a 0
5b 1 6
4c 1 5
4 1 2
7c 7 0
2b 1 4
d3 1 b
af 1 a
5 2 0
b0 a 0
1b 3 0
b8 a 0
0

/
