plpdf_img2 error handling with Oracle InterMedia
replace plpdf_img2_err package with plpdf_img2_err_IM.sql