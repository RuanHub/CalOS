create or replace package plpdf_img2_err is
--v2.4.0
c_handle varchar2(5 char) := 'TRUE';
--
c_im_process varchar2(255 char) := 'fileFormat=JPEG contentFormat=24BITRGB';
--
function errorhandler(
  p_img in out nocopy blob, 
  p_name varchar2
  ) return blob;
--
end plpdf_img2_err;
/

create or replace package body plpdf_img2_err wrapped 
0
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
3
b
9200000
1
4
0 
13
2 :e:
1PACKAGE:
1BODY:
1PLPDF_IMG2_ERR:
1FUNCTION:
1ERRORHANDLER:
1P_IMG:
1OUT:
1NOCOPY:
1BLOB:
1P_NAME:
1VARCHAR2:
1RETURN:
1L_IMAGE:
1ORDSYS:
1ORDIMAGE:
1ORDSOURCE:
1PROCESS:
1C_IM_PROCESS:
1GETCONTENT:
0

0
0
53
2
0 :2 a0 97 a0 8d 90 :3 a0 b0
3f 8f a0 b0 3d b4 :2 a0 2c
6a a3 :2 a0 6b 1c 81 b0 :3 a0
6b :2 a0 6b a0 :5 4d a5 b :7 4d
a5 b d :2 a0 6b a0 a5 57
:3 a0 6b b4 2e 65 b7 a4 b1
11 68 4f b1 b7 a4 11 a0
b1 56 4f 1d 17 b5 
53
2
0 3 7 b 15 19 3d 31
35 39 30 44 51 4d 2d 59
4c 5e 62 66 6a 87 72 76
49 7a 82 71 8e 92 96 6e
9a 9e a2 a5 a9 aa ab ac
ad ae af b1 b2 b3 b4 b5
b6 b7 b8 b9 bb bf c3 c7
ca ce cf d4 d8 dc e0 e3
e4 e9 ed ef f3 f5 101 105
107 109 10b 10f 11b 11f 121 124
126 127 130 
53
2
0 1 9 e 1 a 3 c
10 17 :3 3 a :2 3 16 5 c
:2 1 3 10 17 :3 10 3 4 f
:2 16 1f :2 26 9 f 14 19 1e
23 :2 1f 29 2e 33 38 3d 42
47 :2 f :2 4 :2 c 14 :3 4 b :2 13
:2 b 4 :a 1 5 :6 1 
53
4
0 :3 1 :2 3 :6 4
:4 5 3 :2 6 :2 3
:7 7 :7 a :6 b :2 a
:7 b :3 a :6 c :7 d
:2 8 :8 3 10 :6 1

132
4
:3 0 1 :3 0 2
:3 0 3 :6 0 1
:2 0 4 :3 0 5
:a 0 46 2 :7 0
5 49 0 3
7 :3 0 8 :3 0
9 :3 0 6 :5 0
1 a 9 :3 0
16 17 0 7
b :3 0 a :7 0
e d :3 0 c
:3 0 9 :3 0 10
12 0 46 5
13 :2 0 1d 1e
0 a e :3 0
f :2 0 4 18
:7 0 1b 19 0
44 0 d :6 0
d :3 0 e :3 0
f :3 0 e :3 0
10 :3 0 20 21
0 6 :8 0 c
22 29 :7 0 13
1f 32 1c 33
0 42 d :3 0
11 :3 0 35 36
0 12 :3 0 1c
37 39 :2 0 42
c :3 0 d :3 0
13 :3 0 3c 3d
:2 0 3e 3f :3 0
40 :2 0 42 1e
45 :3 0 45 22
45 44 42 43
:6 0 46 1 0
5 13 45 4d
:3 0 4b 0 4b
:3 0 4b 4d 49
4a :6 0 4e :2 0
3 :3 0 24 0
3 4b 51 :3 0
50 4e 52 :8 0

26
4
:3 0 1 6 1
c 2 b f
1 15 6 23
24 25 26 27
28 8 2a 2b
2c 2d 2e 2f
30 31 1 38
3 34 3a 41
1 1a 1 46

1
4
0 
51
0
1
14
2
5
0 1 0 0 0 0 0 0
0 0 0 0 0 0 0 0
0 0 0 0 
3 0 1
6 2 0
15 2 0
c 2 0
5 1 2
0

/
