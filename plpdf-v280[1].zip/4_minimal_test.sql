prompt run minimal test

prompt create store blob table
CREATE TABLE STORE_BLOB
(
  BLOB_FILE     BLOB,
  CREATED_DATE  DATE
);

prompt create helllo world procedure
CREATE OR REPLACE procedure helloworld1 is 
  l_blob blob;
 begin
    plpdf.init; 
    plpdf.NewPage; 
    plpdf.SetPrintFont(
     p_family => 'Arial',
     p_style => null,
     p_size => 12
     ); 
 
    plpdf.PrintCell(
     p_w => 50, 
     p_h => 10, 
     p_txt => 'Hello World!' 
     ); 
    
    plpdf.SendDoc(
     p_blob => l_blob
     );
	

    insert into STORE_BLOB (blob_file, created_date) values (l_blob, sysdate);  
    commit;
 end;
/


prompt run procedure
begin
  helloworld1;
end;
/

EXIT


