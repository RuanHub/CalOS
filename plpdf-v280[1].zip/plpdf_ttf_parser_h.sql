create or replace package plpdf_ttf_parser is
--v2.7.0

--v2.3.0
function makeFont1(
    p_fontfile_name varchar2,
    p_fontfile blob,
    p_enc varchar2 default 'cp1252',
    p_enc_subset boolean default false
    ) return plpdf_type.t_addfont;

--v2.1.1
function MakeFont_Utf16(
  p_fontfile_name varchar2,
  p_fontfile blob
  ) return Plpdf_Type.t_addfont;

--v2.3.0
procedure StoreTTF1(
  p_font_file_id number,
  p_enc varchar2 default 'cp1252',
  p_commit boolean default true,
  p_enc_subset boolean default false
  );

--v2.1.1
procedure StoreTTF_Utf16(
  p_font_file_id number,
  p_commit boolean default true
  );

--v2.1.1
procedure StoreTTF(
  p_font_file_id number,
  p_enc varchar2 default 'cp1252',
  p_commit boolean default true
  );
end plpdf_ttf_parser;
/

